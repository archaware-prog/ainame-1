"use client";

import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { Search } from "lucide-react";
import { TypeTabs } from "./ResourceList";
import { ResourceRow } from "./ResourceRow";
import { useResources, useTopics } from "@/lib/store";
import { TYPE_LABEL, inTopic, placeNames, type Resource, type ResourceType, type Topic } from "@/lib/types";

const TYPES = Object.keys(TYPE_LABEL) as ResourceType[];

function matches(r: Resource, query: string, topics: Topic[]) {
  const places = placeNames(r, topics).map((p) => `${p.topic.name} ${p.sub.name}`).join(" ");
  const haystack = `${r.title} ${places} ${TYPE_LABEL[r.type]} ${r.unit ? `unit ${r.unit}` : ""}`.toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((word) => haystack.includes(word));
}

export function ExploreView() {
  const params = useSearchParams();
  // Re-mount when the URL changes (e.g. a new search from the header) so the filters reset to it
  return <ExploreInner key={params.toString()} params={params} />;
}

function ExploreInner({ params }: { params: URLSearchParams }) {
  const initialType = params.get("type") as ResourceType | null;
  const [query, setQuery] = useState(params.get("q") ?? "");
  const [type, setType] = useState<ResourceType | "all">(initialType && TYPES.includes(initialType) ? initialType : "all");
  // "all", "topic" or "topic/sub"
  const [place, setPlace] = useState(params.get("topic") ?? "all");

  const resources = useResources();
  const topics = useTopics();
  const inPlace = (r: Resource) => {
    if (place === "all") return true;
    const [topic, sub] = place.split("/");
    return inTopic(r, topic, sub);
  };
  const results = resources.filter((r) => (type === "all" || r.type === type) && inPlace(r) && matches(r, query, topics));

  return (
    <div className="px-4 lg:px-8">
      <h1 className="mt-6 font-display text-3xl font-extrabold tracking-tight">Explore</h1>
      <p className="mt-1 text-sm text-muted">Search everything, or filter by topic and type.</p>

      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        <label className="relative block flex-1">
          <Search size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search notes, PPTs, videos…" className="input py-3 pl-10" autoFocus={!!params.get("q")} />
        </label>
        <select value={place} onChange={(e) => setPlace(e.target.value)} className="input py-3 sm:w-72" aria-label="Topic">
          <option value="all">All topics</option>
          {topics.map((t) => (
            <optgroup key={t.slug} label={t.name}>
              {/* Starts with the topic name, so typing its first letter in the open list jumps here */}
              <option value={t.slug}>{t.name} (all)</option>
              {t.subtopics.map((s) => (
                <option key={s.key} value={s.key}>
                  {s.name}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
      </div>

      <div className="mt-4">
        <TypeTabs types={TYPES} value={type} onChange={setType} />
      </div>

      <p className="mb-3 mt-5 text-xs font-semibold uppercase tracking-wider text-muted">
        {results.length} {results.length === 1 ? "result" : "results"}
      </p>
      {results.length === 0 ? (
        <div className="card p-10 text-center">
          <p className="text-3xl">🔍</p>
          <p className="mt-2 font-semibold">Nothing matches that yet</p>
          <p className="text-sm text-muted">Try a shorter word, or clear the filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2.5 lg:grid-cols-2">
          {results.map((r) => (
            <ResourceRow key={r.id} r={r} showPlace />
          ))}
        </div>
      )}
    </div>
  );
}
