"use client";

import { useState } from "react";
import { ResourceRow } from "./ResourceRow";
import { TYPE_LABEL, type Resource, type ResourceType } from "@/lib/types";

const TAB_ORDER: ResourceType[] = ["notes", "slides", "video", "qbank", "paper", "book"];

export function TypeTabs({ types, value, onChange }: { types: ResourceType[]; value: ResourceType | "all"; onChange: (t: ResourceType | "all") => void }) {
  const tabs: (ResourceType | "all")[] = ["all", ...TAB_ORDER.filter((t) => types.includes(t))];
  return (
    <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none]">
      {tabs.map((t) => (
        <button
          key={t}
          onClick={() => onChange(t)}
          className={`shrink-0 rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${value === t ? "bg-[var(--text)] text-[var(--bg)]" : "bg-black/5 text-muted hover:text-[var(--text)] dark:bg-white/10"}`}
        >
          {t === "all" ? "All" : TYPE_LABEL[t]}
        </button>
      ))}
    </div>
  );
}

/** Groups by unit when the material has units; anything without a unit goes under "More material" */
function groupByUnit(items: Resource[]) {
  const units = new Map<number, Resource[]>();
  const rest: Resource[] = [];
  for (const r of items) {
    if (r.unit) units.set(r.unit, [...(units.get(r.unit) ?? []), r]);
    else rest.push(r);
  }
  const groups = [...units.entries()].sort((a, b) => a[0] - b[0]).map(([u, list]) => ({ title: `Unit ${u}`, list }));
  if (rest.length) groups.push({ title: groups.length ? "More material" : "", list: rest });
  return groups;
}

/** Type tabs (Notes, PPT, Videos…), an optional unit picker, then the items grouped by unit */
export function UnitResources({ all }: { all: Resource[] }) {
  const [tab, setTab] = useState<ResourceType | "all">("all");
  const [pickedUnit, setUnit] = useState(0);
  const ofType = tab === "all" ? all : all.filter((r) => r.type === tab);
  const types = [...new Set(all.map((r) => r.type))];
  const units = [...new Set(ofType.map((r) => r.unit).filter((u): u is number => !!u))].sort((a, b) => a - b);
  // A unit picked under another tab may not exist under this one
  const unit = units.length > 1 && units.includes(pickedUnit) ? pickedUnit : 0;
  const items = unit ? ofType.filter((r) => r.unit === unit) : ofType;

  return (
    <>
      <div className="flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <TypeTabs types={types} value={tab} onChange={setTab} />
        </div>
        {units.length > 1 && (
          <select value={unit} onChange={(e) => setUnit(Number(e.target.value))} aria-label="Unit" className="input w-auto py-1.5 text-sm">
            <option value={0}>All units</option>
            {units.map((u) => (
              <option key={u} value={u}>
                Unit {u}
              </option>
            ))}
          </select>
        )}
      </div>
      {items.length === 0 ? (
        <p className="card mt-4 p-8 text-center text-sm text-muted">Nothing here yet. New material is coming soon.</p>
      ) : (
        groupByUnit(items).map((g) => (
          <section key={g.title || "all"} className="mt-6">
            {g.title && <h2 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted">{g.title}</h2>}
            <div className="grid grid-cols-1 gap-2.5 lg:grid-cols-2">
              {g.list.map((r) => (
                <ResourceRow key={r.id} r={r} />
              ))}
            </div>
          </section>
        ))
      )}
    </>
  );
}
