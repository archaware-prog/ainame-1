import { startPhotoUpload, startUpload } from "@/lib/actions";

const PHOTO_WIDTH = 1600;
/** Slideshow photos fill most of a wide screen */
const SLIDE_WIDTH = 2000;

/** Shrinks a photo to at most 1600 px wide (2000 for slides; WebP where the browser can), uploads it, returns its key */
export async function uploadPhoto(file: File, kind: "about" | "person" | "gallery" | "workshop" | "slide" = "about"): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("Please choose a photo (JPG, PNG or WebP).");
  if (file.size > 20 * 1024 * 1024) throw new Error("That photo is larger than 20 MB. Please choose a smaller one.");
  const bitmap = await createImageBitmap(file).catch(() => null);
  if (!bitmap) throw new Error("That photo could not be read. Try a JPG or PNG.");
  const scale = Math.min(1, (kind === "slide" ? SLIDE_WIDTH : PHOTO_WIDTH) / bitmap.width);
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", 0.85));
  if (!blob) throw new Error("That photo could not be prepared. Try a different one.");

  const signed = await startPhotoUpload(kind);
  if (!signed.ok) throw new Error(signed.error);
  const res = await fetch(signed.data.url, { method: "PUT", body: blob, headers: { "Content-Type": blob.type } }).catch(() => null);
  if (!res?.ok) throw new Error(NETWORK_ERROR);
  return signed.data.key;
}

// R2 itself allows far bigger files; this keeps page rendering quick on the owner's device
export const MAX_MB = 50;
const PAGE_WIDTH = 1400;
const PARALLEL_PAGES = 3;
const NETWORK_ERROR = "Upload failed. Check your internet and try again.";

/**
 * Sends one PDF from the owner's browser straight to R2, together with an image of every page
 * (students see the images, so "view only" files never send the PDF). Returns where it was saved.
 */
export async function uploadPdf(file: File, onProgress: (percent: number) => void): Promise<{ fileId: string; pages: number }> {
  const doc = await openPdf(file);
  try {
    const signed = await startUpload(file.name, doc.numPages);
    if (!signed.ok) throw new Error(signed.error);
    const { fileId, pdf, pages } = signed.data;

    // Half the bar for the PDF upload, half for the pages
    let pdfPart = 0;
    let pagesDone = 0;
    const report = () => onProgress(Math.min(99, Math.round(pdfPart * 50 + (pagesDone / pages.length) * 50)));

    const sendPdf = putWithProgress(pdf, file, "application/pdf", (p) => {
      pdfPart = p;
      report();
    });

    let next = 0;
    const worker = async () => {
      while (next < pages.length) {
        const i = next++;
        const image = await renderPage(doc, i + 1);
        const res = await fetch(pages[i], { method: "PUT", body: image, headers: { "Content-Type": image.type } }).catch(() => null);
        if (!res?.ok) throw new Error(NETWORK_ERROR);
        pagesDone++;
        report();
      }
    };
    await Promise.all([sendPdf, ...Array.from({ length: Math.min(PARALLEL_PAGES, pages.length) }, worker)]);
    onProgress(100);
    return { fileId, pages: pages.length };
  } finally {
    void doc.loadingTask.destroy();
  }
}

type PdfDoc = import("pdfjs-dist").PDFDocumentProxy;

export async function openPdf(file: File): Promise<PdfDoc> {
  const pdfjs = await import("pdfjs-dist");
  // Worker, fonts and decoders are copied into public/pdfjs by scripts/copy-pdfjs.mjs
  pdfjs.GlobalWorkerOptions.workerSrc = "/pdfjs/pdf.worker.min.mjs";
  try {
    return await pdfjs.getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
      standardFontDataUrl: "/pdfjs/standard_fonts/",
      cMapUrl: "/pdfjs/cmaps/",
      wasmUrl: "/pdfjs/wasm/",
      iccUrl: "/pdfjs/iccs/",
    }).promise;
  } catch (e) {
    if (e instanceof pdfjs.PasswordException) throw new Error("This PDF has a password. Remove the password and try again.");
    throw new Error("This PDF could not be read. Try saving it again as PDF.");
  }
}

/** One page as a WebP image 1400 px wide (JPEG on browsers that cannot make WebP) */
export async function renderPage(doc: PdfDoc, n: number): Promise<Blob> {
  const page = await doc.getPage(n);
  const base = page.getViewport({ scale: 1 });
  const viewport = page.getViewport({ scale: Math.min(4, PAGE_WIDTH / base.width) });
  const canvas = document.createElement("canvas");
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  await page.render({ canvas, viewport, background: "#ffffff" }).promise;
  page.cleanup();

  const encode = (type: string, quality: number) => new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, type, quality));
  let blob = await encode("image/webp", 0.8);
  if (blob?.type !== "image/webp") blob = await encode("image/jpeg", 0.85);
  canvas.width = canvas.height = 0; // frees the memory straight away on phones
  if (!blob) throw new Error(`Page ${n} could not be prepared. Try saving the PDF again.`);
  return blob;
}

function putWithProgress(url: string, body: Blob, type: string, onProgress: (fraction: number) => void) {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    xhr.setRequestHeader("Content-Type", type);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? (onProgress(1), resolve()) : reject(new Error(NETWORK_ERROR)));
    xhr.onerror = () => reject(new Error(NETWORK_ERROR));
    xhr.send(body);
  });
}
