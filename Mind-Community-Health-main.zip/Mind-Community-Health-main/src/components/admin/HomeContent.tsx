"use client";

import { useState } from "react";
import { ArrowDown, ArrowLeft, ArrowUp, CalendarDays, ImagePlus, Images, MapPin, Pencil, Plus, Target, Trash2, UserRound } from "lucide-react";
import { SectionTabs, setUrlParams, ViewToggle, type View } from "./Sections";
import { Label, PageTitle, SaveFooter, useStatus } from "./SitePages";
import { workshopDate } from "../HomeExtras";
import { uploadPhoto } from "./upload";
import { saveGallery, saveNotices, savePeople, saveSlides, saveVisionMission, saveWorkshops, type PhotoInput } from "@/lib/actions";
import type { HomePage } from "@/lib/types";

// Owner edits the home page extras: header photos, photo gallery, workshops, vision & mission.
// Photos are shrunk in this browser, uploaded to R2 on Save, and only then stored.

type Kind = "person" | "gallery" | "workshop" | "slide";
/** A photo as the form holds it: the stored link, or a new file picked but not yet uploaded */
type Pic = { photo: string; file?: File; preview?: string };

const src = (p: Pic) => p.preview || p.photo;
const withFile = (f: File): Pic => ({ photo: "", file: f, preview: URL.createObjectURL(f) });

// Files already uploaded by a save that then failed, so pressing Save again does not upload them twice.
// Cleared after a successful save (a removed photo is deleted from storage, so its key must not be reused).
const uploaded = new WeakMap<File, string>();

async function toInput(p: Pic, kind: Kind): Promise<PhotoInput> {
  if (!p.file) return { photo: p.photo };
  let key = uploaded.get(p.file);
  if (!key) {
    key = await uploadPhoto(p.file, kind);
    uploaded.set(p.file, key);
  }
  return { photo: "", newPhoto: key };
}

const forget = (pics: Pic[]) => pics.forEach((p) => p.file && uploaded.delete(p.file));

/** Copies the chosen files out, then clears the input so the same file can be picked again */
const takeFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(e.target.files ?? []);
  e.target.value = "";
  return files;
};

function move<T>(list: T[], i: number, by: -1 | 1) {
  const next = [...list];
  [next[i], next[i + by]] = [next[i + by], next[i]];
  return next;
}

const iconBtn = "rounded-lg p-2 text-muted hover:bg-black/5 hover:text-[var(--text)] disabled:opacity-30 dark:hover:bg-white/10";
const deleteBtn = "rounded-lg p-2 text-muted hover:bg-rose-500/10 hover:text-rose-500";

const SECTIONS = [
  { id: "slideshow", label: "Slideshow", icon: ImagePlus },
  { id: "news", label: "News strip", icon: Pencil },
  { id: "people", label: "Header photos", icon: UserRound },
  { id: "gallery0", label: "Gallery 1", icon: Images },
  { id: "gallery1", label: "Gallery 2", icon: Images },
  { id: "workshops", label: "Workshops", icon: CalendarDays },
  { id: "vision", label: "Vision & Mission", icon: Target },
] as const;
type Section = (typeof SECTIONS)[number]["id"];

export function HomeContent({ home, view, onView, initialSection }: { home: HomePage; view: View; onView: (v: View) => void; initialSection?: string }) {
  const [section, setSectionState] = useState<Section>(() => SECTIONS.find((s) => s.id === initialSection)?.id ?? "workshops");
  const setSection = (s: Section) => {
    setSectionState(s);
    setUrlParams({ section: s });
  };
  // Every form stays mounted and is only hidden, so unsaved edits survive switching sections
  const show = (id: Section) => (section === id ? "" : "hidden");
  return (
    <div className="w-full space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold sm:text-3xl">Home page</h1>
        <p className="mt-1 text-sm text-muted">Pick a part of the home page to edit. Each part has its own Save button. What you save shows on the website straight away.</p>
      </div>
      <SectionTabs items={SECTIONS} value={section} onChange={setSection} label="Home page sections" />
      <div className={show("slideshow")}>
        <SlideshowForm initial={home} />
      </div>
      <div className={show("news")}>
        <NewsForm initial={home} />
      </div>
      <div className={show("people")}>
        <PeopleForm initial={home} />
      </div>
      <div className={show("gallery0")}>
        <GalleryForm index={0} initial={home} />
      </div>
      <div className={show("gallery1")}>
        <GalleryForm index={1} initial={home} />
      </div>
      <div className={show("workshops")}>
        <WorkshopsForm initial={home} view={view} onView={onView} />
      </div>
      <div className={show("vision")}>
        <VisionForm initial={home} />
      </div>
    </div>
  );
}

function PhotoPicker({ pic, onPick, onClear, label, className }: { pic: Pic; onPick: (f: File) => void; onClear?: () => void; label: string; className: string }) {
  const shown = src(pic);
  return (
    <div className="flex items-center gap-3">
      {shown ? (
        // eslint-disable-next-line @next/next/no-img-element -- local preview or signed redirect
        <img src={shown} alt={label} className={`${className} rounded-lg object-cover ring-1 ring-[var(--line)]`} />
      ) : (
        <span className={`${className} grid place-items-center rounded-lg border-2 border-dashed border-line text-muted`}>
          <UserRound size={20} />
        </span>
      )}
      <div className="flex flex-col gap-1.5">
        <label className="btn-ghost cursor-pointer py-1.5 text-xs">
          <ImagePlus size={14} /> {shown ? "Change photo" : "Choose photo"}
          <input
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={(e) => {
              const [f] = takeFiles(e);
              if (f) onPick(f);
            }}
          />
        </label>
        {shown && onClear && (
          <button type="button" onClick={onClear} className="btn-ghost py-1.5 text-xs text-rose-600 dark:text-rose-400">
            <Trash2 size={14} /> Remove photo
          </button>
        )}
      </div>
    </div>
  );
}

// ---------- slideshow ----------

type SlideState = { heading: string; text: string; button: string; link: string; pic: Pic };

function SlideshowForm({ initial }: { initial: HomePage }) {
  const fromHome = (h: HomePage): SlideState[] => h.slides.map(({ photo, ...s }) => ({ ...s, pic: { photo } }));
  const [slides, setSlides] = useState(() => fromHome(initial));
  const status = useStatus();
  const set = (i: number, patch: Partial<SlideState>) => setSlides(slides.map((s, j) => (j === i ? { ...s, ...patch } : s)));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      for (const [i, s] of slides.entries()) {
        if (!src(s.pic)) throw new Error(`Slide ${i + 1} needs a photo. Choose one, or remove the slide.`);
        const link = s.link.trim();
        if (link && !link.startsWith("https://") && !link.startsWith("/")) throw new Error(`The button link on slide ${i + 1} must start with https:// or /`);
      }
      const input = [];
      // One at a time, so a phone on slow internet does not time out
      for (const { pic, ...s } of slides) input.push({ ...s, ...(await toInput(pic, "slide")) });
      const res = await saveSlides(input);
      if (!res.ok) throw new Error(res.error);
      forget(slides.map((s) => s.pic));
      setSlides(fromHome(res.data));
    });
  };

  return (
    <form onSubmit={submit}>
      {/* Locked while saving, so edits made during a slow upload are not overwritten by the saved copy */}
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
        <PageTitle title="Slideshow" href="/" />
        <p className="-mt-2 text-xs text-muted">These photos take turns at the top of the home page, changing every few seconds. Wide landscape photos look best. Leave the text boxes empty to use the usual words (Learn • Understand • Apply). With no slides, the home page shows the built-in picture. Up to 8 slides.</p>
        {slides.map((s, i) => (
          <div key={i} className="space-y-3 rounded-xl border border-line p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm font-semibold">Slide {i + 1}</span>
              <div className="flex gap-1">
                <button type="button" disabled={i === 0} onClick={() => setSlides(move(slides, i, -1))} aria-label={`Move slide ${i + 1} earlier`} className={iconBtn}>
                  <ArrowUp size={16} />
                </button>
                <button type="button" disabled={i === slides.length - 1} onClick={() => setSlides(move(slides, i, 1))} aria-label={`Move slide ${i + 1} later`} className={iconBtn}>
                  <ArrowDown size={16} />
                </button>
                <button type="button" onClick={() => setSlides(slides.filter((_, j) => j !== i))} aria-label={`Delete slide ${i + 1}`} className={deleteBtn}>
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            <PhotoPicker pic={s.pic} label={`Slide ${i + 1} photo`} className="aspect-video w-40 sm:w-56" onPick={(f) => set(i, { pic: withFile(f) })} onClear={() => set(i, { pic: { photo: "" } })} />
            <div className="grid gap-2 sm:grid-cols-2">
              <input value={s.heading} maxLength={120} onChange={(e) => set(i, { heading: e.target.value })} placeholder="Heading (optional)" aria-label={`Slide ${i + 1} heading`} className="input py-2" />
              <input value={s.text} maxLength={240} onChange={(e) => set(i, { text: e.target.value })} placeholder="Short line (optional)" aria-label={`Slide ${i + 1} short line`} className="input py-2" />
              <input value={s.button} maxLength={40} onChange={(e) => set(i, { button: e.target.value })} placeholder="Button text (optional)" aria-label={`Slide ${i + 1} button text`} className="input py-2" />
              <input value={s.link} onChange={(e) => set(i, { link: e.target.value })} placeholder="/topics/... or https://..." aria-label={`Slide ${i + 1} button link`} className="input py-2" />
            </div>
          </div>
        ))}
        <button type="button" disabled={slides.length >= 8} onClick={() => setSlides([...slides, { heading: "", text: "", button: "", link: "", pic: { photo: "" } }])} className="btn-ghost disabled:opacity-40">
          <Plus size={16} /> Add slide
        </button>
        <SaveFooter state={status.state} label="Save slideshow" />
      </fieldset>
    </form>
  );
}

// ---------- news strip ----------

function NewsForm({ initial }: { initial: HomePage }) {
  const [notices, setNotices] = useState(() => [...initial.notices]);
  const status = useStatus();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const res = await saveNotices(notices);
      if (!res.ok) throw new Error(res.error);
      setNotices([...res.data.notices]);
    });
  };

  return (
    <form onSubmit={submit}>
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
        <PageTitle title="News strip" href="/" />
        <p className="-mt-2 text-xs text-muted">Short notices that scroll across a strip under the slideshow, for example ‘Workshop on Mental Health — 5 December’. The newest material you upload is added to the strip automatically. Up to 10 notices.</p>
        {notices.map((n, i) => (
          <div key={i} className="flex items-center gap-2">
            <input value={n} maxLength={160} onChange={(e) => setNotices(notices.map((x, j) => (j === i ? e.target.value : x)))} placeholder="Notice" aria-label={`Notice ${i + 1}`} className="input py-2" />
            <button type="button" disabled={i === 0} onClick={() => setNotices(move(notices, i, -1))} aria-label={`Move notice ${i + 1} earlier`} className={iconBtn}>
              <ArrowUp size={16} />
            </button>
            <button type="button" disabled={i === notices.length - 1} onClick={() => setNotices(move(notices, i, 1))} aria-label={`Move notice ${i + 1} later`} className={iconBtn}>
              <ArrowDown size={16} />
            </button>
            <button type="button" onClick={() => setNotices(notices.filter((_, j) => j !== i))} aria-label={`Delete notice ${i + 1}`} className={deleteBtn}>
              <Trash2 size={16} />
            </button>
          </div>
        ))}
        <button type="button" disabled={notices.length >= 10} onClick={() => setNotices([...notices, ""])} className="btn-ghost disabled:opacity-40">
          <Plus size={16} /> Add notice
        </button>
        <SaveFooter state={status.state} label="Save news strip" />
      </fieldset>
    </form>
  );
}

// ---------- header people ----------

type PersonState = { name: string; title: string; pic: Pic };

function PeopleForm({ initial }: { initial: HomePage }) {
  const fromHome = (h: HomePage): PersonState[] => h.people.map((p) => ({ name: p.name, title: p.title, pic: { photo: p.photo } }));
  const [people, setPeople] = useState(() => fromHome(initial));
  const status = useStatus();
  const set = (i: number, patch: Partial<PersonState>) => setPeople(people.map((p, j) => (j === i ? { ...p, ...patch } : p)));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const input = await Promise.all(people.map(async (p) => ({ name: p.name, title: p.title, ...(await toInput(p.pic, "person")) })));
      const res = await savePeople(input);
      if (!res.ok) throw new Error(res.error);
      forget(people.map((p) => p.pic));
      setPeople(fromHome(res.data));
    });
  };

  return (
    <form onSubmit={submit}>
      {/* Locked while saving, so edits made during a slow upload are not overwritten by the saved copy */}
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
      <PageTitle title="Photos at the top of the site" href="/" />
      <p className="-mt-2 text-xs text-muted">Passport-size photos with names, shown in the top-right corner of every page. Up to 3 people.</p>
      {people.map((p, i) => (
        <div key={i} className="flex flex-col gap-3 rounded-xl border border-line p-3 sm:flex-row sm:items-center">
          <PhotoPicker pic={p.pic} label={p.name} className="h-20 w-16" onPick={(f) => set(i, { pic: withFile(f) })} onClear={() => set(i, { pic: { photo: "" } })} />
          <div className="grid flex-1 gap-2 sm:grid-cols-2">
            <input value={p.name} onChange={(e) => set(i, { name: e.target.value })} placeholder="Name, e.g. Dr. A. Sharma" aria-label="Name" className="input py-2" />
            <input value={p.title} onChange={(e) => set(i, { title: e.target.value })} placeholder="Title, e.g. MD, Professor" aria-label="Title" className="input py-2" />
          </div>
          <div className="flex gap-1 self-end sm:self-auto">
            <button type="button" disabled={i === 0} onClick={() => setPeople(move(people, i, -1))} aria-label="Move left" className={iconBtn}>
              <ArrowUp size={16} />
            </button>
            <button type="button" disabled={i === people.length - 1} onClick={() => setPeople(move(people, i, 1))} aria-label="Move right" className={iconBtn}>
              <ArrowDown size={16} />
            </button>
            <button type="button" onClick={() => setPeople(people.filter((_, j) => j !== i))} aria-label="Remove person" className={deleteBtn}>
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      ))}
      {people.length < 3 && (
        <button type="button" onClick={() => setPeople([...people, { name: "", title: "", pic: { photo: "" } }])} className="btn-ghost">
          <Plus size={16} /> Add a person
        </button>
      )}
      <SaveFooter state={status.state} label="Save photos" />
    </fieldset>
    </form>
  );
}

// ---------- gallery ----------

type GalleryPic = { pic: Pic; caption: string };

function GalleryForm({ index, initial }: { index: 0 | 1; initial: HomePage }) {
  const fromHome = (h: HomePage) => ({ title: h.galleries[index].title, photos: h.galleries[index].photos.map((p): GalleryPic => ({ pic: { photo: p.photo }, caption: p.caption })) });
  const [title, setTitle] = useState(() => fromHome(initial).title);
  const [photos, setPhotos] = useState(() => fromHome(initial).photos);
  const status = useStatus();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const input = [];
      // One at a time, so a phone on slow internet does not time out
      for (const p of photos) input.push({ caption: p.caption, ...(await toInput(p.pic, "gallery")) });
      const res = await saveGallery(index, title, input);
      if (!res.ok) throw new Error(res.error);
      forget(photos.map((p) => p.pic));
      const saved = fromHome(res.data);
      setTitle(saved.title);
      setPhotos(saved.photos);
    });
  };

  return (
    <form onSubmit={submit}>
      {/* Locked while saving, so edits made during a slow upload are not overwritten by the saved copy */}
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
      <PageTitle title={`Photo gallery, section ${index + 1}`} href="/" />
      <Label text="Section title">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={index === 0 ? "Workshops & Events" : "Community Outreach"} className="input" />
      </Label>
      {photos.length > 0 && (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {photos.map((p, i) => (
            <li key={src(p.pic)} className="space-y-1.5">
              {/* eslint-disable-next-line @next/next/no-img-element -- local preview or signed redirect */}
              <img src={src(p.pic)} alt={p.caption} className="aspect-square w-full rounded-lg object-cover ring-1 ring-[var(--line)]" />
              <input value={p.caption} onChange={(e) => setPhotos(photos.map((q, j) => (j === i ? { ...q, caption: e.target.value } : q)))} placeholder="Caption (optional)" aria-label="Caption" className="input py-1.5 text-xs" />
              <div className="flex justify-between">
                <span className="flex">
                  <button type="button" disabled={i === 0} onClick={() => setPhotos(move(photos, i, -1))} aria-label="Move earlier" className={iconBtn}>
                    <ArrowUp size={14} />
                  </button>
                  <button type="button" disabled={i === photos.length - 1} onClick={() => setPhotos(move(photos, i, 1))} aria-label="Move later" className={iconBtn}>
                    <ArrowDown size={14} />
                  </button>
                </span>
                <button type="button" onClick={() => setPhotos(photos.filter((_, j) => j !== i))} aria-label="Remove photo" className={deleteBtn}>
                  <Trash2 size={14} />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
      <label className="btn-ghost cursor-pointer">
        <ImagePlus size={16} /> Add photos
        <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => setPhotos([...photos, ...takeFiles(e).map((f) => ({ pic: withFile(f), caption: "" }))])} />
      </label>
      <p className="text-xs text-muted">The home page shows them in a slowly moving row; visitors click a photo to see it large. Up to 40 per section.</p>
      <SaveFooter state={status.state} label={`Save section ${index + 1}`} />
    </fieldset>
    </form>
  );
}

// ---------- workshops ----------

type WorkshopState = { id: string; title: string; date: string; place: string; body: string; link: string; pic: Pic };

function WorkshopsForm({ initial, view, onView }: { initial: HomePage; view: View; onView: (v: View) => void }) {
  const fromHome = (h: HomePage): WorkshopState[] => h.workshops.map(({ photo, ...w }) => ({ ...w, pic: { photo } }));
  const [list, setList] = useState(() => fromHome(initial));
  /** Index of the workshop open for editing; null shows the overview */
  const [editing, setEditing] = useState<number | null>(null);
  const status = useStatus();
  const set = (i: number, patch: Partial<WorkshopState>) => setList(list.map((w, j) => (j === i ? { ...w, ...patch } : w)));
  const remove = (i: number) => {
    if (!confirm(`Delete the workshop “${list[i].title || "untitled"}”? It is removed when you press Save.`)) return;
    setList(list.filter((_, j) => j !== i));
    setEditing(null);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const input = [];
      for (const { pic, ...w } of list) input.push({ ...w, ...(await toInput(pic, "workshop")) });
      const res = await saveWorkshops(input);
      if (!res.ok) throw new Error(res.error);
      forget(list.map((w) => w.pic));
      setList(fromHome(res.data));
      // The saved list is re-sorted by date, so the open index may now point at another workshop
      setEditing(null);
    });
  };

  const open = editing === null ? null : list[editing];

  return (
    <form onSubmit={submit}>
      {/* Locked while saving, so edits made during a slow upload are not overwritten by the saved copy */}
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
        <PageTitle title="Workshops" href="/workshops" />
        <p className="-mt-2 text-xs text-muted">Listed newest date first. The home page shows the latest 3; the Workshops page shows all. Click a workshop to edit it.</p>

        {open && editing !== null ? (
          <div className="space-y-4">
            <button type="button" onClick={() => setEditing(null)} className="btn-ghost py-1.5 text-sm">
              <ArrowLeft size={16} /> All workshops
            </button>
            <div className="space-y-3 rounded-xl border-2 border-brand-500/40 p-4">
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <Label text="Title">
                    <input value={open.title} onChange={(e) => set(editing, { title: e.target.value })} placeholder="Workshop title" className="input font-semibold" autoFocus={!open.title} />
                  </Label>
                </div>
                <button type="button" onClick={() => remove(editing)} aria-label="Delete workshop" className={`${deleteBtn} mt-6`}>
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Label text="Date">
                  <input type="date" value={open.date} onChange={(e) => set(editing, { date: e.target.value })} className="input" />
                </Label>
                <Label text="Place">
                  <input value={open.place} onChange={(e) => set(editing, { place: e.target.value })} placeholder="e.g. Seminar Hall, college name" className="input" />
                </Label>
              </div>
              <Label text="Description" hint="Leave an empty line between paragraphs. Start a line with “- ” to make a bullet point.">
                <textarea value={open.body} onChange={(e) => set(editing, { body: e.target.value })} rows={6} placeholder="What the workshop covers and who it is for." className="input resize-y" />
              </Label>
              <Label text="Link (optional)" hint="Registration form, YouTube recording or more details.">
                <input value={open.link} onChange={(e) => set(editing, { link: e.target.value })} placeholder="https://…" className="input" />
              </Label>
              <PhotoPicker pic={open.pic} label={open.title} className="h-20 w-32" onPick={(f) => set(editing, { pic: withFile(f) })} onClear={() => set(editing, { pic: { photo: "" } })} />
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setList([{ id: "", title: "", date: "", place: "", body: "", link: "", pic: { photo: "" } }, ...list]);
                  setEditing(0);
                }}
                className="btn-ghost"
              >
                <Plus size={16} /> Add a workshop
              </button>
              {list.length > 0 && <ViewToggle view={view} onChange={onView} />}
            </div>
            {list.length === 0 ? (
              <p className="rounded-xl border-2 border-dashed border-line p-8 text-center text-sm text-muted">No workshops yet. Press “Add a workshop” to write the first one.</p>
            ) : (
              <ul className={view === "grid" ? "grid gap-3 sm:grid-cols-2 xl:grid-cols-3" : "divide-y divide-[var(--line)] overflow-hidden rounded-xl border border-line"}>
                {list.map((w, i) => (
                  <li key={w.id || `new-${i}`}>
                    <WorkshopTile w={w} grid={view === "grid"} onOpen={() => setEditing(i)} />
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
        <SaveFooter state={status.state} label="Save workshops" />
      </fieldset>
    </form>
  );
}

/** One workshop in the overview: photo, title, date and place. Click to edit. */
function WorkshopTile({ w, grid, onOpen }: { w: WorkshopState; grid: boolean; onOpen: () => void }) {
  const shown = src(w.pic);
  const date = workshopDate(w.date);
  const meta = (
    <span className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted">
      <span className="inline-flex items-center gap-1">
        <CalendarDays size={13} /> {date || "No date"}
      </span>
      {w.place && (
        <span className="inline-flex min-w-0 items-center gap-1">
          <MapPin size={13} className="shrink-0" /> <span className="truncate">{w.place}</span>
        </span>
      )}
    </span>
  );
  const badge = !w.id && <span className="ml-2 rounded-md bg-amber-400/20 px-1.5 py-0.5 align-middle text-[11px] font-semibold text-amber-700 dark:text-amber-300">Not saved</span>;
  const title = <span className="font-semibold leading-snug">{w.title || <span className="italic text-muted">Untitled workshop</span>}</span>;
  const thumb = (cls: string) =>
    shown ? (
      // eslint-disable-next-line @next/next/no-img-element -- local preview or signed redirect
      <img src={shown} alt="" className={`${cls} object-cover`} />
    ) : (
      <span className={`${cls} grid place-items-center bg-black/5 text-muted dark:bg-white/5`}>
        <ImagePlus size={20} />
      </span>
    );

  if (grid) {
    return (
      <button type="button" onClick={onOpen} className="group flex h-full w-full flex-col overflow-hidden rounded-xl border border-line text-left transition hover:border-brand-500 hover:shadow-md">
        {thumb("aspect-video w-full")}
        <span className="flex flex-1 flex-col p-3">
          <span>
            {title}
            {badge}
          </span>
          {meta}
          <span className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-brand-500 group-hover:underline">
            <Pencil size={12} /> Edit
          </span>
        </span>
      </button>
    );
  }
  return (
    <button type="button" onClick={onOpen} className="group flex w-full items-center gap-3 p-3 text-left transition hover:bg-black/[0.03] dark:hover:bg-white/5">
      {thumb("h-14 w-20 shrink-0 rounded-lg")}
      <span className="min-w-0 flex-1">
        <span className="block">
          {title}
          {badge}
        </span>
        {meta}
      </span>
      <Pencil size={16} className="shrink-0 text-muted group-hover:text-brand-500" />
    </button>
  );
}

// ---------- vision & mission ----------

function VisionForm({ initial }: { initial: HomePage }) {
  const [vision, setVision] = useState(initial.vision);
  const [mission, setMission] = useState(initial.mission);
  const status = useStatus();
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const res = await saveVisionMission(vision, mission);
      if (!res.ok) throw new Error(res.error);
    });
  };
  return (
    <form onSubmit={submit}>
      {/* Locked while saving, so edits made during a slow upload are not overwritten by the saved copy */}
      <fieldset disabled={status.state.saving} className="card min-w-0 space-y-4 p-5 sm:p-6">
      <PageTitle title="Vision & Mission" href="/" />
      <p className="-mt-2 text-xs text-muted">Shown near the bottom of the home page, just before About Us. Leave both empty to hide it.</p>
      <Label text="Our Vision">
        <textarea value={vision} onChange={(e) => setVision(e.target.value)} rows={4} className="input resize-y" />
      </Label>
      <Label text="Our Mission" hint="Start a line with “- ” to make a bullet point.">
        <textarea value={mission} onChange={(e) => setMission(e.target.value)} rows={5} className="input resize-y" />
      </Label>
      <SaveFooter state={status.state} label="Save vision & mission" />
    </fieldset>
    </form>
  );
}
