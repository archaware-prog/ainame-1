"use client";

import { useOptimistic, useState, useTransition } from "react";
import { Pencil, Search, Trash2, X } from "lucide-react";
import { MaterialForm, Switch } from "./AddMaterial";
import { setUrlParams, ViewToggle, type View } from "./Sections";
import { TypeIcon } from "../ResourceRow";
import { removeResource, setResourceFlags } from "@/lib/actions";
import { useTopics } from "@/lib/store";
import { TYPE_LABEL, inTopic, placeNames, type Resource } from "@/lib/types";

type Patch = { id: string; hidden?: boolean; allowDownload?: boolean; deleted?: boolean };

export function ManageMaterials({ resources, view, onView, initialPlace }: { resources: Resource[]; view: View; onView: (v: View) => void; initialPlace?: string }) {
  const topics = useTopics();
  const [q, setQ] = useState("");
  // "all", "none", a topic slug, or "topic/sub". Kept in the address so a refresh keeps the filter.
  const [place, setPlaceState] = useState(initialPlace || "all");
  const setPlace = (p: string) => {
    setPlaceState(p);
    setUrlParams({ section: p === "all" ? null : p });
  };
  const [editing, setEditing] = useState<Resource | null>(null);
  const [error, setError] = useState("");
  const [, startTransition] = useTransition();

  // Switches and deletes show instantly; the server's answer then replaces them
  const [items, applyOptimistic] = useOptimistic(resources, (list, p: Patch) =>
    p.deleted ? list.filter((r) => r.id !== p.id) : list.map((r) => (r.id === p.id ? { ...r, ...p, hidden: p.hidden ?? r.hidden } : r)),
  );

  const change = (p: Patch, action: () => Promise<{ ok: boolean; error?: string }>) => {
    setError("");
    startTransition(async () => {
      applyOptimistic(p);
      const res = await action();
      if (!res.ok) setError(res.error ?? "That change did not save. Please try again.");
    });
  };

  const words = q.toLowerCase();
  const inPlace = (r: Resource) => {
    if (place === "all") return true;
    if (place === "none") return placeNames(r, topics).length === 0;
    const [topic, sub] = place.split("/");
    return inTopic(r, topic, sub);
  };
  const list = items.filter((r) => inPlace(r) && r.title.toLowerCase().includes(words));

  const placeLabel = (r: Resource) => {
    const names = placeNames(r, topics).map((p) => `${p.topic.name} › ${p.sub.name}`);
    return names.length ? names.join(", ") : "Not under any topic";
  };
  const metaLabel = (r: Resource) => [TYPE_LABEL[r.type], r.unit ? `Unit ${r.unit}` : "", r.meta].filter(Boolean).join(" · ");

  // The same switches and buttons in list and grid view. `labelled`: always show the word next to the switch.
  const switchLabel = (text: string, labelled: boolean) => <span className={`text-xs text-muted ${labelled ? "" : "sm:hidden"}`}>{text}</span>;
  const downloadSwitch = (r: Resource, labelled = false) => (
    <span className="flex items-center gap-2">
      {switchLabel("Download", labelled)}
      {r.type === "video" || r.type === "book" ? <span className="text-xs text-muted">n/a</span> : <Switch on={r.allowDownload} onChange={(v) => change({ id: r.id, allowDownload: v }, () => setResourceFlags(r.id, { allowDownload: v }))} label="Allow download" />}
    </span>
  );
  const visibleSwitch = (r: Resource, labelled = false) => (
    <span className="flex items-center gap-2">
      {switchLabel("Visible", labelled)}
      <Switch on={!r.hidden} onChange={(v) => change({ id: r.id, hidden: !v }, () => setResourceFlags(r.id, { hidden: !v }))} label="Visible on website" />
    </span>
  );
  const actions = (r: Resource) => (
    <>
      <button onClick={() => setEditing(r)} aria-label="Edit" className="rounded-lg p-2 text-muted transition hover:bg-brand-500/10 hover:text-brand-500">
        <Pencil size={16} />
      </button>
      <button
        onClick={() => {
          if (confirm(`Delete “${r.title}”? This cannot be undone.`)) change({ id: r.id, deleted: true }, () => removeResource(r.id));
        }}
        aria-label="Delete"
        className="rounded-lg p-2 text-muted transition hover:bg-rose-500/10 hover:text-rose-500"
      >
        <Trash2 size={16} />
      </button>
    </>
  );

  return (
    <div className="w-full">
      <h1 className="font-display text-2xl font-bold sm:text-3xl">All materials</h1>
      <p className="mt-1 text-sm text-muted">{items.length} {items.length === 1 ? "item" : "items"}. Changes show on the website straight away.</p>

      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        <label className="relative block flex-1">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find an item…" className="input pl-9" />
        </label>
        {/* Option text starts with the topic's own name, so typing its first letter jumps to it */}
        <select value={place} onChange={(e) => setPlace(e.target.value)} className="input sm:w-72" aria-label="Topic">
          <option value="all">All topics</option>
          <option value="none">Not under any topic</option>
          {topics.map((t) => (
            <optgroup key={t.slug} label={t.name}>
              <option value={t.slug}>{t.name} (all)</option>
              {t.subtopics.map((s) => (
                <option key={s.key} value={s.key}>
                  {s.name}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
        <span className="self-end sm:self-center">
          <ViewToggle view={view} onChange={onView} />
        </span>
      </div>

      {error &&<p className="mt-3 rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600 dark:text-rose-400">{error}</p>}

      {list.length > 0 && (
        <p className="mt-4 text-xs text-muted">
          Showing {list.length} of {items.length}
        </p>
      )}

      {view === "grid" && list.length > 0 ? (
        <ul className="mt-2 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((r) => (
            <li key={r.id} className={`card flex flex-col p-4 ${r.hidden ? "opacity-55" : ""}`}>
              <div className="flex items-start gap-3">
                <TypeIcon type={r.type} size={38} />
                <div className="min-w-0 flex-1">
                  <p className="line-clamp-2 text-sm font-semibold leading-snug">{r.title}</p>
                  <p className="mt-0.5 truncate text-xs text-muted">{metaLabel(r)}</p>
                </div>
              </div>
              <p className="mb-3 mt-2 line-clamp-2 text-xs text-muted">{placeLabel(r)}</p>
              <div className="mt-auto flex items-center gap-4 border-t border-line pt-3">
                {downloadSwitch(r, true)}
                {visibleSwitch(r, true)}
                <span className="ml-auto flex">{actions(r)}</span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="card mt-2 divide-y divide-[var(--line)] overflow-hidden">
          <div className="hidden grid-cols-[1fr_110px_90px_88px] gap-4 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-muted sm:grid">
            <span>Item</span>
            <span className="text-center">Download</span>
            <span className="text-center">Visible</span>
            <span />
          </div>
          {list.map((r) => (
            <div key={r.id} className={`grid grid-cols-[1fr_auto] items-center gap-x-4 gap-y-2 px-4 py-3 sm:grid-cols-[1fr_110px_90px_88px] ${r.hidden ? "opacity-55" : ""}`}>
              <div className="flex min-w-0 items-center gap-3">
                <TypeIcon type={r.type} size={34} />
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{r.title}</p>
                  <p className="truncate text-xs text-muted">{metaLabel(r)}</p>
                  <p className="truncate text-xs text-muted">{placeLabel(r)}</p>
                </div>
              </div>
              <div className="col-span-2 flex items-center gap-5 sm:contents">
                <span className="sm:flex sm:justify-center">{downloadSwitch(r)}</span>
                <span className="sm:flex sm:justify-center">{visibleSwitch(r)}</span>
                <span className="ml-auto flex sm:ml-0 sm:justify-end">{actions(r)}</span>
              </div>
            </div>
          ))}
          {list.length === 0 && <p className="p-8 text-center text-sm text-muted">{items.length ? "No items match." : "Nothing uploaded yet. Use “Add material” to publish your first file."}</p>}
        </div>
      )}

      {editing && (
        // items-start + my-auto: centred when it fits, scrolls from the top (with the close button) when it is taller than the screen
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/60 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label="Edit material" onKeyDown={(e) => e.key === "Escape" && setEditing(null)}>
          <div className="my-auto w-full max-w-2xl rounded-3xl bg-surface p-5 shadow-2xl sm:p-6">
            <div className="mb-4 flex items-center justify-between gap-3">
              <h2 className="font-display text-xl font-bold">Edit material</h2>
              <button onClick={() => setEditing(null)} aria-label="Close" className="rounded-full p-2 hover:bg-black/5 dark:hover:bg-white/10">
                <X size={18} />
              </button>
            </div>
            <MaterialForm key={editing.id} initial={editing} onDone={() => setEditing(null)} />
          </div>
        </div>
      )}
    </div>
  );
}
