"use client";

import { useState, useTransition } from "react";
import { ArrowDown, ArrowLeft, ArrowUp, Check, ChevronRight, Pencil, Plus, Trash2, X } from "lucide-react";
import { setUrlParams, ViewToggle, type View } from "./Sections";
import { createSubtopic, createTopic, editSubtopic, editTopic, removeSubtopic, removeTopic, reorderSubtopics, reorderTopics, type TopicInput } from "@/lib/actions";
import { useTopics } from "@/lib/store";
import { TOPIC_COLORS, TOPIC_ICONS, TopicIcon } from "@/lib/topic-style";
import type { Resource, Topic } from "@/lib/types";

type Act = (fn: () => Promise<{ ok: boolean; error?: string }>, after?: () => void) => void;

const iconBtn = "rounded-lg p-2 text-muted hover:bg-black/5 disabled:opacity-30 dark:hover:bg-white/10";

/** The topic cards on the home page and the sub-topics inside each. Items are tagged with sub-topics when uploading. */
export function Topics({ resources, view, onView, initialOpen }: { resources: Resource[]; view: View; onView: (v: View) => void; initialOpen?: string }) {
  const topics = useTopics();
  // The topic open for editing (its slug, kept in the address); none shows every topic as a tile
  const [openSlug, setOpenState] = useState<string | null>(initialOpen ?? null);
  const setOpen = (slug: string | null) => {
    setOpenState(slug);
    setUrlParams({ section: slug });
  };
  const openIndex = topics.findIndex((t) => t.slug === openSlug);
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();

  const act: Act = (fn, after) => {
    setError("");
    startTransition(async () => {
      const res = await fn();
      if (!res.ok) setError(res.error ?? "That change did not save. Please try again.");
      else after?.();
    });
  };

  const move = (i: number, by: -1 | 1) => {
    const order = topics.map((t) => t.slug);
    [order[i], order[i + by]] = [order[i + by], order[i]];
    act(() => reorderTopics(order));
  };

  const errorBox = error && <p className="mt-4 rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600 dark:text-rose-400">{error}</p>;

  // One topic open: its sub-topics, with a way back
  if (openIndex >= 0) {
    const t = topics[openIndex];
    return (
      <div className="w-full">
        <button type="button" onClick={() => setOpen(null)} className="btn-ghost py-1.5 text-sm">
          <ArrowLeft size={16} /> All topics
        </button>
        {errorBox}
        <div className={`mt-4 ${pending ? "opacity-70" : ""}`}>
          <TopicBlock key={t.slug} topic={t} resources={resources} pending={pending} act={act} first={openIndex === 0} last={openIndex === topics.length - 1} onMove={(by) => move(openIndex, by)} onDeleted={() => setOpen(null)} />
        </div>
      </div>
    );
  }

  const itemCount = (slug: string) => resources.filter((r) => r.subtopics.some((k) => k.startsWith(`${slug}/`))).length;

  return (
    <div className="w-full">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold sm:text-3xl">Topics</h1>
          <p className="mt-1 text-sm text-muted">These are the cards on the home page, in this order. Click a topic to edit it and its sub-topics.</p>
        </div>
        <div className="flex items-center gap-2">
          {topics.length > 0 && <ViewToggle view={view} onChange={onView} />}
          {!adding && (
            <button onClick={() => setAdding(true)} className="btn-primary">
              <Plus size={16} /> New topic
            </button>
          )}
        </div>
      </div>

      {errorBox}

      {adding && (
        <div className="card mt-5 p-4">
          <TopicForm pending={pending} onCancel={() => setAdding(false)} onSave={(input) => act(() => createTopic(input), () => setAdding(false))} />
        </div>
      )}

      {topics.length === 0 ? (
        <p className="card mt-5 p-8 text-center text-sm text-muted">No topics yet. Press “New topic” to add the first card.</p>
      ) : (
        <ul className={`mt-5 ${view === "grid" ? "grid gap-3 sm:grid-cols-2 xl:grid-cols-3" : "card divide-y divide-[var(--line)] overflow-hidden"} ${pending ? "opacity-70" : ""}`}>
          {topics.map((t, i) => {
            const subs = t.subtopics.length;
            const items = itemCount(t.slug);
            const counts = `${subs} ${subs === 1 ? "sub-topic" : "sub-topics"} · ${items} ${items === 1 ? "item" : "items"}`;
            const arrows = (
              <>
                <button disabled={pending || i === 0} onClick={() => move(i, -1)} aria-label={`Move ${t.name} earlier`} className={iconBtn}>
                  <ArrowUp size={16} />
                </button>
                <button disabled={pending || i === topics.length - 1} onClick={() => move(i, 1)} aria-label={`Move ${t.name} later`} className={iconBtn}>
                  <ArrowDown size={16} />
                </button>
              </>
            );
            return view === "grid" ? (
              <li key={t.slug} className="card flex flex-col overflow-hidden">
                <button type="button" onClick={() => setOpen(t.slug)} className="group flex flex-1 flex-col text-left">
                  <span className="flex items-center gap-3 px-4 py-4 text-white" style={{ background: t.color }}>
                    <TopicIcon icon={t.icon} size={28} strokeWidth={1.7} className="shrink-0" />
                    <span className="min-w-0 font-display text-lg font-bold leading-snug">{t.name}</span>
                  </span>
                  <span className="flex flex-1 items-center justify-between gap-2 px-4 py-3 text-xs text-muted">
                    {counts}
                    <span className="inline-flex items-center gap-1 font-semibold text-brand-500 group-hover:underline">
                      <Pencil size={12} /> Edit
                    </span>
                  </span>
                </button>
                <span className="flex justify-end border-t border-line px-2 py-1">{arrows}</span>
              </li>
            ) : (
              <li key={t.slug} className="flex items-center gap-1 pr-2">
                <button type="button" onClick={() => setOpen(t.slug)} className="group flex min-w-0 flex-1 items-center gap-3 p-3 text-left transition hover:bg-black/[0.03] dark:hover:bg-white/5">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-white" style={{ background: t.color }}>
                    <TopicIcon icon={t.icon} size={22} strokeWidth={1.8} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{t.name}</span>
                    <span className="block text-xs text-muted">{counts}</span>
                  </span>
                  <ChevronRight size={18} className="shrink-0 text-muted group-hover:text-brand-500" />
                </button>
                {arrows}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function TopicBlock({ topic, resources, pending, act, first, last, onMove, onDeleted }: { topic: Topic; resources: Resource[]; pending: boolean; act: Act; first: boolean; last: boolean; onMove: (by: -1 | 1) => void; onDeleted: () => void }) {
  const [editing, setEditing] = useState(false);
  const [newSub, setNewSub] = useState("");
  const [renaming, setRenaming] = useState<{ slug: string; name: string; youtube: string } | null>(null);
  const subs = topic.subtopics;

  const moveSub = (i: number, by: -1 | 1) => {
    const order = subs.map((s) => s.slug);
    [order[i], order[i + by]] = [order[i + by], order[i]];
    act(() => reorderSubtopics(topic.slug, order));
  };

  return (
    <div className="card overflow-hidden">
      {editing ? (
        <div className="p-4">
          <TopicForm initial={topic} pending={pending} onCancel={() => setEditing(false)} onSave={(input) => act(() => editTopic(topic.slug, input), () => setEditing(false))} />
        </div>
      ) : (
        <div className="flex items-center gap-2 px-4 py-3 text-white" style={{ background: topic.color }}>
          <TopicIcon icon={topic.icon} size={26} strokeWidth={1.7} className="shrink-0" />
          <p className="min-w-0 flex-1 truncate font-display text-lg font-bold">{topic.name}</p>
          <button disabled={pending || first} onClick={() => onMove(-1)} aria-label="Move topic up" className="rounded-lg p-2 hover:bg-white/15 disabled:opacity-30">
            <ArrowUp size={16} />
          </button>
          <button disabled={pending || last} onClick={() => onMove(1)} aria-label="Move topic down" className="rounded-lg p-2 hover:bg-white/15 disabled:opacity-30">
            <ArrowDown size={16} />
          </button>
          <button onClick={() => setEditing(true)} aria-label="Edit topic" className="rounded-lg p-2 hover:bg-white/15">
            <Pencil size={16} />
          </button>
          <button
            disabled={pending}
            onClick={() => {
              if (confirm(`Delete the topic “${topic.name}”?`)) act(() => removeTopic(topic.slug), onDeleted);
            }}
            aria-label="Delete topic"
            className="rounded-lg p-2 hover:bg-white/15"
          >
            <Trash2 size={16} />
          </button>
        </div>
      )}

      <div className="divide-y divide-[var(--line)]">
        {subs.map((s, i) => {
          const count = resources.filter((r) => r.subtopics.includes(s.key)).length;
          return (
            <div key={s.slug} className="flex items-center gap-2 py-2 pl-5 pr-4">
              {renaming?.slug === s.slug ? (
                <form
                  className="flex flex-1 flex-wrap gap-2 sm:flex-nowrap"
                  onSubmit={(e) => {
                    e.preventDefault();
                    act(
                      () => editSubtopic(topic.slug, s.slug, { name: renaming.name, youtube: renaming.youtube }),
                      () => setRenaming(null),
                    );
                  }}
                >
                  <input value={renaming.name} onChange={(e) => setRenaming({ ...renaming, name: e.target.value })} aria-label="Sub-topic name" className="input py-1.5" autoFocus />
                  <input value={renaming.youtube} onChange={(e) => setRenaming({ ...renaming, youtube: e.target.value })} aria-label="YouTube link" placeholder="YouTube link (optional)" className="input py-1.5" />
                  <button disabled={pending} aria-label="Save" className="rounded-lg p-2 text-emerald-600 hover:bg-emerald-500/10">
                    <Check size={16} />
                  </button>
                  <button type="button" onClick={() => setRenaming(null)} aria-label="Cancel" className={iconBtn}>
                    <X size={16} />
                  </button>
                </form>
              ) : (
                <>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{s.name}</p>
                    <p className="text-xs text-muted">
                      {count} {count === 1 ? "item" : "items"}
                      {s.youtube && <span className="font-semibold text-[#ff0033]"> · YouTube link added</span>}
                    </p>
                  </div>
                  <button disabled={pending || i === 0} onClick={() => moveSub(i, -1)} aria-label="Move up" className={iconBtn}>
                    <ArrowUp size={16} />
                  </button>
                  <button disabled={pending || i === subs.length - 1} onClick={() => moveSub(i, 1)} aria-label="Move down" className={iconBtn}>
                    <ArrowDown size={16} />
                  </button>
                  <button onClick={() => setRenaming({ slug: s.slug, name: s.name, youtube: s.youtube ?? "" })} aria-label="Edit name and YouTube link" title="Edit name and YouTube link" className="rounded-lg p-2 text-muted hover:bg-brand-500/10 hover:text-brand-500">
                    <Pencil size={16} />
                  </button>
                  <button
                    disabled={pending}
                    onClick={() => {
                      if (confirm(`Delete the sub-topic “${s.name}”?`)) act(() => removeSubtopic(topic.slug, s.slug));
                    }}
                    aria-label="Delete"
                    className="rounded-lg p-2 text-muted hover:bg-rose-500/10 hover:text-rose-500"
                  >
                    <Trash2 size={16} />
                  </button>
                </>
              )}
            </div>
          );
        })}
        <form
          className="flex gap-2 bg-black/[0.02] px-4 py-3 dark:bg-white/[0.03]"
          onSubmit={(e) => {
            e.preventDefault();
            act(
              () => createSubtopic(topic.slug, newSub),
              () => setNewSub(""),
            );
          }}
        >
          <input value={newSub} onChange={(e) => setNewSub(e.target.value)} placeholder="New sub-topic, e.g. 2nd Year MD" aria-label={`New sub-topic in ${topic.name}`} className="input py-2" />
          <button disabled={pending || !newSub.trim()} className="btn-primary shrink-0 disabled:opacity-60">
            <Plus size={16} /> Add
          </button>
        </form>
      </div>
    </div>
  );
}

function TopicForm({ initial, pending, onSave, onCancel }: { initial?: Topic; pending: boolean; onSave: (input: TopicInput) => void; onCancel: () => void }) {
  const [name, setName] = useState(initial?.name ?? "");
  const [icon, setIcon] = useState(initial?.icon ?? "book");
  const [color, setColor] = useState(initial?.color ?? TOPIC_COLORS[0]);

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        onSave({ name, icon, color });
      }}
    >
      <div className="flex items-center gap-3 rounded-xl px-4 py-3 text-white" style={{ background: color }}>
        <TopicIcon icon={icon} size={30} strokeWidth={1.6} />
        <span className="font-display text-lg font-bold">{name || "Topic name"}</span>
      </div>
      <div>
        <p className="mb-1.5 text-sm font-semibold">Name</p>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Community Medicine" className="input" autoFocus />
      </div>
      <div>
        <p className="mb-1.5 text-sm font-semibold">Icon</p>
        <div className="flex flex-wrap gap-2">
          {Object.entries(TOPIC_ICONS).map(([key, { icon: I, label }]) => (
            <button key={key} type="button" onClick={() => setIcon(key)} aria-label={label} aria-pressed={icon === key} title={label} className={`grid h-10 w-10 place-items-center rounded-xl transition ${icon === key ? "text-white" : "bg-black/5 text-muted hover:text-[var(--text)] dark:bg-white/10"}`} style={icon === key ? { background: color } : undefined}>
              <I size={20} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="mb-1.5 text-sm font-semibold">Colour</p>
        <div className="flex flex-wrap gap-2">
          {TOPIC_COLORS.map((c) => (
            <button key={c} type="button" onClick={() => setColor(c)} aria-label={`Colour ${c}`} aria-pressed={color === c} className={`h-9 w-9 rounded-full ring-offset-2 ring-offset-[var(--surface)] transition ${color === c ? "ring-2 ring-[var(--text)]" : ""}`} style={{ background: c }} />
          ))}
        </div>
      </div>
      <div className="flex gap-2">
        <button disabled={pending || !name.trim()} className="btn-primary disabled:opacity-60">
          <Check size={16} /> {initial ? "Save" : "Add topic"}
        </button>
        <button type="button" onClick={onCancel} className="rounded-xl px-4 py-2 text-sm font-semibold text-muted hover:bg-black/5 dark:hover:bg-white/10">
          Cancel
        </button>
      </div>
    </form>
  );
}
