"use client";

import { useState } from "react";
import { CheckCircle2, UploadCloud } from "lucide-react";
import { MAX_MB, uploadPdf } from "./upload";
import { createResource, editResource, type ResourceInput } from "@/lib/actions";
import { useTopics } from "@/lib/store";
import { TYPE_LABEL, bookUrl, isLinkType, type Resource, type ResourceType } from "@/lib/types";
import { parseVideoUrl } from "@/lib/video";

export function AddMaterial({ onDone }: { onDone: () => void }) {
  return (
    <div className="w-full">
      <h1 className="font-display text-2xl font-bold sm:text-3xl">Add material</h1>
      <p className="mt-1 text-sm text-muted">It goes live on the website as soon as you press Publish.</p>
      <div className="card mt-6 p-5 sm:p-6">
        <MaterialForm onDone={onDone} />
      </div>
    </div>
  );
}

/** Add a new item, or edit one when `initial` is given */
export function MaterialForm({ initial, onDone }: { initial?: Resource; onDone: () => void }) {
  const topics = useTopics();
  const editing = !!initial;
  const [title, setTitle] = useState(initial?.title ?? "");
  // Sub-topic keys, "topic/sub"
  const [places, setPlaces] = useState<string[]>(initial?.subtopics ?? []);
  const [type, setType] = useState<ResourceType>(initial?.type ?? "notes");
  const [unit, setUnit] = useState(initial?.unit ? String(initial.unit) : "");
  const [link, setLink] = useState(initial?.videoUrl ?? "");
  const [file, setFile] = useState<File | null>(null);
  const [allowDownload, setAllowDownload] = useState(initial?.allowDownload ?? true);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const isVideo = type === "video";
  const isBook = type === "book";
  const isLink = isLinkType(type);
  const video = isVideo && link ? parseVideoUrl(link) : null;
  const book = isBook && link ? bookUrl(link) : null;
  // Editing a PDF item without choosing a new file keeps the current one
  const hasFile = editing && !isLinkType(initial.type);

  const togglePlace = (key: string) => setPlaces(places.includes(key) ? places.filter((k) => k !== key) : [...places, key]);

  const pickFile = (f: File | undefined) => {
    setError("");
    if (!f) return setFile(null);
    if (f.type !== "application/pdf" && !/\.pdf$/i.test(f.name)) return setError("Please choose a PDF. For PowerPoint, save it as PDF first (File → Save as → PDF).");
    if (f.size > MAX_MB * 1024 * 1024) return setError(`That file is larger than ${MAX_MB} MB. Compress it first (for example at ilovepdf.com → Compress PDF).`);
    setFile(f);
    if (!title) setTitle(f.name.replace(/\.pdf$/i, ""));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!title.trim()) return setError("Please add a title.");
    if (isVideo && !video) return setError("Paste a YouTube or Instagram link.");
    if (isBook && !book) return setError("Paste the book's Amazon link (it starts with https://).");
    if (!isLink && !file && !hasFile) return setError("Please choose a PDF file.");

    setSaving(true);
    try {
      let fileId: string | undefined;
      let filePages: number | undefined;
      if (!isLink && file) {
        setProgress(0);
        ({ fileId, pages: filePages } = await uploadPdf(file, setProgress));
      }
      const input: ResourceInput = {
        title,
        subtopics: places,
        type,
        unit: unit && !isBook ? Number(unit) : undefined,
        videoUrl: isLink ? link : undefined,
        allowDownload,
        fileId,
        filePages,
      };
      const res = editing ? await editResource(initial.id, input) : await createResource(input);
      if (!res.ok) throw new Error(res.error);
      onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setSaving(false);
      setProgress(null);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <Field label="What are you adding?">
        <div className="flex flex-wrap gap-2">
          {(Object.keys(TYPE_LABEL) as ResourceType[]).map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => {
                setType(t);
                setError("");
              }}
              className={`rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${type === t ? "bg-brand-500 text-white" : "bg-black/5 text-muted hover:text-[var(--text)] dark:bg-white/10"}`}
            >
              {TYPE_LABEL[t]}
            </button>
          ))}
        </div>
      </Field>

      {isVideo ? (
        <Field label="YouTube or Instagram link">
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://youtube.com/watch?v=…  or  https://instagram.com/reel/…" className="input" />
          {link && (
            <p className={`mt-1.5 text-xs ${video ? "text-emerald-600 dark:text-emerald-400" : "text-rose-500"}`}>
              {video ? `✓ ${video.kind === "youtube" ? "YouTube video" : "Instagram post"} detected` : "This does not look like a YouTube or Instagram link."}
            </p>
          )}
          {video?.kind === "instagram" && <p className="mt-1.5 text-xs text-amber-700 dark:text-amber-300">Note: some Instagram reels (private, collab or remix posts) cannot play inside other websites. Students will see an “Open on Instagram” button.</p>}
        </Field>
      ) : isBook ? (
        <Field label="Amazon link to the book">
          <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://www.amazon.in/…" className="input" />
          {link && !book && <p className="mt-1.5 text-xs text-rose-500">This does not look like a web link. Copy it from the address bar on the book’s Amazon page.</p>}
          <p className="mt-1.5 text-xs text-muted">Students who click this book go straight to its Amazon page in a new tab.</p>
        </Field>
      ) : (
        <Field label={hasFile ? "PDF file (optional: choose one only to replace the current file)" : "PDF file"}>
          <label className="flex cursor-pointer flex-col items-center gap-2 rounded-2xl border-2 border-dashed border-line px-4 py-8 text-center transition hover:border-brand-500/50 hover:bg-brand-500/5">
            {file ? <CheckCircle2 className="text-emerald-500" size={28} /> : <UploadCloud className="text-brand-500" size={28} />}
            <span className="text-sm font-semibold">{file ? file.name : hasFile ? "Keep the current file, or choose a new PDF" : "Choose a PDF to upload"}</span>
            <span className="text-xs text-muted">Notes, slides (saved as PDF), question banks or papers · up to {MAX_MB} MB</span>
            <input type="file" accept="application/pdf,.pdf" className="sr-only" onChange={(e) => pickFile(e.target.files?.[0])} />
          </label>
        </Field>
      )}

      <div className={`grid gap-4 ${isBook ? "" : "sm:grid-cols-[1fr_140px]"}`}>
        <Field label="Title">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={isBook ? "e.g. Community Medicine Made Easy" : "e.g. Unit 3: Epidemiology basics"} className="input" />
        </Field>
        {!isBook && (
        <Field label="Unit (optional)">
          <select value={unit} onChange={(e) => setUnit(e.target.value)} className="input">
            <option value="">None</option>
            {[1, 2, 3, 4, 5, 6, 7, 8].map((u) => (
              <option key={u} value={u}>
                Unit {u}
              </option>
            ))}
          </select>
        </Field>
        )}
      </div>

      <Field label="Show under which topic? (tick all that apply)">
        {topics.every((t) => !t.subtopics.length) ? (
          <p className="text-sm text-muted">No sub-topics yet. Add them in the “Topics” tab, then come back here.</p>
        ) : (
          <div className="space-y-3">
            {topics
              .filter((t) => t.subtopics.length)
              .map((t) => (
                <div key={t.slug}>
                  <p className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider" style={{ color: t.color }}>
                    {t.name}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {t.subtopics.map((s) => (
                      <Chip key={s.key} on={places.includes(s.key)} onClick={() => togglePlace(s.key)}>
                        {s.name}
                      </Chip>
                    ))}
                  </div>
                </div>
              ))}
          </div>
        )}
        {places.length === 0 && <p className="mt-1.5 text-xs text-amber-700 dark:text-amber-300">Nothing ticked: students will only find it through search, not on the topic cards.</p>}
      </Field>

      {!isLink && (
        <label className="flex items-center justify-between gap-4 rounded-2xl bg-black/[0.03] p-4 dark:bg-white/5">
          <span>
            <span className="block text-sm font-semibold">Allow students to download</span>
            <span className="text-xs text-muted">Turn off to make this file “view only”.</span>
          </span>
          <Switch on={allowDownload} onChange={setAllowDownload} />
        </label>
      )}

      {error && <p className="rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600 dark:text-rose-400">{error}</p>}

      {progress !== null && (
        <div className="h-2 overflow-hidden rounded-full bg-black/5 dark:bg-white/10" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full rounded-full bg-linear-to-r from-brand-500 to-pop-500 transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}

      <button disabled={saving} className="btn-primary w-full justify-center py-3 disabled:opacity-60">
        {saving ? (progress !== null && progress < 100 ? `Uploading… ${progress}%` : "Saving…") : editing ? "Save changes" : "Publish"}
      </button>
    </form>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className={`rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${on ? "bg-brand-500 text-white" : "bg-black/5 text-muted hover:text-[var(--text)] dark:bg-white/10"}`}>
      {on ? "✓ " : ""}
      {children}
    </button>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-1.5 text-sm font-semibold">{label}</p>
      {children}
    </div>
  );
}

export function Switch({ on, onChange, label, disabled }: { on: boolean; onChange: (v: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)} className={`relative h-6 w-11 shrink-0 rounded-full transition disabled:opacity-50 ${on ? "bg-brand-500" : "bg-black/15 dark:bg-white/20"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
    </button>
  );
}
