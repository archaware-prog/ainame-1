"use client";

import Link from "next/link";
import { useState } from "react";
import { Logo } from "../Chrome";
import { PasswordInput } from "../PasswordInput";
import { signIn } from "@/lib/actions";

export function Login({ problem }: { problem: string | null }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    // On success the server refreshes this page, which then shows the owner panel
    const res = await signIn(email, password);
    if (!res.ok) {
      setError(res.error);
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-linear-to-br from-brand-500 via-[#8b3dff] to-pop-500 p-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl bg-surface p-7 shadow-2xl">
        <Logo />
        <h1 className="mt-5 font-display text-2xl font-bold">Owner login</h1>
        <p className="mt-1 text-sm text-muted">Only the content owner logs in. Students never need an account.</p>
        {problem && <p className="mt-4 rounded-xl bg-amber-100 px-3 py-2 text-xs text-amber-900 dark:bg-amber-400/15 dark:text-amber-200">{problem}</p>}
        <label className="mt-5 block text-sm font-semibold">
          Email
          <input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} className="input mt-1.5" required autoFocus />
        </label>
        <label className="mt-3 block text-sm font-semibold">
          Password
          <PasswordInput autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1.5" required />
        </label>
        {error && <p className="mt-2 text-sm text-rose-500">{error}</p>}
        <button disabled={busy} className="btn-primary mt-5 w-full justify-center py-3 disabled:opacity-60">
          {busy ? "Logging in…" : "Log in"}
        </button>
        <p className="mt-3 text-center text-xs text-muted">Forgot the password? Reset it in Supabase → Authentication → Users.</p>
        <Link href="/" className="mt-4 block text-center text-sm text-muted hover:text-brand-500">
          ← Back to website
        </Link>
      </form>
    </div>
  );
}
