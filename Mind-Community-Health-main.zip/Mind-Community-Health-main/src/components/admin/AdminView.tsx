"use client";

import Link from "next/link";
import { useState } from "react";
import { BarChart3, ExternalLink, FileText, FolderOpen, House, LayoutGrid, LogOut, Plus } from "lucide-react";
import { Logo } from "../Chrome";
import { AddMaterial } from "./AddMaterial";
import { HomeContent } from "./HomeContent";
import { SitePages } from "./SitePages";
import { Dashboard } from "./Dashboard";
import { ManageMaterials } from "./ManageMaterials";
import { Topics } from "./Topics";
import { setUrlParams, toView, type View } from "./Sections";
import { signOut } from "@/lib/actions";
import type { Resource, SitePages as SitePagesData } from "@/lib/types";

const TABS = [
  { id: "dashboard", label: "Dashboard", icon: BarChart3 },
  { id: "add", label: "Add material", icon: Plus },
  { id: "manage", label: "All materials", icon: FolderOpen },
  { id: "topics", label: "Topics", icon: LayoutGrid },
  { id: "home", label: "Home page", icon: House },
  { id: "pages", label: "About & Contact", icon: FileText },
] as const;
type Tab = (typeof TABS)[number]["id"];

/** Where the owner was before a refresh, read from the address (?tab=…&section=…&view=…) */
export type AdminAt = { tab?: string; section?: string; view?: string };
type Props = { email: string; resources: Resource[]; pages: SitePagesData; loadError: string | null; problem: string | null; at?: AdminAt };

const toTab = (v: string | undefined): Tab => TABS.find((t) => t.id === v)?.id ?? "dashboard";

/** Shown only after the server has checked the owner's login (src/app/admin/page.tsx) */
export function AdminView({ email, resources, pages, loadError, problem, at = {} }: Props) {
  const [tab, setTabState] = useState<Tab>(() => toTab(at.tab));
  const [view, setView] = useState<View>(() => toView(at.view));
  // A section from the address applies only to the tab first shown, until the owner switches tabs
  const [fresh, setFresh] = useState(true);
  const section = (t: Tab) => (fresh && t === toTab(at.tab) ? at.section : undefined);
  const setTab = (t: Tab) => {
    setTabState(t);
    setFresh(false);
    setUrlParams({ tab: t === "dashboard" ? null : t, section: null });
  };
  const logout = () => void signOut();

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* On desktop the sidebar stays put while the page scrolls */}
      <aside className="flex shrink-0 flex-col gap-1 bg-ink-900 p-4 text-white md:sticky md:top-0 md:h-screen md:w-60 md:overflow-y-auto md:p-5">
        <div className="flex items-center justify-between md:mb-6 md:block">
          <span className="[&_a]:text-white">
            <Logo />
          </span>
          <p className="hidden truncate text-xs text-white/50 md:block">{email}</p>
        </div>
        <nav className="-mx-1 mt-3 flex gap-1 overflow-x-auto md:mx-0 md:mt-0 md:flex-col">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex shrink-0 items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium transition ${tab === t.id ? "bg-brand-500 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
              <t.icon size={17} /> {t.label}
            </button>
          ))}
        </nav>
        <div className="mt-auto hidden flex-col gap-1 pt-6 md:flex">
          <Link href="/" target="_blank" className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-white/70 hover:bg-white/10 hover:text-white">
            <ExternalLink size={17} /> View website
          </Link>
          <button onClick={logout} className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-white/70 hover:bg-white/10 hover:text-white">
            <LogOut size={17} /> Log out
          </button>
        </div>
      </aside>
      <div className="min-w-0 flex-1 p-4 sm:p-8">
        {(problem || loadError) && <p className="mb-5 rounded-xl bg-amber-100 px-4 py-3 text-sm text-amber-900 dark:bg-amber-400/15 dark:text-amber-200">{problem ?? loadError}</p>}
        {tab === "dashboard" && <Dashboard resources={resources} />}
        {tab === "add" && <AddMaterial onDone={() => setTab("manage")} />}
        {tab === "manage" && <ManageMaterials resources={resources} view={view} onView={setView} initialPlace={section("manage")} />}
        {tab === "topics" && <Topics resources={resources} view={view} onView={setView} initialOpen={section("topics")} />}
        {tab === "home" && <HomeContent home={pages.home} view={view} onView={setView} initialSection={section("home")} />}
        {tab === "pages" && <SitePages pages={pages} initialSection={section("pages")} />}
        <div className="mt-8 flex gap-4 text-sm md:hidden">
          <Link href="/" className="text-brand-500">
            View website
          </Link>
          <button onClick={logout} className="text-muted">
            Log out
          </button>
        </div>
      </div>
    </div>
  );
}
