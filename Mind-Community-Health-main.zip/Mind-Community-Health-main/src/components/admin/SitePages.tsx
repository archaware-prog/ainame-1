"use client";

import Link from "next/link";
import { useState } from "react";
import { ExternalLink, ImagePlus, Info, Phone, Trash2 } from "lucide-react";
import { SectionTabs, setUrlParams } from "./Sections";
import { uploadPhoto } from "./upload";
import { saveAbout, saveContact } from "@/lib/actions";
import type { ContactPage, SitePages as Pages } from "@/lib/types";

const SECTIONS = [
  { id: "about", label: "About Us", icon: Info },
  { id: "contact", label: "Contact Us", icon: Phone },
] as const;
type Section = (typeof SECTIONS)[number]["id"];

/** Owner edits the About Us and Contact Us pages */
export function SitePages({ pages, initialSection }: { pages: Pages; initialSection?: string }) {
  const [section, setSectionState] = useState<Section>(() => SECTIONS.find((s) => s.id === initialSection)?.id ?? "about");
  const setSection = (s: Section) => {
    setSectionState(s);
    setUrlParams({ section: s });
  };
  // Both forms stay mounted and are only hidden, so unsaved edits survive switching
  return (
    <div className="w-full space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold sm:text-3xl">About &amp; Contact pages</h1>
        <p className="mt-1 text-sm text-muted">Pick a page to edit. What you save here shows on the website straight away.</p>
      </div>
      <SectionTabs items={SECTIONS} value={section} onChange={setSection} label="Pages" />
      <div className={section === "about" ? "" : "hidden"}>
        <AboutForm initial={pages.about} />
      </div>
      <div className={section === "contact" ? "" : "hidden"}>
        <ContactForm initial={pages.contact} />
      </div>
    </div>
  );
}

function AboutForm({ initial }: { initial: Pages["about"] }) {
  const [heading, setHeading] = useState(initial.heading);
  const [body, setBody] = useState(initial.body);
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [removePhoto, setRemovePhoto] = useState(false);
  const status = useStatus();

  const currentPhoto = initial.photoVersion && !removePhoto ? `/api/site-photo?v=${initial.photoVersion}` : "";
  const shown = preview || currentPhoto;

  const pick = (f: File | undefined) => {
    if (!f) return;
    if (preview) URL.revokeObjectURL(preview);
    setPhoto(f);
    setPreview(URL.createObjectURL(f));
    setRemovePhoto(false);
  };
  const clearPhoto = () => {
    if (preview) URL.revokeObjectURL(preview);
    setPhoto(null);
    setPreview("");
    setRemovePhoto(true);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const newPhoto = photo ? await uploadPhoto(photo) : undefined;
      const res = await saveAbout({ heading, body, newPhoto, removePhoto: removePhoto && !photo });
      if (!res.ok) throw new Error(res.error);
      setPhoto(null);
    });
  };

  return (
    <form onSubmit={submit} className="card space-y-4 p-5 sm:p-6">
      <PageTitle title="About Us" href="/about" />
      <Label text="Heading">
        <input value={heading} onChange={(e) => setHeading(e.target.value)} placeholder="About Us" className="input" />
      </Label>
      <Label text="Text" hint="Leave an empty line between paragraphs. Start a line with “- ” to make a bullet point.">
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={10} placeholder={"Who you are, what this site is for, and who it helps.\n\n- Free notes and PPTs\n- Videos for every unit"} className="input resize-y leading-relaxed" />
      </Label>

      <div>
        <p className="mb-1.5 text-sm font-semibold">Photo (optional)</p>
        <div className="flex flex-wrap items-center gap-4">
          {shown ? (
            // eslint-disable-next-line @next/next/no-img-element -- local preview or signed redirect
            <img src={shown} alt="About page photo" className="h-28 w-40 rounded-xl object-cover ring-1 ring-[var(--line)]" />
          ) : (
            <span className="grid h-28 w-40 place-items-center rounded-xl border-2 border-dashed border-line text-xs text-muted">No photo</span>
          )}
          <div className="flex flex-col gap-2">
            <label className="btn-ghost cursor-pointer">
              <ImagePlus size={16} /> {shown ? "Change photo" : "Choose photo"}
              <input type="file" accept="image/*" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} />
            </label>
            {shown && (
              <button type="button" onClick={clearPhoto} className="btn-ghost text-rose-600 dark:text-rose-400">
                <Trash2 size={16} /> Remove photo
              </button>
            )}
          </div>
        </div>
      </div>

      <SaveFooter state={status.state} label="Save About Us" />
    </form>
  );
}

const CONTACT_FIELDS: { key: keyof ContactPage; label: string; placeholder: string; hint?: string }[] = [
  { key: "email", label: "Email", placeholder: "name@example.com" },
  { key: "phone", label: "Phone", placeholder: "+91 98765 43210" },
  { key: "whatsapp", label: "WhatsApp number", placeholder: "+91 98765 43210", hint: "Students tap it to open a WhatsApp chat." },
  { key: "timings", label: "Timings", placeholder: "Mon–Sat, 10 am to 5 pm" },
  { key: "youtube", label: "YouTube channel link", placeholder: "https://youtube.com/@yourchannel" },
  { key: "instagram", label: "Instagram link", placeholder: "https://instagram.com/yourname" },
];

function ContactForm({ initial }: { initial: ContactPage }) {
  const [form, setForm] = useState(initial);
  const set = (k: keyof ContactPage, v: string) => setForm({ ...form, [k]: v });
  const status = useStatus();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    status.run(async () => {
      const res = await saveContact(form);
      if (!res.ok) throw new Error(res.error);
    });
  };

  return (
    <form onSubmit={submit} className="card space-y-4 p-5 sm:p-6">
      <PageTitle title="Contact Us" href="/contact" />
      <p className="-mt-2 text-xs text-muted">Leave a box empty to hide it on the website.</p>
      <Label text="Heading">
        <input value={form.heading} onChange={(e) => set("heading", e.target.value)} placeholder="Contact Us" className="input" />
      </Label>
      <Label text="Short message (optional)">
        <textarea value={form.note} onChange={(e) => set("note", e.target.value)} rows={3} placeholder="e.g. For doubts about any topic, message on WhatsApp." className="input resize-y" />
      </Label>
      <div className="grid gap-4 sm:grid-cols-2">
        {CONTACT_FIELDS.map((f) => (
          <Label key={f.key} text={f.label} hint={f.hint}>
            <input value={form[f.key]} onChange={(e) => set(f.key, e.target.value)} placeholder={f.placeholder} className="input" />
          </Label>
        ))}
      </div>
      <Label text="Address">
        <textarea value={form.address} onChange={(e) => set("address", e.target.value)} rows={3} placeholder="Building, street, city, PIN" className="input resize-y" />
      </Label>
      <SaveFooter state={status.state} label="Save Contact Us" />
    </form>
  );
}

// ---------- small shared pieces ----------

export function PageTitle({ title, href }: { title: string; href: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <h2 className="font-display text-xl font-bold">{title}</h2>
      <Link href={href} target="_blank" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-500 hover:underline">
        View page <ExternalLink size={14} />
      </Link>
    </div>
  );
}

export function Label({ text, hint, children }: { text: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold">{text}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}

type SaveState = { saving: boolean; error: string; saved: boolean };

/** Saving / saved / error state for one form */
export function useStatus() {
  const [state, setState] = useState<SaveState>({ saving: false, error: "", saved: false });
  const run = async (fn: () => Promise<void>) => {
    setState({ saving: true, error: "", saved: false });
    try {
      await fn();
      setState({ saving: false, error: "", saved: true });
    } catch (err) {
      setState({ saving: false, error: err instanceof Error ? err.message : "Something went wrong. Please try again.", saved: false });
    }
  };
  return { state, run };
}

export function SaveFooter({ state, label }: { state: SaveState; label: string }) {
  return (
    <div className="space-y-3">
      {state.error && <p className="rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600 dark:text-rose-400">{state.error}</p>}
      {state.saved && <p className="rounded-xl bg-emerald-500/10 px-3 py-2 text-sm text-emerald-700 dark:text-emerald-300">Saved. The website now shows this.</p>}
      <button disabled={state.saving} className="btn-primary w-full justify-center py-3 disabled:opacity-60">
        {state.saving ? "Saving…" : label}
      </button>
    </div>
  );
}
