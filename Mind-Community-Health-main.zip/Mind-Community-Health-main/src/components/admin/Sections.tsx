"use client";

import { LayoutGrid, List, type LucideIcon } from "lucide-react";

// Shared pieces for the owner panel: section buttons, the list/grid switch, and remembering
// where the owner was. The open tab, section and view are written into the web address
// (/admin?tab=topics&section=…&view=grid), so a page refresh comes back to the same place.

export type View = "list" | "grid";
export const toView = (v: string | undefined): View => (v === "grid" ? "grid" : "list");

/** Rewrites the address bar without reloading or adding a Back-button step. `null` removes a value. */
export function setUrlParams(params: Record<string, string | null>) {
  const url = new URL(window.location.href);
  for (const [k, v] of Object.entries(params)) {
    if (v === null) url.searchParams.delete(k);
    else url.searchParams.set(k, v);
  }
  window.history.replaceState(window.history.state, "", url);
}

export function SectionTabs<T extends string>({ items, value, onChange, label }: { items: readonly { id: T; label: string; icon: LucideIcon }[]; value: T; onChange: (id: T) => void; label: string }) {
  return (
    <nav aria-label={label} className="sticky top-0 z-10 -mx-4 flex gap-1.5 overflow-x-auto bg-[var(--bg)] px-4 py-2 sm:-mx-8 sm:px-8">
      {items.map((s) => (
        <button
          key={s.id}
          type="button"
          onClick={() => onChange(s.id)}
          aria-current={value === s.id ? "page" : undefined}
          className={`flex shrink-0 items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-medium transition ${value === s.id ? "border-brand-500 bg-brand-500 text-white" : "border-line bg-surface text-muted hover:text-[var(--text)]"}`}
        >
          <s.icon size={16} /> {s.label}
        </button>
      ))}
    </nav>
  );
}

/** List / grid switch. The choice is kept in the address, shared by every tab. */
export function ViewToggle({ view, onChange }: { view: View; onChange: (v: View) => void }) {
  const pick = (v: View) => {
    onChange(v);
    setUrlParams({ view: v === "list" ? null : v });
  };
  return (
    <div role="group" aria-label="View" className="flex shrink-0 rounded-xl border border-line bg-surface p-0.5">
      {(
        [
          ["list", List, "List view"],
          ["grid", LayoutGrid, "Grid view"],
        ] as const
      ).map(([v, Icon, label]) => (
        <button key={v} type="button" onClick={() => pick(v)} aria-label={label} aria-pressed={view === v} title={label} className={`rounded-lg p-1.5 transition ${view === v ? "bg-brand-500 text-white" : "text-muted hover:text-[var(--text)]"}`}>
          <Icon size={16} />
        </button>
      ))}
    </div>
  );
}
