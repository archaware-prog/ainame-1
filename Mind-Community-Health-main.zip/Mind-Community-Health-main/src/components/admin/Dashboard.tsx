"use client";

import { useEffect, useState } from "react";
import { Download, Eye, Monitor, PlayCircle, Smartphone, Tablet, Users } from "lucide-react";
import { getStats } from "@/lib/actions";
import { useTopics } from "@/lib/store";
import { inTopic, type Resource, type StatRange, type Stats, type Topic } from "@/lib/types";

const RANGES: StatRange[] = [7, 30, 90];
const fmt = (n: number) => n.toLocaleString("en-IN");

export function Dashboard({ resources }: { resources: Resource[] }) {
  const topics = useTopics();
  const [days, setDays] = useState<StatRange>(30);
  const [result, setResult] = useState<{ days: StatRange; stats: Stats | null; error: string } | null>(null);

  useEffect(() => {
    let live = true;
    getStats(days).then((res) => {
      if (live) setResult({ days, stats: res.ok ? res.data : null, error: res.ok ? "" : res.error });
    });
    return () => {
      live = false;
    };
  }, [days]);

  const loading = result?.days !== days;
  const stats = result?.stats;

  return (
    <div className="w-full">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-2xl font-bold sm:text-3xl">Welcome back 👋</h1>
        <div className="flex rounded-xl bg-black/5 p-1 dark:bg-white/10" role="group" aria-label="Date range">
          {RANGES.map((d) => (
            <button key={d} onClick={() => setDays(d)} className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition ${days === d ? "bg-surface shadow" : "text-muted"}`}>
              {d} days
            </button>
          ))}
        </div>
      </div>

      {result?.error && <p className="mt-4 rounded-xl bg-rose-500/10 px-3 py-2 text-sm text-rose-600 dark:text-rose-400">{result.error}</p>}

      <div className={`transition-opacity ${loading ? "opacity-50" : ""}`}>
        <StatsBody stats={stats ?? null} resources={resources} topics={topics} />
      </div>
      <p className="mt-4 text-xs text-muted">Counts start from launch day. Full watch time and likes for videos stay in YouTube Studio and Instagram Insights.</p>
    </div>
  );
}

function StatsBody({ stats, resources, topics }: { stats: Stats | null; resources: Resource[]; topics: Topic[] }) {
  const t = stats?.totals ?? { visits: 0, views: 0, downloads: 0, plays: 0 };
  const cards = [
    { label: "Visits", value: t.visits, icon: Users, cls: "from-brand-500 to-pop-500" },
    { label: "Files viewed", value: t.views, icon: Eye, cls: "from-orange-400 to-rose-500" },
    { label: "Downloads", value: t.downloads, icon: Download, cls: "from-emerald-400 to-teal-600" },
    { label: "Video plays (on site)", value: t.plays, icon: PlayCircle, cls: "from-[#ff0033] to-pink-500" },
  ];

  const usesOf = (id: string) => {
    const b = stats?.byResource[id];
    return b ? b.views + b.plays + b.downloads : 0;
  };
  const top = resources
    .map((r) => ({ r, n: usesOf(r.id) }))
    .filter((x) => x.n > 0)
    .sort((a, b) => b.n - a.n)
    .slice(0, 6);
  const maxTop = top[0]?.n || 1;

  const byTopic = topics
    .map((t) => ({ t, n: resources.filter((r) => inTopic(r, t.slug)).reduce((a, r) => a + usesOf(r.id), 0) }))
    .sort((a, b) => b.n - a.n);
  const maxTopic = byTopic[0]?.n || 1;

  const daily = stats?.daily ?? [];
  const maxDay = Math.max(1, ...daily.map((d) => d.n));
  const dev = stats?.devices ?? { mobile: 0, tablet: 0, desktop: 0 };
  const devTotal = dev.mobile + dev.tablet + dev.desktop || 1;

  return (
    <>
      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="card p-4">
            <span className={`grid h-9 w-9 place-items-center rounded-xl bg-linear-to-br text-white ${c.cls}`}>
              <c.icon size={18} />
            </span>
            <p className="mt-3 font-display text-2xl font-bold">{fmt(c.value)}</p>
            <p className="text-xs text-muted">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="card mt-4 p-5">
        <h2 className="font-display font-bold">📈 Visits per day</h2>
        <div className="mt-4 flex h-32 items-end gap-[2px]" aria-label="Visits per day chart">
          {daily.map((d) => (
            <div key={d.day} title={`${d.day}: ${fmt(d.n)} visits`} className="flex-1 rounded-t bg-linear-to-t from-brand-500 to-pop-500" style={{ height: `${Math.max(2, (d.n / maxDay) * 100)}%`, opacity: d.n ? 1 : 0.25 }} />
          ))}
        </div>
        {daily.length > 0 && (
          <div className="mt-1 flex justify-between text-[11px] text-muted">
            <span>{daily[0].day}</span>
            <span>Today</span>
          </div>
        )}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <h2 className="font-display font-bold">⭐ Most popular</h2>
          {top.length === 0 && <p className="mt-4 text-sm text-muted">No views in this period yet.</p>}
          <ul className="mt-4 space-y-3">
            {top.map(({ r, n }) => (
              <li key={r.id} className="text-sm">
                <div className="flex justify-between gap-3">
                  <span className="truncate">{r.title}</span>
                  <span className="shrink-0 text-muted">{fmt(n)}</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-black/5 dark:bg-white/10">
                  <div className="h-full rounded-full bg-linear-to-r from-brand-500 to-pop-500" style={{ width: `${(n / maxTop) * 100}%` }} />
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-5">
          <h2 className="font-display font-bold">📱 Devices</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {[
              { label: "Phone", n: dev.mobile, icon: Smartphone },
              { label: "Tablet", n: dev.tablet, icon: Tablet },
              { label: "Computer", n: dev.desktop, icon: Monitor },
            ].map((d) => (
              <li key={d.label} className="flex items-center gap-3">
                <d.icon size={18} className="text-muted" />
                <span className="flex-1">{d.label}</span>
                <span className="font-semibold">{Math.round((d.n / devTotal) * 100)}%</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="card mt-4 p-5">
        <h2 className="font-display font-bold">📚 Views by topic</h2>
        <ul className="mt-4 grid gap-x-8 gap-y-3 sm:grid-cols-2">
          {byTopic.map(({ t, n }) => (
            <li key={t.slug} className="text-sm">
              <div className="flex justify-between gap-3">
                <span>{t.name}</span>
                <span className="text-muted">{fmt(n)}</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-black/5 dark:bg-white/10">
                <div className="h-full rounded-full" style={{ width: `${(n / maxTopic) * 100}%`, background: t.color }} />
              </div>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}
