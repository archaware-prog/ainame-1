"use client";

import Image from "next/image";
import Link from "next/link";
import Form from "next/form";
import { useState } from "react";
import { HeroSlideshow } from "./home/HeroSlideshow";
import { NewsTicker } from "./home/NewsTicker";
import { StatsStrip } from "./home/StatsStrip";
import { Apple, ArrowRight, Brain, ChevronDown, ChevronRight, PersonStanding, Play, Search, Sprout, Users, type LucideIcon } from "lucide-react";
import { AboutSection, PhotoGallery, VisionMission, WorkshopsSection, YoutubeLink } from "./HomeExtras";
import { TypeIcon } from "./ResourceRow";
import { useViewer } from "./Viewer";
import { SITE } from "@/lib/site";
import { useResources, useTopics } from "@/lib/store";
import { TopicIcon, topicVars } from "@/lib/topic-style";
import { TYPE_LABEL, inTopic, placeNames, type Resource, type Topic } from "@/lib/types";
import { parseVideoUrl, youtubeThumb } from "@/lib/video";

const CHIPS = [
  { label: "Notes", type: "notes" },
  { label: "PPTs", type: "slides" },
  { label: "Videos", type: "video" },
  { label: "Question Banks", type: "qbank" },
  { label: "Previous Papers", type: "paper" },
];

export function HomeView() {
  const resources = useResources();
  const latest = resources.slice(0, 8);
  const videos = resources.filter((r) => r.type === "video").slice(0, 4);

  return (
    <>
      <HeroSlideshow />
      <NewsTicker />
      <div className="px-4 lg:px-8">
        <TopicCards />

        <Form action="/explore" className="mt-6 xl:hidden">
          <label className="relative block">
            <Search size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input name="q" placeholder="Search notes, PPTs, videos…" aria-label="Search resources" className="input py-3 pl-10" />
          </label>
        </Form>

        <div className="mt-6 flex flex-wrap gap-2">
          {CHIPS.map((c) => (
            <Link key={c.type} href={`/explore?type=${c.type}`} className="rounded-full border border-line bg-surface px-3.5 py-1.5 text-xs font-semibold text-navy-800 transition hover:border-brand-500 hover:text-brand-500 dark:text-white">
              {c.label}
            </Link>
          ))}
        </div>

        <StatsStrip chips={CHIPS} />
        <HomeSections latest={latest} videos={videos} />
        <PhotoGallery />
        <WorkshopsSection />
        <VisionMission />
        <AboutSection />
      </div>
      <TipsStrip />
    </>
  );
}

function HomeSections({ latest, videos }: { latest: Resource[]; videos: Resource[] }) {
  return (
    <>
      {/* New this week */}
      <div className="reveal">
      <SectionTitle title="Latest material" href={latest.length ? "/explore" : undefined} />
      {latest.length ? (
        <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 [scrollbar-width:none]">
          {latest.map((r) => (
            <FreshCard key={r.id} r={r} />
          ))}
        </div>
      ) : (
        <p className="card p-8 text-center text-sm text-muted">New material is on its way. Check back soon!</p>
      )}
      </div>

      {/* Videos */}
      {videos.length > 0 && (
        <div className="reveal">
          <SectionTitle title="Watch & learn" href="/explore?type=video" />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {videos.map((r) => (
              <VideoCard key={r.id} r={r} />
            ))}
          </div>
        </div>
      )}
    </>
  );
}

// ---------- hero, category cards and bottom strip (from the client's reference design) ----------

/** The owner's topic cards. Each one opens a drop-down of its sub-topics when clicked. */
function TopicCards() {
  const topics = useTopics();
  if (!topics.length) return null;
  return (
    <section aria-label="Topics" className="mt-8 grid items-start gap-4 sm:grid-cols-2 lg:grid-cols-5">
      {topics.map((t) => (
        <TopicCard key={t.slug} topic={t} />
      ))}
    </section>
  );
}

function TopicCard({ topic }: { topic: Topic }) {
  const resources = useResources();
  const [open, setOpen] = useState(false);
  const listId = `topic-${topic.slug}`;
  return (
    <div className="reveal reveal-card">
    <div className="topic-card overflow-hidden rounded-2xl shadow-sm ring-1 ring-black/5 transition duration-200 hover:-translate-y-1 hover:shadow-xl dark:ring-white/10" style={topicVars(topic.color)}>
      {/* Icon and arrow on top, name below at full width: five cards in a row leave ~150px each on a laptop */}
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls={listId} className="flex min-h-32 w-full flex-col gap-3 bg-[var(--card)] px-4 py-4 text-left text-white">
        <span className="flex w-full items-center justify-between">
          <span className="topic-icon inline-flex"><TopicIcon icon={topic.icon} size={32} strokeWidth={1.6} /></span>
          <ChevronDown size={20} className={`transition ${open ? "rotate-180" : ""}`} />
        </span>
        <span className="font-display text-lg font-bold leading-tight hyphens-auto">{topic.name}</span>
      </button>
      {open && (
        <ul id={listId} className="divide-y divide-black/5 bg-[var(--tint)] px-3 py-1 dark:divide-white/10 dark:bg-surface">
          {topic.subtopics.map((s) => {
            const n = resources.filter((r) => r.subtopics.includes(s.key)).length;
            return (
              <li key={s.slug}>
                <div className="flex items-center">
                  <Link href={`/topics/${topic.slug}/${s.slug}`} className="group flex min-w-0 flex-1 items-center gap-2 px-1.5 py-2.5 text-sm font-medium text-navy-900 dark:text-white">
                    <span className="min-w-0 flex-1 leading-snug group-hover:underline">{s.name}</span>
                    {n > 0 && <span className="text-xs text-muted">{n}</span>}
                    <ChevronRight size={16} className="shrink-0 text-[var(--card)] transition group-hover:translate-x-0.5" />
                  </Link>
                  {s.youtube && <YoutubeLink href={s.youtube} label={`${s.name} on YouTube`} />}
                </div>
              </li>
            );
          })}
          <li>
            <Link href={`/topics/${topic.slug}`} className="flex items-center gap-1 px-1.5 py-2.5 text-xs font-semibold text-[var(--card)] hover:underline">
              {topic.subtopics.length ? "See everything" : "Open"} ({resources.filter((r) => inTopic(r, topic.slug)).length}) <ArrowRight size={13} />
            </Link>
          </li>
        </ul>
      )}
    </div>
    </div>
  );
}

const TIPS: { label: string; icon: LucideIcon; color: string }[] = [
  { label: "Be Active", icon: PersonStanding, color: "text-brand-500" },
  { label: "Eat Healthy", icon: Apple, color: "text-orange-500" },
  { label: "Manage Stress", icon: Brain, color: "text-brand-500" },
  { label: "Support Others", icon: Users, color: "text-brand-500" },
  { label: "Protect Environment", icon: Sprout, color: "text-leaf-600" },
];

function TipsStrip() {
  return (
    <section className="reveal mt-14 px-4 lg:px-8">
      <div className="relative flex items-center overflow-hidden rounded-2xl bg-linear-to-r from-[#eef5fb] via-[#f4f9f6] to-[#eef6ea] ring-1 ring-black/5 dark:from-[#12223a] dark:via-[#13253a] dark:to-[#142a2a] dark:ring-white/10">
        <Image src="/home/strip-globe.webp" alt="" width={270} height={172} className="hidden h-36 w-auto shrink-0 mask-r-from-60% mask-r-to-100% md:block dark:opacity-80" />
        <div className="flex-1 px-4 py-6 text-center">
          <p className="font-display text-xl font-bold italic text-navy-900 sm:text-2xl xl:text-3xl dark:text-white">{SITE.motto}</p>
          <div className="mx-auto mt-2 h-0.5 w-2/3 bg-linear-to-r from-transparent via-leaf-600 to-transparent" />
          <ul className="mt-4 grid grid-cols-3 gap-y-4 sm:grid-cols-5 sm:divide-x sm:divide-navy-800/20 dark:sm:divide-white/15">
            {TIPS.map((t) => (
              <li key={t.label} className="tip-item flex flex-col items-center gap-1.5 px-2">
                <t.icon size={30} strokeWidth={1.8} className={`tip-icon ${t.color}`} />
                <span className="text-xs font-medium text-navy-900 sm:text-sm dark:text-white">{t.label}</span>
              </li>
            ))}
          </ul>
        </div>
        <Image src="/home/strip-town.webp" alt="" width={356} height={172} className="hidden h-36 w-auto shrink-0 self-end mask-l-from-60% mask-l-to-100% mask-t-from-70% lg:block dark:opacity-80" />
      </div>
    </section>
  );
}

function SectionTitle({ title, href }: { title: string; href?: string }) {
  return (
    <div className="mb-3 mt-12 flex items-end justify-between">
      <h2 className="font-display text-2xl font-bold tracking-tight text-navy-900 sm:text-3xl dark:text-white">{title}</h2>
      {href && (
        <Link href={href} className="text-sm font-semibold text-brand-500 hover:underline">
          See all
        </Link>
      )}
    </div>
  );
}

const FRESH_BG: Record<Resource["type"], string> = {
  notes: "from-rose-400 to-orange-400",
  slides: "from-orange-400 to-amber-400",
  qbank: "from-violet-500 to-indigo-500",
  paper: "from-sky-400 to-blue-500",
  video: "from-[#ff0033] to-pink-500",
  book: "from-amber-400 to-yellow-500",
};

function FreshCard({ r }: { r: Resource }) {
  const { open } = useViewer();
  const place = placeNames(r, useTopics())[0];
  return (
    <button onClick={() => open(r)} className={`flex h-36 w-44 shrink-0 snap-start flex-col justify-between rounded-2xl bg-linear-to-br p-3.5 text-left text-white shadow-lg shadow-black/5 transition duration-200 hover:-translate-y-1.5 hover:shadow-xl ${FRESH_BG[r.type]}`}>
      <span className="text-[10px] font-bold uppercase tracking-wider opacity-90">{TYPE_LABEL[r.type]}</span>
      <span>
        <span className="line-clamp-3 font-display text-sm font-bold leading-snug">{r.title}</span>
        <span className="mt-1 block truncate text-[11px] opacity-85">{place?.sub.name}</span>
      </span>
    </button>
  );
}

export function VideoCard({ r }: { r: Resource }) {
  const { open } = useViewer();
  const v = r.videoUrl ? parseVideoUrl(r.videoUrl) : null;
  return (
    <button onClick={() => open(r)} className="card lift group overflow-hidden text-left">
      <div className="relative aspect-video bg-ink-800">
        {v?.kind === "youtube" ? (
          // eslint-disable-next-line @next/next/no-img-element -- remote thumbnail, no need for next/image config in the demo
          <img src={youtubeThumb(v.id)} alt="" className="h-full w-full object-cover transition group-hover:scale-105" loading="lazy" />
        ) : (
          <div className="grid h-full place-items-center bg-linear-to-br from-[#f58529] via-[#dd2a7b] to-[#8134af] text-sm font-bold text-white">Instagram Reel</div>
        )}
        <span className="absolute inset-0 grid place-items-center bg-black/10 transition group-hover:bg-black/25">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-white/95 text-[#ff0033] shadow-lg transition group-hover:scale-110">
            <Play size={20} fill="currentColor" />
          </span>
        </span>
      </div>
      <div className="flex items-start gap-2.5 p-3">
        <TypeIcon type="video" size={28} />
        <p className="line-clamp-2 text-sm font-semibold leading-snug">{r.title}</p>
      </div>
    </button>
  );
}
