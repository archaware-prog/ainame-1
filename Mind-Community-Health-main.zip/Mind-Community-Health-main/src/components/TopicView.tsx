"use client";

import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { YoutubeMark } from "./HomeExtras";
import { UnitResources } from "./ResourceList";
import { useResources, useTopics } from "@/lib/store";
import { TopicIcon, topicVars } from "@/lib/topic-style";
import { inTopic } from "@/lib/types";

/**
 * One topic (all its material) or one sub-topic inside it.
 * Students see: sub-topic chips → Notes / PPT / Videos… tabs → unit picker → the items.
 */
export function TopicView({ topicSlug, subSlug }: { topicSlug: string; subSlug?: string }) {
  const topic = useTopics().find((t) => t.slug === topicSlug);
  const resources = useResources();
  if (!topic) return null;
  const sub = topic.subtopics.find((s) => s.slug === subSlug);
  const all = resources.filter((r) => inTopic(r, topic.slug, sub?.slug));

  const chip = (active: boolean) => `shrink-0 rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${active ? "bg-[var(--card)] text-white" : "bg-surface text-navy-800 ring-1 ring-[var(--line)] hover:ring-[var(--card)] dark:text-white"}`;

  return (
    <div className="px-4 lg:px-8" style={topicVars(topic.color)}>
      <nav aria-label="Breadcrumb" className="mt-6 flex items-center gap-1 text-xs text-muted">
        <Link href="/" className="hover:text-brand-500">
          Home
        </Link>
        <ChevronRight size={12} />
        <Link href={`/topics/${topic.slug}`} className="hover:text-brand-500">
          {topic.name}
        </Link>
        {sub && (
          <>
            <ChevronRight size={12} />
            <span>{sub.name}</span>
          </>
        )}
      </nav>

      <div className="mt-3 flex items-center gap-4">
        <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[var(--card)] text-white shadow-lg">
          <TopicIcon icon={topic.icon} size={30} strokeWidth={1.6} />
        </span>
        <div className="min-w-0">
          <h1 className="font-display text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl dark:text-white">{sub ? sub.name : topic.name}</h1>
          <p className="mt-0.5 text-sm text-muted">
            {sub && <span className="font-semibold text-[var(--card)]">{topic.name} · </span>}
            {all.length} {all.length === 1 ? "item" : "items"}: notes, PPTs, question banks, papers and videos.
          </p>
        </div>
      </div>

      {sub?.youtube && (
        <a href={sub.youtube} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-surface px-4 py-2.5 text-sm font-semibold text-navy-900 shadow-sm ring-1 ring-[var(--line)] transition hover:ring-[#ff0033] dark:text-white">
          <YoutubeMark /> Watch {sub.name} on YouTube
        </a>
      )}

      {topic.subtopics.length > 0 && (
        <div className="-mx-4 mt-5 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none]">
          <Link href={`/topics/${topic.slug}`} className={chip(!sub)}>
            All
          </Link>
          {topic.subtopics.map((s) => (
            <Link key={s.slug} href={`/topics/${topic.slug}/${s.slug}`} className={chip(s.slug === sub?.slug)}>
              {s.name}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-5">
        {/* key: reset the tabs when moving between sub-topics */}
        <UnitResources key={sub?.slug ?? "_all"} all={all} />
      </div>
    </div>
  );
}
