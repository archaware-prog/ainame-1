"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { usePathname } from "next/navigation";
import { Download, ExternalLink, Share2, X } from "lucide-react";
import { track, useResources } from "@/lib/store";
import { parseVideoUrl } from "@/lib/video";
import type { Resource } from "@/lib/types";

type ViewerCtx = { open: (r: Resource) => void };
const Ctx = createContext<ViewerCtx>({ open: () => {} });
const noopSubscribe = () => () => {};

export const useViewer = () => useContext(Ctx);

/** Link that opens one item directly, used by the Share button */
export function shareLink(r: Resource) {
  return `${window.location.origin}/item/${r.id}`;
}

export async function shareResource(r: Resource) {
  const url = shareLink(r);
  const text = `${r.title}: free study material`;
  if (navigator.share) {
    try {
      await navigator.share({ title: r.title, text, url });
      return;
    } catch {
      // cancelled: fall through to WhatsApp
    }
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`, "_blank", "noopener");
}

export function ViewerProvider({ children }: { children: React.ReactNode }) {
  const [opened, setOpened] = useState<Resource | null>(null);
  const [deepDismissed, setDeepDismissed] = useState(false);
  const resources = useResources();

  // A shared link (/item/<id>, or the older ?open=<id>) opens that item straight away
  const path = usePathname();
  const queryId = useSyncExternalStore(
    noopSubscribe,
    () => new URLSearchParams(window.location.search).get("open"),
    () => null,
  );
  const deepId = path.startsWith("/item/") ? path.slice(6) : queryId;
  const deep = !deepDismissed && deepId ? (resources.find((x) => x.id === deepId && x.type !== "book") ?? null) : null;
  const current = opened ?? deep;

  // Keyboard users land back on the button that opened the viewer when it closes
  const opener = useRef<HTMLElement | null>(null);

  const open = useCallback((r: Resource) => {
    track(r.type === "video" ? "play" : "view", r.id);
    // A book is just a link to its Amazon page: open it in a new tab, no pop-up
    if (r.type === "book") {
      if (r.videoUrl) window.open(r.videoUrl, "_blank", "noopener,noreferrer");
      return;
    }
    opener.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setOpened(r);
  }, []);

  const close = useCallback(() => {
    setOpened(null);
    setDeepDismissed(true);
    opener.current?.focus();
    opener.current = null;
  }, []);

  useEffect(() => {
    if (!current) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [current, close]);

  return (
    <Ctx.Provider value={{ open }}>
      {children}
      {current &&
        (current.type === "video" ? (
          <VideoModal r={current} onClose={close} />
        ) : (
          <FileViewer key={current.id} r={current} onClose={close} />
        ))}
    </Ctx.Provider>
  );
}

function VideoModal({ r, onClose }: { r: Resource; onClose: () => void }) {
  const v = r.videoUrl ? parseVideoUrl(r.videoUrl) : null;
  const isInsta = v?.kind === "instagram";
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm" onClick={onClose} role="dialog" aria-modal="true" aria-label={r.title}>
      <div className={`w-full overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-ink-800 ${isInsta ? "max-w-sm" : "max-w-3xl"}`} onClick={(e) => e.stopPropagation()}>
        <div className="relative bg-black">
          {v ? (
            <iframe
              src={v.embedUrl}
              title={r.title}
              className={`w-full ${isInsta ? "h-[70vh] max-h-[640px] bg-white" : "aspect-video"}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          ) : (
            <p className="p-10 text-center text-white">This video link could not be read.</p>
          )}
          <button onClick={onClose} aria-label="Close" autoFocus className="absolute right-3 top-3 rounded-full bg-black/60 p-2 text-white hover:bg-black/80">
            <X size={18} />
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-3 p-4">
          <div className="min-w-0 basis-full sm:basis-auto sm:flex-1">
            <p className="font-display text-base font-bold">{r.title}</p>
            <p className="text-xs text-muted">
              {isInsta ? "If the reel does not load here, open it on Instagram." : "Plays right here, and the view still counts on YouTube."}
            </p>
          </div>
          <button onClick={() => shareResource(r)} className="btn-ghost">
            <Share2 size={15} /> Share
          </button>
          {v && (
            <a href={v.watchUrl} target="_blank" rel="noopener noreferrer" className={isInsta ? "btn-insta" : "btn-yt"}>
              Open on {isInsta ? "Instagram" : "YouTube"} <ExternalLink size={14} />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

type Pages = { pages: string[]; allowDownload: boolean };

function FileViewer({ r, onClose }: { r: Resource; onClose: () => void }) {
  // Pages arrive as signed images, so the PDF itself is never sent for "view only" files
  const [data, setData] = useState<Pages | null | undefined>(undefined);

  useEffect(() => {
    let live = true;
    fetch(`/api/files/${r.id}`)
      .then((res) => (res.ok ? (res.json() as Promise<Pages>) : null))
      .catch(() => null)
      .then((d) => live && setData(d));
    return () => {
      live = false;
    };
  }, [r.id]);

  const canDownload = data ? data.allowDownload : r.allowDownload;
  // Space kept for each page before its image arrives, so the pages do not jump while scrolling.
  // Starts as A4 portrait, then takes the real shape of the first page (slides are landscape).
  const [ratio, setRatio] = useState("1 / 1.414");

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/85 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={r.title}>
      <div className="flex items-center gap-2 bg-white px-3 py-2.5 dark:bg-ink-800 sm:px-5">
        <button onClick={onClose} aria-label="Close" autoFocus className="rounded-full p-2 hover:bg-black/5 dark:hover:bg-white/10">
          <X size={20} />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display font-bold">{r.title}</p>
          <p className="text-xs text-muted">{canDownload ? r.meta : "View only: download is turned off for this file"}</p>
        </div>
        <button onClick={() => shareResource(r)} className="btn-ghost">
          <Share2 size={15} /> <span className="hidden sm:inline">Share</span>
        </button>
        {canDownload && (
          <a href={`/api/files/${r.id}/download`} className="btn-primary">
            <Download size={15} /> <span className="hidden sm:inline">Download</span>
          </a>
        )}
      </div>
      <div className="flex-1 overflow-y-auto overscroll-contain px-2 py-3 sm:px-4 sm:py-6" onContextMenu={canDownload ? undefined : (e) => e.preventDefault()}>
        {data === undefined && <p className="p-10 text-center text-white/80">Opening…</p>}
        {data === null && <p className="p-10 text-center text-white/80">This file could not be opened. Please try again later.</p>}
        {data && (
          <div className="mx-auto flex max-w-4xl flex-col gap-3 sm:gap-4">
            {data.pages.map((src, i) => (
              <figure key={src} className="relative overflow-hidden rounded-lg bg-white shadow-xl sm:rounded-xl">
                {/* eslint-disable-next-line @next/next/no-img-element -- signed R2 page images, already resized and compressed at upload */}
                <img
                  src={src}
                  alt={`Page ${i + 1} of ${r.title}`}
                  loading={i < 2 ? "eager" : "lazy"}
                  draggable={false}
                  style={{ aspectRatio: ratio }}
                  onLoad={i === 0 ? (e) => e.currentTarget.naturalWidth && setRatio(`${e.currentTarget.naturalWidth} / ${e.currentTarget.naturalHeight}`) : undefined}
                  className="block w-full select-none object-contain"
                />
                <figcaption className="absolute bottom-2 right-2 rounded-full bg-black/55 px-2 py-0.5 text-[11px] font-semibold text-white">
                  {i + 1} / {data.pages.length}
                </figcaption>
              </figure>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
