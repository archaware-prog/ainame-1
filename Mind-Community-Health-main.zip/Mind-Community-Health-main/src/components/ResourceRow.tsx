"use client";

import { BookOpen, FileQuestion, FileText, Play, Presentation, ScrollText } from "lucide-react";
import { useViewer } from "./Viewer";
import { TYPE_LABEL, isLinkType, type Resource, type ResourceType } from "@/lib/types";
import { useTopics } from "@/lib/store";
import { placeNames } from "@/lib/types";
import { parseVideoUrl } from "@/lib/video";

const ICON: Record<ResourceType, { icon: React.ElementType; cls: string }> = {
  notes: { icon: FileText, cls: "bg-rose-500" },
  slides: { icon: Presentation, cls: "bg-orange-500" },
  qbank: { icon: FileQuestion, cls: "bg-violet-500" },
  paper: { icon: ScrollText, cls: "bg-sky-500" },
  video: { icon: Play, cls: "bg-[#ff0033]" },
  book: { icon: BookOpen, cls: "bg-amber-500" },
};

export function TypeIcon({ type, size = 40 }: { type: ResourceType; size?: number }) {
  const { icon: Icon, cls } = ICON[type];
  return (
    <span className={`grid shrink-0 place-items-center rounded-xl text-white ${cls}`} style={{ width: size, height: size }}>
      <Icon size={size * 0.45} fill={type === "video" ? "currentColor" : "none"} />
    </span>
  );
}

/** `showPlace` adds the sub-topic name, for lists that mix sub-topics (search) */
export function ResourceRow({ r, showPlace = false }: { r: Resource; showPlace?: boolean }) {
  const { open } = useViewer();
  const place = placeNames(r, useTopics())[0];
  const video = r.type === "video" && r.videoUrl ? parseVideoUrl(r.videoUrl) : null;
  const source = video?.kind === "instagram" ? "Instagram Reel" : video ? "YouTube" : r.meta;

  return (
    <button onClick={() => open(r)} className="card group flex w-full min-w-0 items-center gap-3 p-3 text-left transition hover:-translate-y-0.5 hover:border-brand-500/40 hover:shadow-lg hover:shadow-brand-500/5">
      <TypeIcon type={r.type} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold">{r.title}</p>
        <p className="mt-0.5 flex flex-wrap items-center gap-x-1.5 text-xs text-muted">
          <span>{TYPE_LABEL[r.type]}</span>
          {showPlace && place && <span>· {place.sub.name}</span>}
          {r.unit && <span>· Unit {r.unit}</span>}
          {source && <span>· {source}</span>}
          {!r.allowDownload && !isLinkType(r.type) && (
            <span className="rounded-md bg-amber-100 px-1.5 py-px text-[10px] font-semibold text-amber-800 dark:bg-amber-400/15 dark:text-amber-300">View only</span>
          )}
        </p>
      </div>
      <span className="btn-primary shrink-0 px-3 py-1.5 text-xs">{r.type === "video" ? "Play" : r.type === "book" ? "Buy on Amazon" : "View"}</span>
    </button>
  );
}
