/**
 * Turns the owner's plain text into paragraphs and bullet lists. Never renders HTML from the text.
 * A blank line starts a new paragraph; lines starting with "- " or "• " become bullet points.
 */
export function RichText({ text }: { text: string }) {
  const blocks = text
    .replace(/\r\n/g, "\n")
    .split(/\n\s*\n/)
    .map((b) => b.trim())
    .filter(Boolean);
  const isBullet = (l: string) => /^[-•]\s+/.test(l);

  return (
    <div className="space-y-4 text-base leading-relaxed text-[var(--text)]/90">
      {blocks.map((block, i) => {
        const lines = block.split("\n").map((l) => l.trim());
        if (lines.every(isBullet)) {
          return (
            <ul key={i} className="list-disc space-y-1.5 pl-5 marker:text-leaf-600">
              {lines.map((l, j) => (
                <li key={j}>{l.replace(/^[-•]\s+/, "")}</li>
              ))}
            </ul>
          );
        }
        return (
          <p key={i} className="whitespace-pre-line">
            {block}
          </p>
        );
      })}
    </div>
  );
}
