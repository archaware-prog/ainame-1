"use client";

import Image from "next/image";
import Link from "next/link";
import Form from "next/form";
import { usePathname } from "next/navigation";
import { useEffect, useState, useSyncExternalStore } from "react";
import { ChevronDown, ChevronRight, Compass, Home, Mail, Moon, Search, Sun, UserRound } from "lucide-react";
import { SITE } from "@/lib/site";
import { trackVisit, useHome, useTopics } from "@/lib/store";

const NAV = [
  { href: "/", label: "Home", icon: Home },
  { href: "/explore", label: "Explore", icon: Compass },
  { href: "/contact", label: "Contact", icon: Mail },
];

const isActive = (path: string, href: string) => (href === "/" ? path === "/" : path.startsWith(href));

export function Logo() {
  return (
    <Link href="/" className="font-display text-xl font-extrabold tracking-tight">
      Mind & Community<span className="bg-linear-to-r from-brand-500 to-pop-500 bg-clip-text text-transparent"> Health</span>
    </Link>
  );
}

export function Header() {
  const path = usePathname();
  const topics = useTopics();
  // Which drop-down was opened by a tap or click (hover and keyboard focus open it too)
  const [menu, setMenu] = useState<string | null>(null);
  if (path.startsWith("/admin")) return null;

  const menus: { label: string; href: string; items?: { href: string; label: string }[] }[] = [
    { label: "About Us", href: "/about" },
    { label: "Topics", href: "/", items: topics.map((t) => ({ href: `/topics/${t.slug}`, label: t.name })) },
    { label: "Videos", href: "/explore?type=video" },
    { label: "Workshops", href: "/workshops" },
  ];
  const tab = (active: boolean) => `flex h-full items-center gap-1 whitespace-nowrap px-4 text-sm font-medium transition ${active ? "bg-brand-500" : "hover:bg-white/10"}`;

  return (
    <>
      <header className="bg-surface">
        <div className="flex items-center gap-4 px-4 lg:px-8 py-3 sm:py-4">
          <Link href="/" className="flex min-w-0 items-center gap-3">
            <Image src="/logo.png" alt="" width={329} height={256} priority className="h-11 w-auto shrink-0 sm:h-16" />
            <span className="min-w-0">
              <span className="block font-display text-lg font-bold leading-tight text-navy-800 sm:text-3xl dark:text-white">Mind &amp; Community Health</span>
              <span className="block font-display text-[11px] italic leading-snug text-leaf-600 sm:text-lg dark:text-emerald-400">{SITE.motto}</span>
            </span>
          </Link>
          <Form action="/explore" className="ml-auto hidden w-64 xl:block">
            <label className="relative block">
              <input name="q" placeholder="Search resources…" aria-label="Search resources" className="input py-2.5 pr-9" />
              <Search size={17} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted" />
            </label>
          </Form>
          <div className="ml-auto flex shrink-0 items-center gap-2 sm:gap-4 xl:ml-0">
            <HeaderPeople />
            <ThemeToggle />
          </div>
        </div>
      </header>

      <nav aria-label="Main" className="sticky top-0 z-40 bg-navy-800 text-white shadow-md shadow-navy-900/20">
        {/* Phones: one scrolling row of plain links */}
        <div className="flex h-11 overflow-x-auto [scrollbar-width:none] md:hidden">
          <Link href="/" className={tab(path === "/")}>
            <Home size={15} /> Home
          </Link>
          {topics.map((t) => (
            <Link key={t.slug} href={`/topics/${t.slug}`} className={tab(path.startsWith(`/topics/${t.slug}`))}>
              {t.name}
            </Link>
          ))}
          <Link href="/workshops" className={tab(path.startsWith("/workshops"))}>
            Workshops
          </Link>
          <Link href="/about" className={tab(path.startsWith("/about"))}>
            About Us
          </Link>
          <Link href="/contact" className={tab(path.startsWith("/contact"))}>
            Contact Us
          </Link>
          <Link href="/admin" className={tab(false)}>
            <UserRound size={15} /> Login
          </Link>
        </div>
        {/* Larger screens: menu bar with drop-downs, like the reference design */}
        <div className="hidden h-12 px-4 lg:px-8 md:flex">
          <Link href="/" className={tab(path === "/")}>
            <Home size={15} /> Home
          </Link>
          {menus.map((m) =>
            m.items ? (
              m.items.length > 0 && (
                // Opens on hover (mouse), on keyboard focus, and on tap (tablets have no hover)
                <div
                  key={m.label}
                  className="group relative h-full"
                  onMouseLeave={() => setMenu(null)}
                  onBlur={(e) => !e.currentTarget.contains(e.relatedTarget) && setMenu(null)}
                  onKeyDown={(e) => e.key === "Escape" && setMenu(null)}
                >
                  <button type="button" aria-haspopup="true" aria-expanded={menu === m.label} onClick={() => setMenu(menu === m.label ? null : m.label)} className={tab(m.label === "Topics" && path.startsWith("/topics"))}>
                    {m.label} <ChevronDown size={14} className={`transition group-hover:rotate-180 ${menu === m.label ? "rotate-180" : ""}`} />
                  </button>
                  <div className={`absolute left-0 top-full z-50 min-w-56 rounded-b-xl bg-surface py-2 text-[var(--text)] shadow-xl shadow-navy-900/15 ring-1 ring-[var(--line)] transition group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 ${menu === m.label ? "visible translate-y-0 opacity-100" : "invisible translate-y-1 opacity-0"}`}>
                    {m.items.map((it) => (
                      <Link
                        key={it.href}
                        href={it.href}
                        onClick={(e) => {
                          // Close it, including the keyboard-focus way of keeping it open
                          setMenu(null);
                          e.currentTarget.blur();
                        }}
                        className="flex items-center justify-between gap-4 px-4 py-2 text-sm hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-white/5">
                        {it.label} <ChevronRight size={14} className="text-muted" />
                      </Link>
                    ))}
                  </div>
                </div>
              )
            ) : (
              <Link key={m.label} href={m.href} className={tab(m.href !== "/explore?type=video" && isActive(path, m.href))}>
                {m.label}
              </Link>
            ),
          )}
          <Link href="/contact" className={`ml-auto ${tab(path.startsWith("/contact"))}`}>
            Contact Us
          </Link>
          <Link href="/admin" className={tab(false)}>
            <UserRound size={15} /> Login
          </Link>
        </div>
      </nav>
    </>
  );
}

/** Passport photos and names the owner adds in the panel (Home page tab), top-right of the header */
function HeaderPeople() {
  const people = useHome().people;
  if (!people.length) return null;
  return (
    <ul aria-label="Faculty" className="flex items-start gap-1.5 sm:gap-4">
      {people.map((p, i) => (
        <li key={i} className="flex w-8 flex-col items-center text-center sm:w-24">
          {p.photo ? (
            // eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect, so next/image cannot optimise it
            <img src={p.photo} alt={p.name} className="h-10 w-8 rounded-md object-cover shadow-sm ring-1 ring-black/10 sm:h-20 sm:w-16 dark:ring-white/15" />
          ) : (
            <span className="grid h-10 w-8 place-items-center rounded-md bg-navy-800/10 text-navy-800 sm:h-20 sm:w-16 dark:bg-white/10 dark:text-white">
              <UserRound size={22} />
            </span>
          )}
          <span className="mt-1 hidden w-full text-xs font-semibold leading-tight text-navy-900 sm:line-clamp-2 dark:text-white">{p.name}</span>
          {p.title && <span className="hidden w-full text-[10px] leading-tight text-muted sm:line-clamp-2">{p.title}</span>}
        </li>
      ))}
    </ul>
  );
}

export function BottomNav() {
  const path = usePathname();
  if (path.startsWith("/admin")) return null;
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      {NAV.map((n) => {
        const active = isActive(path, n.href);
        return (
          <Link key={n.href} href={n.href} className={`flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${active ? "text-brand-500" : "text-muted"}`}>
            <n.icon size={20} strokeWidth={active ? 2.4 : 1.8} />
            {n.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function Footer() {
  const path = usePathname();
  if (path.startsWith("/admin")) return null;
  return (
    <footer className="w-full px-4 lg:px-8 pb-24 pt-10 text-xs text-muted md:pb-10">
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line pt-6">
        <p>Free study material for everyone. No sign-up needed.</p>
        <span className="flex gap-4">
          <Link href="/about" className="hover:text-brand-500">
            About Us
          </Link>
          <Link href="/contact" className="hover:text-brand-500">
            Contact Us
          </Link>
          <Link href="/admin" className="hover:text-brand-500">
            Owner login
          </Link>
        </span>
      </div>
    </footer>
  );
}

// ---------- theme ----------

const subscribeTheme = (cb: () => void) => {
  window.addEventListener("themechange", cb);
  return () => window.removeEventListener("themechange", cb);
};

export function ThemeToggle() {
  const dark = useSyncExternalStore(
    subscribeTheme,
    () => document.documentElement.classList.contains("dark"),
    () => false,
  );
  const toggle = () => {
    const next = !dark;
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("theme", next ? "dark" : "light");
    } catch {
      // ignore: theme just won't be remembered
    }
    window.dispatchEvent(new Event("themechange"));
  };
  return (
    <button onClick={toggle} aria-label={dark ? "Switch to light mode" : "Switch to dark mode"} className="ml-auto rounded-xl p-2 text-muted transition hover:bg-black/5 hover:text-[var(--text)] sm:ml-0 dark:hover:bg-white/10">
      {dark ? <Sun size={19} /> : <Moon size={19} />}
    </button>
  );
}

/** Applies the saved theme before first paint, so dark mode does not flash white. Light unless the visitor picked dark. */
export const themeScript = `try{if(localStorage.getItem('theme')==='dark')document.documentElement.classList.add('dark')}catch(e){}`;

/** Counts one visit per browser session for the owner dashboard */
export function VisitTracker() {
  useEffect(() => {
    try {
      if (sessionStorage.getItem("ec:visited")) return;
      sessionStorage.setItem("ec:visited", "1");
    } catch {
      return;
    }
    trackVisit();
  }, []);
  return null;
}
