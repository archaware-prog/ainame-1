"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { ArrowRight, ChevronLeft, ChevronRight, Pause, Play } from "lucide-react";
import { useHome } from "@/lib/store";
import type { Slide } from "@/lib/types";

const SLIDE_MS = 6000;
const SWIPE_PX = 50;

const BUILT_IN: Slide = { photo: "", heading: "", text: "", button: "", link: "" };

function subscribeMedia(cb: () => void) {
  const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
  mq.addEventListener("change", cb);
  return () => mq.removeEventListener("change", cb);
}
function useReducedMotion() {
  return useSyncExternalStore(
    subscribeMedia,
    () => window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    () => false,
  );
}
function subscribeVisibility(cb: () => void) {
  document.addEventListener("visibilitychange", cb);
  return () => document.removeEventListener("visibilitychange", cb);
}
function useTabHidden() {
  return useSyncExternalStore(
    subscribeVisibility,
    () => document.hidden,
    () => false,
  );
}

const btnClass = "inline-flex items-center gap-2 rounded-xl bg-navy-800 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-navy-900/20 transition hover:bg-navy-700 sm:text-base";

function SlideButton({ slide }: { slide: Slide }) {
  const label = slide.button || (slide.link ? "Learn more" : "Explore Our Resources");
  const link = slide.link;
  const content = (
    <>
      {label} <ArrowRight size={18} />
    </>
  );
  if (link.startsWith("https://")) {
    return (
      <a href={link} target="_blank" rel="noopener noreferrer" className={`mt-6 ${btnClass}`}>
        {content}
      </a>
    );
  }
  return (
    <Link href={link.startsWith("/") ? link : "/explore"} className={`mt-6 ${btnClass}`}>
      {content}
    </Link>
  );
}

export function HeroSlideshow() {
  const { slides: owned } = useHome();
  const slides = owned && owned.length ? owned : [BUILT_IN];
  const n = slides.length;
  const multi = n > 1;

  const [pos, setPos] = useState({ cur: 0, prev: -1 });
  // null = the visitor has not pressed play/pause: play, unless their device asks for less motion
  const [choice, setChoice] = useState<"play" | "pause" | null>(null);
  // Only keyboard focus pauses (mouse clicks on the arrows/dots focus them too, and must not stop it).
  // Hovering does not pause: the hero is under the mouse on page load, so it would never move.
  const [keyFocus, setKeyFocus] = useState(false);
  const reduced = useReducedMotion();
  const hidden = useTabHidden();
  const touchX = useRef<number | null>(null);

  const cur = pos.cur % n;
  const paused = choice ? choice === "pause" : reduced;
  const playing = multi && !paused && !keyFocus && !hidden;

  const go = useCallback((to: number) => setPos((p) => ({ cur: (to + n) % n, prev: p.cur % n })), [n]);

  useEffect(() => {
    if (!playing) return;
    const t = window.setTimeout(() => go(cur + 1), SLIDE_MS);
    return () => window.clearTimeout(t);
  }, [playing, cur, go]);

  const next = (cur + 1) % n;
  const animatedZoom = !reduced;

  return (
    <section
      aria-roledescription="carousel"
      aria-label="Highlights"
      className="relative overflow-hidden bg-[#e8f1fa]"
      onFocus={(e) => setKeyFocus(e.target.matches(":focus-visible"))}
      onBlur={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setKeyFocus(false);
      }}
      onTouchStart={(e) => {
        touchX.current = e.touches[0].clientX;
      }}
      onTouchEnd={(e) => {
        if (touchX.current === null || !multi) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        touchX.current = null;
        if (Math.abs(dx) > SWIPE_PX) go(cur + (dx < 0 ? 1 : -1));
      }}
    >
      {/* Photos, crossfading */}
      <div className="absolute inset-y-0 right-0 w-full md:w-[62%]">
        {slides.map((s, i) => {
          const zoom = animatedZoom && (i === cur || i === pos.prev % n);
          const style = zoom
            ? { animationPlayState: playing || !multi ? ("running" as const) : ("paused" as const) }
            : undefined;
          return (
            <div key={i} aria-hidden="true" className={`absolute inset-0 transition-opacity duration-1000 ease-in-out motion-reduce:transition-none ${i === cur ? "opacity-100" : "opacity-0"}`}>
              <div className={`absolute inset-0 ${zoom ? (multi ? "kenburns" : "kenburns kenburns-loop") : ""}`} style={style}>
                {s.photo ? (
                  // eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect
                  <img
                    src={s.photo}
                    alt=""
                    loading={i === 0 || i === next ? "eager" : "lazy"}
                    fetchPriority={i === 0 ? "high" : "auto"}
                    className="h-full w-full object-cover object-[60%_center]"
                  />
                ) : (
                  <Image src="/home/hero.webp" alt="" fill priority sizes="(min-width: 768px) 62vw, 100vw" className="object-cover object-[60%_center]" />
                )}
              </div>
            </div>
          );
        })}
      </div>
      {/* Fades the photo into the sky colour behind the text */}
      <div className="absolute inset-0 bg-linear-to-b from-[#e8f1fa]/95 via-[#e8f1fa]/80 to-[#e8f1fa]/20 md:bg-linear-to-r md:from-[#e8f1fa] md:from-38% md:via-[#e8f1fa]/70 md:via-48% md:to-transparent md:to-62%" />

      {/* Text: all slides share one grid cell so the hero is always as tall as the longest one */}
      <div className="relative grid px-4 lg:px-8 pb-40 pt-10 sm:pb-48 md:py-16 lg:py-20">
        {slides.map((s, i) => {
          const active = i === cur;
          const Heading = i === 0 ? "h1" : "h2";
          return (
            <div
              key={i}
              role={multi ? "group" : undefined}
              aria-roledescription={multi ? "slide" : undefined}
              aria-label={multi ? `${i + 1} of ${n}` : undefined}
              aria-hidden={active ? undefined : true}
              inert={!active}
              className={`col-start-1 row-start-1 transition-opacity duration-700 motion-reduce:transition-none ${active ? "hero-text opacity-100" : "pointer-events-none opacity-0"}`}
            >
              {/* The owner's own headings can be long: keep them on the light panel, off the photo */}
              <Heading className={`font-display text-4xl font-bold tracking-tight text-navy-900 sm:text-5xl lg:text-6xl ${s.heading ? "text-balance md:max-w-[46%]" : ""}`}>
                {s.heading || (
                  <>
                    Learn <span className="text-leaf-600">•</span> Understand <span className="text-leaf-600">•</span> Apply
                  </>
                )}
              </Heading>
              <p className="mt-3 max-w-lg text-xl leading-snug text-navy-800 sm:text-3xl">{s.text || "For a Healthier Individual and a Healthier Society"}</p>
              <div className="mt-5 h-1 w-56 rounded-full bg-linear-to-r from-leaf-600 to-transparent" />
              <SlideButton slide={s} />
            </div>
          );
        })}
      </div>

      {multi && (
        <div className="absolute inset-x-0 bottom-4 flex items-center justify-between px-4 lg:px-8">
          <div className="flex items-center gap-1 rounded-full bg-navy-900/75 p-1 text-white backdrop-blur">
            <button type="button" onClick={() => setChoice(paused ? "play" : "pause")} aria-label={paused ? "Play slideshow" : "Pause slideshow"} className="grid h-8 w-8 place-items-center rounded-full hover:bg-white/15">
              {paused ? <Play size={16} fill="currentColor" /> : <Pause size={16} fill="currentColor" />}
            </button>
            <div className="flex items-center">
              {slides.map((_, i) => (
                <button key={i} type="button" onClick={() => go(i)} aria-label={`Go to slide ${i + 1}`} aria-current={i === cur ? "true" : undefined} className="grid h-8 w-5 place-items-center">
                  <span className={`block h-2 rounded-full transition-all ${i === cur ? "w-5 bg-white" : "w-2 bg-white/50"}`} />
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button type="button" onClick={() => go(cur - 1)} aria-label="Previous slide" className="grid h-9 w-9 place-items-center rounded-full bg-navy-900/75 text-white backdrop-blur hover:bg-navy-900">
              <ChevronLeft size={20} />
            </button>
            <button type="button" onClick={() => go(cur + 1)} aria-label="Next slide" className="grid h-9 w-9 place-items-center rounded-full bg-navy-900/75 text-white backdrop-blur hover:bg-navy-900">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
