"use client";

import Link from "next/link";
import { Megaphone, Sparkles } from "lucide-react";
import { useHome, useResources } from "@/lib/store";

type Item = { key: string; text: string; href?: string };

export function NewsTicker() {
  const { notices } = useHome();
  const resources = useResources();

  const items: Item[] = [
    ...(notices ?? []).map((t, i) => ({ key: `n${i}`, text: t })),
    ...resources.slice(0, 5).map((r) => ({ key: r.id, text: `New: ${r.title}`, href: `/item/${r.id}` })),
  ];
  if (!items.length) return null;

  const chars = items.reduce((sum, it) => sum + it.text.length, 0);
  // ~8px per character plus the icon and gap
  const width = chars * 8 + items.length * 60;
  // Each copy must be wider than a big screen, or a gap shows: repeat a short list
  const reps = Math.max(1, Math.ceil(2200 / width));
  // travelled at ~70px per second
  const seconds = Math.max(20, Math.round((width * reps) / 70));
  const shown = Array.from({ length: reps }, (_, rep) => items.map((it) => ({ ...it, rep }))).flat();

  const list = (dup: boolean) => (
    <ul className="flex shrink-0 items-center" aria-hidden={dup ? true : undefined}>
      {shown.map((it) => (
        <li key={`${it.key}-${it.rep}`} aria-hidden={!dup && it.rep > 0 ? true : undefined} className="flex shrink-0 items-center gap-2 pr-10">
          {it.href ? <Sparkles size={14} className="shrink-0 text-leaf-600 brightness-150" aria-hidden="true" /> : <Megaphone size={14} className="shrink-0 text-amber-300" aria-hidden="true" />}
          {it.href ? (
            <Link href={it.href} tabIndex={dup || it.rep > 0 ? -1 : undefined} className="whitespace-nowrap text-sm hover:underline">
              {it.text}
            </Link>
          ) : (
            <span className="whitespace-nowrap text-sm">{it.text}</span>
          )}
        </li>
      ))}
    </ul>
  );

  return (
    <section aria-label="Latest updates" className="flex items-stretch bg-navy-800 text-white dark:bg-navy-900">
      <span className="relative z-10 flex shrink-0 items-center gap-1.5 bg-leaf-600 px-3 text-xs font-bold uppercase tracking-wider sm:px-4">
        <Megaphone size={14} aria-hidden="true" /> Updates
      </span>
      <div className="marquee min-w-0 flex-1 overflow-hidden py-2.5">
        <div className="marquee-track" style={{ ["--marquee-duration" as string]: `${seconds}s` }}>
          {list(false)}
          <div className="marquee-dup flex">{list(true)}</div>
        </div>
      </div>
    </section>
  );
}
