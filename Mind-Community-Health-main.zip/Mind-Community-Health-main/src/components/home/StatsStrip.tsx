"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useResources, useTopics } from "@/lib/store";

type Chip = { label: string; type: string };

const DURATION = 1200;

/** Counts from 0 to `value` once, the first time `started` turns true. Shows the final number if motion is reduced. */
function CountUp({ value, started }: { value: number; started: boolean }) {
  const [shown, setShown] = useState<number | null>(null);
  useEffect(() => {
    if (!started) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      const id = requestAnimationFrame(() => setShown(value));
      return () => cancelAnimationFrame(id);
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / DURATION);
      setShown(Math.round(value * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, value]);
  // Until the strip scrolls into view the real number is shown, so it is never stuck at 0
  if (!started) return <>{value}</>;
  if (shown !== null) return <>{shown}</>;
  return <>{window.matchMedia("(prefers-reduced-motion: reduce)").matches ? value : 0}</>;
}

export function StatsStrip({ chips }: { chips: Chip[] }) {
  const resources = useResources();
  const topics = useTopics();
  const ref = useRef<HTMLElement>(null);
  const [started, setStarted] = useState(false);

  const visible = resources.length > 0;
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setStarted(true);
          io.disconnect();
        }
      },
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [visible]);

  if (!visible) return null;

  const stats: { label: string; value: number; href?: string }[] = [
    { label: topics.length === 1 ? "Topic" : "Topics", value: topics.length, href: "/explore" },
    ...chips.map((c) => ({ label: c.label, value: resources.filter((r) => r.type === c.type).length, href: `/explore?type=${c.type}` })),
  ].filter((s) => s.value > 0);

  return (
    <section ref={ref} aria-label="Library at a glance" className="reveal mt-10">
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {stats.map((s) => (
          <li key={s.label}>
            <Link href={s.href ?? "/explore"} className="card lift flex h-full flex-col items-center justify-center px-3 py-4 text-center">
              <span className="font-display text-3xl font-bold tabular-nums text-brand-500 sm:text-4xl">
                <CountUp value={s.value} started={started} />
              </span>
              <span className="mt-1 text-xs font-semibold text-muted sm:text-sm">{s.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
