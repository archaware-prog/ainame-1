"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowRight, CalendarDays, ExternalLink, Eye, MapPin, Target, X } from "lucide-react";
import { RichText } from "./RichText";
import { SITE } from "@/lib/site";
import { useAbout, useHome } from "@/lib/store";
import type { GalleryPhoto, Workshop } from "@/lib/types";

// Owner-written parts of the home page (admin → Home page tab), in the order the client asked for:
// photo gallery, workshops, vision & mission, then About Us.

function Title({ title, href }: { title: string; href?: string }) {
  return (
    <div className="mb-4 mt-12 flex items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-2xl font-bold tracking-tight text-navy-900 sm:text-3xl dark:text-white">{title}</h2>
        <div className="mt-2 h-1 w-24 rounded-full bg-linear-to-r from-leaf-600 to-transparent" />
      </div>
      {href && (
        <Link href={href} className="shrink-0 text-sm font-semibold text-brand-500 hover:underline">
          See all
        </Link>
      )}
    </div>
  );
}

/** Small red YouTube button, e.g. next to a sub-topic */
export function YoutubeLink({ href, label }: { href: string; label: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} title="Watch on YouTube" className="shrink-0 rounded-lg p-1.5 transition hover:bg-[#ff0033]/10">
      <YoutubeMark />
    </a>
  );
}

/** The red play-button mark (lucide no longer ships brand logos) */
export function YoutubeMark({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={(size * 2) / 3} viewBox="0 0 24 16" aria-hidden="true">
      <rect width="24" height="16" rx="4" fill="#ff0033" />
      <path d="M9.5 4.5v7l6-3.5z" fill="#fff" />
    </svg>
  );
}

// ---------- photo gallery (two sections) ----------

const HOME_PHOTOS = 8;

export function PhotoGallery() {
  const { galleries } = useHome();
  const [shown, setShown] = useState<GalleryPhoto | null>(null);
  if (!galleries.some((g) => g.photos.length)) return null;
  return (
    <section aria-label="Photo gallery" className="reveal">
      <Title title="Photo Gallery" />
      <div className="space-y-8">
        {galleries.map(
          (g, i) =>
            g.photos.length > 0 && (
              <div key={i}>
                <h3 className="mb-3 font-display text-xl font-bold text-navy-800 dark:text-white">{g.title}</h3>
                {/* Drifting row; people who ask for less motion get the still grid below instead */}
                <div className="motion-reduce:hidden">
                  <PhotoRow photos={g.photos} title={g.title} onOpen={setShown} />
                </div>
                <div className="hidden motion-reduce:block">
                  <ul className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
                    {g.photos.slice(0, HOME_PHOTOS).map((p) => (
                      <li key={p.photo}>
                        <button type="button" onClick={() => setShown(p)} className="group block w-full overflow-hidden rounded-xl ring-1 ring-black/5 dark:ring-white/10">
                          {/* eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect */}
                          <img src={p.photo} alt={p.caption || g.title} loading="lazy" className="aspect-square w-full object-cover transition group-hover:scale-105" />
                        </button>
                      </li>
                    ))}
                  </ul>
                  {g.photos.length > HOME_PHOTOS && <MorePhotos photos={g.photos.slice(HOME_PHOTOS)} onOpen={setShown} title={g.title} />}
                </div>
              </div>
            ),
        )}
      </div>
      {shown && <Lightbox photo={shown} onClose={() => setShown(null)} />}
    </section>
  );
}

const DRIFT_MIN_PHOTOS = 4;

/** One full-width row of photos that drifts sideways (~35px/s) and pauses on hover or focus. */
function PhotoRow({ photos, title, onOpen }: { photos: GalleryPhoto[]; title: string; onOpen: (p: GalleryPhoto) => void }) {
  const drift = photos.length >= DRIFT_MIN_PHOTOS;
  // Each copy must be wider than a big screen (~8 photos), or a gap shows: repeat a short list
  const reps = drift ? Math.ceil(8 / photos.length) : 1;
  const shown = Array.from({ length: reps }, (_, rep) => photos.map((p) => ({ p, rep }))).flat();
  const seconds = Math.max(20, Math.round((shown.length * 290) / 35));
  const list = (dup: boolean) => (
    <ul className="flex shrink-0 gap-3 pr-3" aria-hidden={dup ? true : undefined}>
      {shown.map(({ p, rep }) => {
        const copy = dup || rep > 0;
        return (
          <li key={`${p.photo}-${rep}`} aria-hidden={!dup && copy ? true : undefined} className="shrink-0">
            <button type="button" tabIndex={copy ? -1 : undefined} onClick={() => onOpen(p)} className="group block overflow-hidden rounded-xl ring-1 ring-black/5 dark:ring-white/10">
              {/* eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect */}
              <img src={p.photo} alt={copy ? "" : p.caption || title} loading="lazy" className="aspect-[4/3] h-40 rounded-xl object-cover transition duration-300 group-hover:scale-105 sm:h-52" />
            </button>
          </li>
        );
      })}
    </ul>
  );
  if (!drift) return <div className="overflow-x-auto pb-1">{list(false)}</div>;
  return (
    <div className="marquee overflow-hidden">
      <div className="marquee-track" style={{ ["--marquee-duration" as string]: `${seconds}s` }}>
        {list(false)}
        {list(true)}
      </div>
    </div>
  );
}

function MorePhotos({ photos, onOpen, title }: { photos: GalleryPhoto[]; onOpen: (p: GalleryPhoto) => void; title: string }) {
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="mt-3 text-sm font-semibold text-brand-500 hover:underline">
        Show {photos.length} more {photos.length === 1 ? "photo" : "photos"}
      </button>
    );
  }
  return (
    <ul className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
      {photos.map((p) => (
        <li key={p.photo}>
          <button type="button" onClick={() => onOpen(p)} className="group block w-full overflow-hidden rounded-xl ring-1 ring-black/5 dark:ring-white/10">
            {/* eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect */}
            <img src={p.photo} alt={p.caption || title} loading="lazy" className="aspect-square w-full object-cover transition group-hover:scale-105" />
          </button>
        </li>
      ))}
    </ul>
  );
}

function Lightbox({ photo, onClose }: { photo: GalleryPhoto; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  // Drawn on <body>: the gallery section's scroll-in animation would otherwise trap this
  // "fixed" layer inside the section, and later sections would paint over it
  return createPortal(
    <div role="dialog" aria-modal="true" aria-label={photo.caption || "Photo"} onClick={onClose} className="fixed inset-0 z-[60] grid place-items-center bg-black/85 p-4">
      <button type="button" onClick={onClose} aria-label="Close" autoFocus className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20">
        <X size={22} />
      </button>
      <figure onClick={(e) => e.stopPropagation()} className="max-w-5xl">
        {/* eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect */}
        <img src={photo.photo} alt={photo.caption} className="max-h-[80vh] w-auto rounded-xl object-contain" />
        {photo.caption && <figcaption className="mt-3 text-center text-sm text-white/90">{photo.caption}</figcaption>}
      </figure>
    </div>,
    document.body,
  );
}

// ---------- workshops ----------

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2026-12-05" → "5 Dec 2026". Built by hand so server and browser always print the same text. */
export function workshopDate(d: string) {
  const [y, m, day] = d.split("-").map(Number);
  return y && m && day ? `${day} ${MONTHS[m - 1]} ${y}` : "";
}

export function WorkshopCard({ w, full = false }: { w: Workshop; full?: boolean }) {
  return (
    <article id={w.id} className="card flex scroll-mt-20 flex-col overflow-hidden">
      {w.photo && (
        // eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect
        <img src={w.photo} alt="" loading="lazy" className={`w-full object-cover ${full ? "max-h-96" : "aspect-video"}`} />
      )}
      <div className="flex flex-1 flex-col gap-2 p-4 sm:p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-navy-900 sm:text-xl dark:text-white">{w.title}</h3>
        {(w.date || w.place) && (
          <p className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
            {w.date && (
              <span className="inline-flex items-center gap-1.5">
                <CalendarDays size={15} /> {workshopDate(w.date)}
              </span>
            )}
            {w.place && (
              <span className="inline-flex items-center gap-1.5">
                <MapPin size={15} /> {w.place}
              </span>
            )}
          </p>
        )}
        {w.body && (full ? <RichText text={w.body} /> : <p className="line-clamp-3 whitespace-pre-line text-sm leading-relaxed text-[var(--text)]/85">{w.body}</p>)}
        <div className="mt-auto flex flex-wrap gap-3 pt-2">
          {!full && (
            <Link href={`/workshops#${w.id}`} className="inline-flex items-center gap-1 text-sm font-semibold text-brand-500 hover:underline">
              Read more <ArrowRight size={14} />
            </Link>
          )}
          {w.link && (
            <a href={w.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-500 hover:underline">
              More details <ExternalLink size={14} />
            </a>
          )}
        </div>
      </div>
    </article>
  );
}

export function WorkshopsSection() {
  const { workshops } = useHome();
  if (!workshops.length) return null;
  return (
    <section aria-label="Workshops" className="reveal">
      <Title title="Workshops" href={workshops.length > 3 ? "/workshops" : undefined} />
      <div className="grid items-start gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {workshops.slice(0, 3).map((w) => (
          <WorkshopCard key={w.id} w={w} />
        ))}
      </div>
    </section>
  );
}

// ---------- vision & mission ----------

export function VisionMission() {
  const { vision, mission } = useHome();
  if (!vision && !mission) return null;
  const items = [
    { title: "Our Vision", text: vision, icon: Eye },
    { title: "Our Mission", text: mission, icon: Target },
  ].filter((x) => x.text);
  return (
    <section aria-label="Vision and mission" className={`reveal mt-12 grid gap-4 ${items.length > 1 ? "md:grid-cols-2" : ""}`}>
      {items.map((x) => (
        <div key={x.title} className="rounded-2xl bg-linear-to-br from-[#eef5fb] to-[#eef6ea] p-5 ring-1 ring-black/5 sm:p-7 dark:from-[#12223a] dark:to-[#142a2a] dark:ring-white/10">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-navy-800 text-white">
              <x.icon size={22} />
            </span>
            <h2 className="font-display text-2xl font-bold text-navy-900 dark:text-white">{x.title}</h2>
          </div>
          <div className="mt-4">
            <RichText text={x.text} />
          </div>
        </div>
      ))}
    </section>
  );
}

// ---------- About Us (short version of /about) ----------

export function AboutSection() {
  const about = useAbout();
  return (
    <section aria-label={about.heading} className="reveal">
      <Title title={about.heading} />
      <div className={`grid items-start gap-6 ${about.photoVersion ? "md:grid-cols-[320px_1fr]" : ""}`}>
        {about.photoVersion && (
          // eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect
          <img src={`/api/site-photo?v=${about.photoVersion}`} alt="" loading="lazy" className="w-full rounded-2xl object-cover shadow-lg ring-1 ring-black/5" />
        )}
        <div>
          {/* A short preview: long text fades out; the full text is on /about */}
          <div className="max-h-80 overflow-hidden mask-b-from-75%">
            {about.body ? (
              <RichText text={about.body} />
            ) : (
              <p className="text-base leading-relaxed text-muted">{SITE.name} is a free place for students to find notes, PPTs, question banks, previous papers and videos. No sign-up needed.</p>
            )}
          </div>
          <Link href="/about" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-navy-800 px-5 py-3 text-sm font-semibold text-white transition hover:bg-navy-700">
            Read more about us <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </section>
  );
}
