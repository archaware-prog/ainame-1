"use server";

import { refresh, updateTag } from "next/cache";
import { headers } from "next/headers";
import { CATALOG_TAG, RESOURCE_COLUMNS, toResource, type ResourceRow } from "./server/catalog";
import { hasR2 } from "./server/env";
import { homePhotoKeys, photoLink, toHome, type AboutRow, type HomeRow } from "./server/pages";
import { PHOTO_KINDS, deleteFile, deletePhoto, inspectUpload, photoExists, signPhotoUpload, signUpload, type PhotoKind } from "./server/r2";
import { adminDb, authClient, currentOwner } from "./server/supabase";
import { parseVideoUrl } from "./video";
import { TOPIC_COLORS, TOPIC_ICONS } from "./topic-style";
import { TYPE_LABEL, bookUrl, isLinkType, type ContactPage, type HomePage, type Resource, type ResourceType, type StatRange, type Stats } from "./types";

// Every owner action checks the login first, then writes with the secret key.
// Actions return { ok, error } instead of throwing, because thrown messages are hidden in production.

export type Result<T = null> = { ok: true; data: T } | { ok: false; error: string };

const ok = <T>(data: T): Result<T> => ({ ok: true, data });
const fail = (error: string): Result<never> => ({ ok: false, error });

async function ownerDb() {
  const db = adminDb();
  if (!db) throw new Error("The website is not connected to the database yet.");
  if (!(await currentOwner())) throw new Error("Your login has expired. Please log in again.");
  return db;
}

async function run<T>(fn: () => Promise<T>): Promise<Result<T>> {
  try {
    return ok(await fn());
  } catch (e) {
    return fail(e instanceof Error ? e.message : "Something went wrong. Please try again.");
  }
}

function changed() {
  updateTag(CATALOG_TAG);
  refresh();
}

// ---------- login ----------

// Brute-force guard: after MAX_TRIES wrong logins from one internet address, that address must wait
// LOCK_MINUTES. Kept in the login_attempts table so it holds across all of Vercel's servers.
const MAX_TRIES = 5;
const LOCK_MINUTES = 15;
const WRONG = "That email or password is not right.";

async function visitorIp() {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] || h.get("x-real-ip") || "unknown").trim().slice(0, 64);
}

export async function signIn(email: string, password: string): Promise<Result> {
  const db = adminDb();
  if (!db) return fail("The website is not connected to the database yet.");
  const ip = await visitorIp();
  const since = new Date(Date.now() - LOCK_MINUTES * 60_000).toISOString();

  // If the table is missing (schema.sql not re-run yet) the count fails and login works as before
  const { count } = await db.from("login_attempts").select("id", { count: "exact", head: true }).eq("ip", ip).gte("at", since);
  if ((count ?? 0) >= MAX_TRIES) return fail(`Too many wrong tries. Please wait ${LOCK_MINUTES} minutes and try again.`);

  const sb = await authClient();
  const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password });
  // A real account that is not the owner gets the same answer as a wrong password, so it reveals nothing
  const owner = !error && (await currentOwner());
  if (!owner) {
    if (!error) await sb.auth.signOut();
    await db.from("login_attempts").insert({ ip });
    // Old rows are useless after the lock window; tidy them while we are here
    await db.from("login_attempts").delete().lt("at", new Date(Date.now() - 24 * 60 * 60_000).toISOString());
    // A short pause makes guessing slower without bothering a real person
    await new Promise((r) => setTimeout(r, 800));
    return fail(WRONG);
  }
  await db.from("login_attempts").delete().eq("ip", ip);
  refresh();
  return ok(null);
}

export async function signOut(): Promise<Result> {
  const sb = await authClient();
  await sb.auth.signOut();
  refresh();
  return ok(null);
}

// ---------- material ----------

export type ResourceInput = {
  title: string;
  /** Sub-topic keys ("topic/sub") it shows under */
  subtopics: string[];
  type: ResourceType;
  unit?: number;
  videoUrl?: string;
  allowDownload: boolean;
  /** R2 folder of a freshly uploaded PDF and its page images (new item, or a replacement file) */
  fileId?: string;
  /** Page count of that upload */
  filePages?: number;
};

function clean(input: ResourceInput) {
  const title = input.title.trim();
  if (!title) throw new Error("Please add a title.");
  if (!(input.type in TYPE_LABEL)) throw new Error("Unknown material type.");
  const unit = input.unit && Number.isInteger(input.unit) && input.unit >= 1 && input.unit <= 20 ? input.unit : null;
  const isVideo = input.type === "video";
  const video = isVideo ? parseVideoUrl(input.videoUrl ?? "") : null;
  if (isVideo && !video) throw new Error("Paste a YouTube or Instagram link.");
  const book = input.type === "book" ? bookUrl(input.videoUrl ?? "") : null;
  if (input.type === "book" && !book) throw new Error("Paste the book's Amazon link (it starts with https://).");
  return {
    title,
    subtopics: [...new Set(input.subtopics.filter((k) => typeof k === "string" && /^[a-z0-9-]+\/[a-z0-9-]+$/.test(k)))],
    type: input.type,
    unit,
    video_url: video ? input.videoUrl!.trim() : book,
    allow_download: isLinkType(input.type) ? false : input.allowDownload,
  };
}

/** Signed links for uploading one PDF and its page images from the browser straight to R2 */
export async function startUpload(fileName: string, pages: number) {
  return run(async () => {
    await ownerDb();
    if (!hasR2()) throw new Error("File storage (Cloudflare R2) is not connected yet.");
    return signUpload(fileName, pages);
  });
}

export async function listAllResources(): Promise<Result<Resource[]>> {
  return run(async () => {
    const db = await ownerDb();
    const { data, error } = await db.from("resources").select(RESOURCE_COLUMNS).order("added_at", { ascending: false });
    if (error) throw new Error(error.code === "42703" ? NEEDS_SCHEMA : error.message);
    return (data as ResourceRow[]).map(toResource);
  });
}

export async function createResource(input: ResourceInput): Promise<Result<Resource>> {
  return run(async () => {
    const db = await ownerDb();
    const row = clean(input);
    let file = { file_id: null as string | null, file_pages: null as number | null, file_bytes: null as number | null };
    if (!isLinkType(row.type)) {
      if (!input.fileId) throw new Error("Please choose a PDF file.");
      const info = await inspectUpload(input.fileId, input.filePages ?? 0);
      file = { file_id: input.fileId, file_pages: info.pages, file_bytes: info.bytes };
    }
    const { data, error } = await db.from("resources").insert({ ...row, ...file }).select(RESOURCE_COLUMNS).single();
    if (error) {
      if (file.file_id) await deleteFile(file.file_id, file.file_pages ?? 1);
      throw new Error(error.message);
    }
    changed();
    return toResource(data as ResourceRow);
  });
}

export async function editResource(id: string, input: ResourceInput): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const row = clean(input);
    const { data: old, error: readError } = await db.from("resources").select("file_id,file_pages").eq("id", id).single();
    if (readError) throw new Error("That item no longer exists.");

    const patch: Record<string, unknown> = { ...row };
    if (isLinkType(row.type)) Object.assign(patch, { file_id: null, file_pages: null, file_bytes: null });
    else if (input.fileId && input.fileId !== old.file_id) {
      const info = await inspectUpload(input.fileId, input.filePages ?? 0);
      Object.assign(patch, { file_id: input.fileId, file_pages: info.pages, file_bytes: info.bytes });
    } else if (!old.file_id) throw new Error("Please choose a PDF file.");

    const { error } = await db.from("resources").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    // Remove the old PDF once the item points at its replacement (or became a video)
    if (old.file_id && patch.file_id !== undefined && patch.file_id !== old.file_id) await deleteFile(old.file_id, old.file_pages ?? 1);
    changed();
    return null;
  });
}

export async function setResourceFlags(id: string, flags: { hidden?: boolean; allowDownload?: boolean }): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const patch: Record<string, boolean> = {};
    if (flags.hidden !== undefined) patch.hidden = flags.hidden;
    if (flags.allowDownload !== undefined) patch.allow_download = flags.allowDownload;
    const { error } = await db.from("resources").update(patch).eq("id", id);
    if (error) throw new Error(error.message);
    changed();
    return null;
  });
}

export async function removeResource(id: string): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const { data, error } = await db.from("resources").delete().eq("id", id).select("file_id,file_pages").single();
    if (error) throw new Error(error.message);
    // Refresh the public site first: the row is already gone, even if deleting the file below fails
    changed();
    if (data.file_id) await deleteFile(data.file_id, data.file_pages ?? 1);
    return null;
  });
}

// ---------- topics and sub-topics ----------

const NEEDS_SCHEMA = "The database needs updating first: run supabase/schema.sql again in the Supabase SQL Editor.";

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 50);

const dbError = (error: { code?: string; message: string }, duplicate: string) =>
  new Error(error.code === "23505" ? duplicate : error.code === "PGRST205" || error.code === "42P01" ? NEEDS_SCHEMA : error.message);

export type TopicInput = { name: string; icon: string; color: string };

function cleanTopic(input: TopicInput) {
  const name = input.name.trim().slice(0, 80);
  if (!name) throw new Error("Please give the topic a name.");
  return {
    name,
    icon: input.icon in TOPIC_ICONS ? input.icon : "book",
    color: TOPIC_COLORS.includes(input.color) ? input.color : TOPIC_COLORS[0],
  };
}

async function nextPosition(db: Awaited<ReturnType<typeof ownerDb>>, table: "topics" | "subtopics", topic?: string) {
  let q = db.from(table).select("position").order("position", { ascending: false }).limit(1);
  if (topic) q = q.eq("topic_slug", topic);
  const { data } = await q;
  return (data?.[0]?.position ?? 0) + 1;
}

/** Saves a new order: the list of slugs, top first. Sub-topics are ordered within their topic. */
async function saveOrder(table: "topics" | "subtopics", slugs: string[], topic?: string): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const results = await Promise.all(
      slugs.map((slug, i) => {
        const q = db.from(table).update({ position: i + 1 }).eq("slug", slug);
        return topic ? q.eq("topic_slug", topic) : q;
      }),
    );
    const failed = results.find((r) => r.error);
    if (failed?.error) throw new Error(failed.error.message);
    changed();
    return null;
  });
}

export async function createTopic(input: TopicInput): Promise<Result<string>> {
  return run(async () => {
    const db = await ownerDb();
    const t = cleanTopic(input);
    const slug = slugify(t.name);
    if (!slug) throw new Error("Use some letters or numbers in the name.");
    const { error } = await db.from("topics").insert({ ...t, slug, position: await nextPosition(db, "topics") });
    if (error) throw dbError(error, "A topic with this name already exists.");
    changed();
    return slug;
  });
}

/** Renaming keeps the web address (slug), so links and tagged items keep working */
export async function editTopic(slug: string, input: TopicInput): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const { error } = await db.from("topics").update(cleanTopic(input)).eq("slug", slug);
    if (error) throw dbError(error, "");
    changed();
    return null;
  });
}

export async function reorderTopics(slugs: string[]): Promise<Result> {
  return saveOrder("topics", slugs);
}

export async function removeTopic(slug: string): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const { count } = await db.from("subtopics").select("slug", { count: "exact", head: true }).eq("topic_slug", slug);
    if (count) throw new Error(`This topic still has ${count} ${count === 1 ? "sub-topic" : "sub-topics"}. Delete them first.`);
    const { error } = await db.from("topics").delete().eq("slug", slug);
    if (error) throw dbError(error, "");
    changed();
    return null;
  });
}

export async function createSubtopic(topic: string, name: string): Promise<Result<string>> {
  return run(async () => {
    const db = await ownerDb();
    const clean = name.trim().slice(0, 80);
    if (!clean) throw new Error("Please give the sub-topic a name.");
    const slug = slugify(clean);
    if (!slug) throw new Error("Use some letters or numbers in the name.");
    const { error } = await db.from("subtopics").insert({ topic_slug: topic, slug, name: clean, position: await nextPosition(db, "subtopics", topic) });
    if (error) throw dbError(error, "This topic already has a sub-topic with that name.");
    changed();
    return slug;
  });
}

export async function renameSubtopic(topic: string, slug: string, name: string): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const clean = name.trim().slice(0, 80);
    if (!clean) throw new Error("Please give the sub-topic a name.");
    const { error } = await db.from("subtopics").update({ name: clean }).eq("topic_slug", topic).eq("slug", slug);
    if (error) throw dbError(error, "");
    changed();
    return null;
  });
}

/** Is this a YouTube link (video, playlist, channel or short)? */
const isYoutube = (url: string) => /^https:\/\/(www\.|m\.)?(youtube\.com|youtu\.be)\/\S+$/i.test(url);

/** Name and YouTube link of a sub-topic. Renaming keeps the web address. An empty link removes it. */
export async function editSubtopic(topic: string, slug: string, input: { name: string; youtube: string }): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const name = input.name.trim().slice(0, 80);
    if (!name) throw new Error("Please give the sub-topic a name.");
    const youtube = input.youtube.trim().slice(0, 300);
    if (youtube && !isYoutube(youtube)) throw new Error("The YouTube link should look like https://youtube.com/… or https://youtu.be/…");
    const { error } = await db.from("subtopics").update({ name, youtube_url: youtube || null }).eq("topic_slug", topic).eq("slug", slug);
    if (error) throw error.code === "PGRST204" || error.code === "42703" ? new Error(NEEDS_SCHEMA) : dbError(error, "");
    changed();
    return null;
  });
}

export async function reorderSubtopics(topic: string, slugs: string[]): Promise<Result> {
  return saveOrder("subtopics", slugs, topic);
}

export async function removeSubtopic(topic: string, slug: string): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const { count } = await db.from("resources").select("id", { count: "exact", head: true }).contains("subtopics", [`${topic}/${slug}`]);
    if (count) throw new Error(`${count} ${count === 1 ? "item is" : "items are"} still under this sub-topic. Edit them first.`);
    const { error } = await db.from("subtopics").delete().eq("topic_slug", topic).eq("slug", slug);
    if (error) throw dbError(error, "");
    changed();
    return null;
  });
}

// ---------- About Us and Contact Us ----------

/** Upload link for a new site photo (About Us by default; header people, gallery, workshops) */
export async function startPhotoUpload(kind: PhotoKind = "about"): Promise<Result<{ key: string; url: string }>> {
  return run(async () => {
    await ownerDb();
    if (!hasR2()) throw new Error("File storage (Cloudflare R2) is not connected yet.");
    return signPhotoUpload(PHOTO_KINDS.includes(kind) ? kind : "about");
  });
}

const limit = (s: unknown, max: number) => (typeof s === "string" ? s.trim().slice(0, max) : "");

export type AboutInput = {
  heading: string;
  body: string;
  /** R2 key of a photo just uploaded with startPhotoUpload */
  newPhoto?: string;
  removePhoto?: boolean;
};

export async function saveAbout(input: AboutInput): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const { data: old } = await db.from("site_pages").select("content").eq("slug", "about").maybeSingle();
    const oldPhoto = (old?.content as AboutRow | undefined)?.photo;

    let photo = input.removePhoto ? undefined : oldPhoto;
    if (input.newPhoto) {
      if (!(await photoExists(input.newPhoto))) throw new Error("The photo did not finish uploading. Please try again.");
      photo = input.newPhoto;
    }
    const content: AboutRow = { heading: limit(input.heading, 120), body: limit(input.body, 20_000), ...(photo ? { photo } : {}) };
    const { error } = await db.from("site_pages").upsert({ slug: "about", content, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.code === "PGRST205" ? "The database needs updating first: run supabase/schema.sql again." : error.message);
    if (oldPhoto && oldPhoto !== photo) await deletePhoto(oldPhoto);
    changed();
    return null;
  });
}

export async function saveContact(input: ContactPage): Promise<Result> {
  return run(async () => {
    const db = await ownerDb();
    const c: ContactPage = {
      heading: limit(input.heading, 120),
      note: limit(input.note, 2_000),
      email: limit(input.email, 200),
      phone: limit(input.phone, 40),
      whatsapp: limit(input.whatsapp, 40),
      address: limit(input.address, 500),
      timings: limit(input.timings, 200),
      youtube: limit(input.youtube, 300),
      instagram: limit(input.instagram, 300),
    };
    if (c.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)) throw new Error("That email address does not look right.");
    for (const [label, v] of [["Phone", c.phone], ["WhatsApp", c.whatsapp]] as const) {
      if (v && v.replace(/\D/g, "").length < 8) throw new Error(`${label} number looks too short. Include the full number.`);
    }
    for (const [label, v] of [["YouTube", c.youtube], ["Instagram", c.instagram]] as const) {
      if (v && !/^https:\/\/\S+$/.test(v)) throw new Error(`${label} link should start with https://`);
    }
    const { error } = await db.from("site_pages").upsert({ slug: "contact", content: c, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.code === "PGRST205" ? "The database needs updating first: run supabase/schema.sql again." : error.message);
    changed();
    return null;
  });
}

// ---------- home page: header people, vision & mission, gallery, workshops ----------

/** A photo field as the panel sends it: the current public link to keep it, or a freshly uploaded key */
export type PhotoInput = { photo: string; newPhoto?: string };

/**
 * Reads the home row, lets `edit` change one part, saves it, then deletes photos nothing uses any more.
 * `photoKey` turns a PhotoInput into a storage key, accepting only photos already on the home page or just uploaded.
 */
async function updateHome(edit: (row: HomeRow, photoKey: (p: PhotoInput) => Promise<string | undefined>) => Promise<void>): Promise<Result<HomePage>> {
  return run(async () => {
    const db = await ownerDb();
    // 42P01/PGRST205: no site_pages table; 23514: the table's slug check predates "home"
    const schemaError = (e: { code?: string; message: string }) => new Error(["PGRST205", "42P01", "23514"].includes(e.code ?? "") ? NEEDS_SCHEMA : e.message);

    // Two saves can overlap (several Save buttons on one screen). Each write only lands if the row is
    // unchanged since it was read; otherwise it re-reads and applies its change again.
    for (let attempt = 0; attempt < 3; attempt++) {
      const { data: old, error: readError } = await db.from("site_pages").select("content,updated_at").eq("slug", "home").maybeSingle();
      if (readError) throw schemaError(readError);
      const row: HomeRow = structuredClone((old?.content ?? {}) as HomeRow);
      const oldKeys = homePhotoKeys(row);

      await edit(row, async ({ photo, newPhoto }) => {
        if (newPhoto) {
          // Only photos uploaded for the home page; never the About photo
          if (!/^site\/(person|gallery|workshop|slide)-/.test(newPhoto) || !(await photoExists(newPhoto))) throw new Error("A photo did not finish uploading. Please try again.");
          return newPhoto;
        }
        if (!photo) return undefined;
        const key = oldKeys.find((k) => photoLink(k) === photo);
        if (!key) throw new Error("The photos were changed in another tab or window. Reload this page and try again.");
        return key;
      });

      const now = new Date().toISOString();
      const write = old
        ? await db.from("site_pages").update({ content: row, updated_at: now }).eq("slug", "home").eq("updated_at", old.updated_at).select("slug")
        : await db.from("site_pages").insert({ slug: "home", content: row, updated_at: now }).select("slug");
      if (write.error && write.error.code !== "23505") throw schemaError(write.error);
      if (write.error || !write.data?.length) continue; // someone else saved first (or inserted the row): try again

      const kept = new Set(homePhotoKeys(row));
      await Promise.all(oldKeys.filter((k) => !kept.has(k)).map(deletePhoto));
      changed();
      // The saved version, so the panel shows the stored photos without reloading
      return toHome(row);
    }
    throw new Error("Another save was happening at the same time. Please press Save again.");
  });
}

const MAX_PEOPLE = 3;
const MAX_GALLERY_PHOTOS = 40;
const MAX_WORKSHOPS = 60;

export async function savePeople(people: (PhotoInput & { name: string; title: string })[]): Promise<Result<HomePage>> {
  return updateHome(async (row, photoKey) => {
    if (people.length > MAX_PEOPLE) throw new Error(`Up to ${MAX_PEOPLE} people can be shown.`);
    row.people = [];
    for (const p of people) {
      const name = limit(p.name, 80);
      if (!name) throw new Error("Please give every person a name.");
      const photo = await photoKey(p);
      row.people.push({ name, title: limit(p.title, 120), ...(photo ? { photo } : {}) });
    }
  });
}

export async function saveVisionMission(vision: string, mission: string): Promise<Result<HomePage>> {
  return updateHome(async (row) => {
    row.vision = limit(vision, 4_000);
    row.mission = limit(mission, 4_000);
  });
}

export async function saveGallery(index: 0 | 1, title: string, photos: (PhotoInput & { caption: string })[]): Promise<Result<HomePage>> {
  return updateHome(async (row, photoKey) => {
    if (index !== 0 && index !== 1) throw new Error("Unknown gallery section.");
    if (photos.length > MAX_GALLERY_PHOTOS) throw new Error(`Up to ${MAX_GALLERY_PHOTOS} photos per section.`);
    const galleries = Array.isArray(row.galleries) ? row.galleries : [];
    while (galleries.length < 2) galleries.push({});
    const kept: { photo: string; caption: string }[] = [];
    for (const p of photos) {
      const photo = await photoKey(p);
      if (photo) kept.push({ photo, caption: limit(p.caption, 200) });
    }
    galleries[index] = { title: limit(title, 80), photos: kept };
    row.galleries = galleries;
  });
}

export type WorkshopInput = PhotoInput & { id: string; title: string; date: string; place: string; body: string; link: string };

export async function saveWorkshops(list: WorkshopInput[]): Promise<Result<HomePage>> {
  return updateHome(async (row, photoKey) => {
    if (list.length > MAX_WORKSHOPS) throw new Error(`Up to ${MAX_WORKSHOPS} workshops can be listed. Delete old ones first.`);
    row.workshops = [];
    const ids = new Set<string>();
    for (const w of list) {
      const title = limit(w.title, 160);
      if (!title) throw new Error("Please give every workshop a title.");
      const date = /^\d{4}-\d{2}-\d{2}$/.test(w.date) && !Number.isNaN(Date.parse(w.date)) ? w.date : "";
      const link = limit(w.link, 300);
      if (link && !/^https:\/\/\S+$/.test(link)) throw new Error(`The link for “${title}” should start with https://`);
      const photo = await photoKey(w);
      // A new workshop (or a repeated id) gets a fresh id, so every card has its own address on /workshops
      const id = /^[a-z0-9]{4,20}$/.test(w.id) && !ids.has(w.id) ? w.id : Math.random().toString(36).slice(2, 12);
      ids.add(id);
      row.workshops.push({ id, title, date, place: limit(w.place, 160), body: limit(w.body, 5_000), link, ...(photo ? { photo } : {}) });
    }
  });
}

const MAX_SLIDES = 8;
const MAX_NOTICES = 10;

export type SlideInput = PhotoInput & { heading: string; text: string; button: string; link: string };

export async function saveSlides(list: SlideInput[]): Promise<Result<HomePage>> {
  return updateHome(async (row, photoKey) => {
    if (list.length > MAX_SLIDES) throw new Error(`Up to ${MAX_SLIDES} slides can be shown.`);
    row.slides = [];
    for (const [i, s] of list.entries()) {
      const photo = await photoKey(s);
      if (!photo) throw new Error(`Slide ${i + 1} needs a photo.`);
      const link = limit(s.link, 300);
      // A page on this site (/topics/...) or a full https:// address; never javascript: or other schemes
      if (link && !/^(https:\/\/\S+|\/(?!\/)\S*)$/.test(link)) throw new Error(`The button link on slide ${i + 1} should start with https:// or /`);
      row.slides.push({ photo, heading: limit(s.heading, 120), text: limit(s.text, 240), button: limit(s.button, 40), link });
    }
  });
}

export async function saveNotices(list: string[]): Promise<Result<HomePage>> {
  return updateHome(async (row) => {
    const notices = (Array.isArray(list) ? list : []).map((n) => limit(n, 160)).filter(Boolean);
    if (notices.length > MAX_NOTICES) throw new Error(`Up to ${MAX_NOTICES} notices can be shown.`);
    row.notices = notices;
  });
}

// ---------- usage statistics ----------

export async function getStats(days: StatRange): Promise<Result<Stats>> {
  return run(async () => {
    const db = await ownerDb();
    if (![7, 30, 90].includes(days)) throw new Error("Unknown date range.");
    const since = new Date(Date.now() - days * 86_400_000).toISOString();
    const [totals, byRes, devices, daily] = await Promise.all([
      db.rpc("stats_totals", { since }),
      db.rpc("stats_by_resource", { since }),
      db.rpc("stats_by_device", { since }),
      db.rpc("stats_daily", { since }),
    ]);
    const err = totals.error ?? byRes.error ?? devices.error ?? daily.error;
    if (err) throw new Error(err.message);

    const t = Object.fromEntries((totals.data as { kind: string; n: number }[]).map((r) => [r.kind, Number(r.n)]));
    const byResource: Stats["byResource"] = {};
    for (const r of byRes.data as { resource_id: string; kind: string; n: number }[]) {
      const entry = (byResource[r.resource_id] ??= { views: 0, downloads: 0, plays: 0 });
      if (r.kind === "view") entry.views = Number(r.n);
      if (r.kind === "download") entry.downloads = Number(r.n);
      if (r.kind === "play") entry.plays = Number(r.n);
    }
    const dev = Object.fromEntries((devices.data as { device: string; n: number }[]).map((r) => [r.device, Number(r.n)]));

    // Fill in days with no visits so the chart has one bar per day
    const counts = new Map((daily.data as { day: string; n: number }[]).map((r) => [r.day, Number(r.n)]));
    const dayKey = (d: Date) => d.toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
    const series = Array.from({ length: days }, (_, i) => {
      const day = dayKey(new Date(Date.now() - (days - 1 - i) * 86_400_000));
      return { day, n: counts.get(day) ?? 0 };
    });

    return {
      days,
      totals: { visits: t.visit ?? 0, views: t.view ?? 0, downloads: t.download ?? 0, plays: t.play ?? 0 },
      byResource,
      devices: { mobile: dev.mobile ?? 0, tablet: dev.tablet ?? 0, desktop: dev.desktop ?? 0 },
      daily: series,
    };
  });
}

/** Shown on the owner login screen when keys are missing */
