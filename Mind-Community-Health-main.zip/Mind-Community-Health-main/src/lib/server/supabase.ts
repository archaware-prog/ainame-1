import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { env, hasSupabase } from "./env";

let admin: SupabaseClient | null = null;

/** Full-access client (secret key). Server only; call it only after checking the owner's login, or for public reads and usage counters. */
export function adminDb(): SupabaseClient | null {
  if (!hasSupabase()) return null;
  admin ??= createClient(env.supabaseUrl, env.supabaseSecret, { auth: { persistSession: false, autoRefreshToken: false } });
  return admin;
}

/** Login-aware client that reads and refreshes the owner's session cookie */
export async function authClient() {
  const store = await cookies();
  return createServerClient(env.supabaseUrl, env.supabaseKey, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list) => {
        try {
          // httpOnly: page scripts can never read the login cookie (only this server uses it)
          list.forEach(({ name, value, options }) => store.set(name, value, { ...options, httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax" }));
        } catch {
          // Called from a Server Component, where cookies are read-only. The next action refreshes them.
        }
      },
    },
  });
}

/** The owner's email when the visitor is logged in as the owner, otherwise null */
export async function currentOwner(): Promise<string | null> {
  if (!hasSupabase()) return null;
  const sb = await authClient();
  const { data } = await sb.auth.getUser();
  const email = data.user?.email?.toLowerCase() ?? null;
  if (!email) return null;
  // Only the account named in OWNER_EMAIL is the owner. If OWNER_EMAIL is missing nobody is let in,
  // so a stray Supabase account (e.g. sign-ups left on) can never reach the owner panel.
  return env.ownerEmail && email === env.ownerEmail ? email : null;
}
