import { AwsClient } from "aws4fetch";
import { env } from "./env";

// PDFs live in a private Cloudflare R2 bucket: no public URL exists. When the owner uploads a PDF,
// their browser also turns every page into an image and uploads those next to it. Students see the
// page images through signed links, so "view only" files never send the PDF. Downloads get a
// two-minute signed link to the PDF itself.
//
// One item's files:  files/<name>-<time>/original.pdf, files/<name>-<time>/p1, …/p2, …
// The database stores the folder ("file id") and the page count.

const FOLDER = "files";
export const MAX_PAGES = 500;
const UPLOAD_LINK_SECONDS = 30 * 60;
const DOWNLOAD_LINK_SECONDS = 120;

let client: AwsClient | null = null;
const r2 = () => (client ??= new AwsClient({ accessKeyId: env.r2KeyId, secretAccessKey: env.r2Secret, service: "s3", region: "auto" }));

const objectUrl = (key: string) => new URL(`https://${env.r2AccountId}.r2.cloudflarestorage.com/${env.r2Bucket}/${key}`);
const pdfKey = (fileId: string) => `${fileId}/original.pdf`;
const pageKey = (fileId: string, page: number) => `${fileId}/p${page}`;
const pageNumbers = (pages: number) => Array.from({ length: Math.max(1, pages) }, (_, i) => i + 1);

/** AWS date format, e.g. 20261030T140000Z */
const amzDate = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");

async function signedUrl(key: string, method: "GET" | "PUT", seconds: number, query: Record<string, string> = {}, datetime?: string) {
  const url = objectUrl(key);
  url.searchParams.set("X-Amz-Expires", String(seconds));
  for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
  const signed = await r2().sign(url, { method, aws: { signQuery: true, datetime } });
  return signed.url;
}

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/\.pdf$/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60) || "file";

/** Upload links for one PDF and its page images, used by the owner's browser */
export async function signUpload(fileName: string, pages: number) {
  if (!Number.isInteger(pages) || pages < 1) throw new Error("That PDF has no pages.");
  if (pages > MAX_PAGES) throw new Error(`PDFs can have up to ${MAX_PAGES} pages. Split this one into parts.`);
  const fileId = `${FOLDER}/${slugify(fileName)}-${Date.now().toString(36)}`;
  const [pdf, ...pageLinks] = await Promise.all(
    [pdfKey(fileId), ...pageNumbers(pages).map((n) => pageKey(fileId, n))].map((key) => signedUrl(key, "PUT", UPLOAD_LINK_SECONDS)),
  );
  return { fileId, pdf, pages: pageLinks };
}

/** Checks that the PDF and every page image really arrived; returns the PDF's size */
export async function inspectUpload(fileId: string, pages: number) {
  if (!/^files\/[a-z0-9-]+$/.test(fileId)) throw new Error("Unexpected file location.");
  if (!Number.isInteger(pages) || pages < 1 || pages > MAX_PAGES) throw new Error("Unexpected page count.");
  const head = (key: string) => r2().fetch(objectUrl(key), { method: "HEAD" });
  const [pdf, last, extra] = await Promise.all([head(pdfKey(fileId)), head(pageKey(fileId, pages)), head(pageKey(fileId, pages + 1))]);
  if (!pdf.ok || !last.ok || extra.ok) throw new Error("The upload did not finish. Please try again.");
  return { pages, bytes: Number(pdf.headers.get("content-length")) || 0 };
}

/**
 * Signed links to the page images. Signed as of the start of the hour and valid for two hours, so
 * the links stay the same for an hour and the browser can reuse cached pages.
 */
export function pageUrls(fileId: string, pages: number) {
  const hour = new Date();
  hour.setUTCMinutes(0, 0, 0);
  return Promise.all(pageNumbers(pages).map((n) => signedUrl(pageKey(fileId, n), "GET", 2 * 60 * 60, {}, amzDate(hour))));
}

/** A download link for the original PDF that stops working after two minutes */
export function downloadUrl(fileId: string, title: string) {
  const name = `${slugify(title)}.pdf`;
  return signedUrl(pdfKey(fileId), "GET", DOWNLOAD_LINK_SECONDS, {
    "response-content-type": "application/pdf",
    "response-content-disposition": `attachment; filename="${name}"`,
  });
}

// ---------- Site photos: site/<kind>-<time><random>.webp (About Us, header people, gallery, workshops) ----------

export const PHOTO_KINDS = ["about", "person", "gallery", "workshop", "slide"] as const;
export type PhotoKind = (typeof PHOTO_KINDS)[number];

export const isPhotoKey = (key: string) => /^site\/(about|person|gallery|workshop|slide)-[a-z0-9]+\.webp$/.test(key);

/** Upload link for a new site photo (the owner's browser shrinks it to WebP first) */
export async function signPhotoUpload(kind: PhotoKind = "about") {
  const id = kind === "about" ? Date.now().toString(36) : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const key = `site/${kind}-${id}.webp`;
  return { key, url: await signedUrl(key, "PUT", UPLOAD_LINK_SECONDS) };
}

export async function photoExists(key: string) {
  if (!isPhotoKey(key)) return false;
  return (await r2().fetch(objectUrl(key), { method: "HEAD" })).ok;
}

/** Signed as of the start of the hour, valid two hours, so browsers can cache it for an hour */
export function photoUrl(key: string) {
  const hour = new Date();
  hour.setUTCMinutes(0, 0, 0);
  return signedUrl(key, "GET", 2 * 60 * 60, {}, amzDate(hour));
}

export async function deletePhoto(key: string) {
  if (isPhotoKey(key)) await r2().fetch(objectUrl(key), { method: "DELETE" }).catch(() => null);
}

export async function deleteFile(fileId: string, pages: number) {
  // A failure leaves orphan files in R2 at worst; the database change already happened
  const keys = [pdfKey(fileId), ...pageNumbers(pages).map((n) => pageKey(fileId, n))];
  await Promise.allSettled(keys.map((key) => r2().fetch(objectUrl(key), { method: "DELETE" })));
}
