import { cacheLife, cacheTag } from "next/cache";
import { createClient } from "@supabase/supabase-js";
import { CATALOG_TAG } from "./catalog";
import { env, hasSupabase } from "./env";
import { DEFAULT_GALLERY_TITLES, DEFAULT_PAGES, type ContactPage, type HomePage, type SitePages } from "../types";

// About Us and Contact Us, written by the owner in the panel (src/components/admin/SitePages.tsx).
// Stored as JSON in the site_pages table. Cached with the catalog, so owner saves show straight away.

/** What the database holds for About; `photo` is the private R2 key, never sent to the browser */
export type AboutRow = { heading?: string; body?: string; photo?: string };

/** What the database holds for the home page (slug "home"). `photo` fields are private R2 keys. */
export type HomeRow = {
  people?: { name?: string; title?: string; photo?: string }[];
  vision?: string;
  mission?: string;
  galleries?: { title?: string; photos?: { photo?: string; caption?: string }[] }[];
  workshops?: { id?: string; title?: string; date?: string; place?: string; body?: string; link?: string; photo?: string }[];
  slides?: { photo?: string; heading?: string; text?: string; button?: string; link?: string }[];
  notices?: string[];
};

const str = (v: unknown) => (typeof v === "string" ? v : "");
const arr = <T>(v: T[] | undefined): T[] => (Array.isArray(v) ? v : []);

/** Every R2 photo key a home row points at */
export function homePhotoKeys(row: HomeRow): string[] {
  return [
    ...arr(row.people).map((p) => p.photo),
    ...arr(row.galleries).flatMap((g) => arr(g.photos).map((p) => p.photo)),
    ...arr(row.workshops).map((w) => w.photo),
    ...arr(row.slides).map((s) => s.photo),
  ].filter((k): k is string => !!k);
}

/** Public link for a site photo. The id is unique per upload, so it can be cached for good. */
export const photoLink = (key?: string) => (key ? `/api/site-photo?id=${key.replace(/^site\//, "").replace(/\.webp$/, "")}` : "");

export function toHome(row: HomeRow): HomePage {
  const g = arr(row.galleries);
  const gallery = (i: 0 | 1) => ({
    title: str(g[i]?.title) || DEFAULT_GALLERY_TITLES[i],
    photos: arr(g[i]?.photos)
      .filter((p) => p.photo)
      .map((p) => ({ photo: photoLink(p.photo), caption: str(p.caption) })),
  });
  return {
    people: arr(row.people).map((p) => ({ name: str(p.name), title: str(p.title), photo: photoLink(p.photo) })),
    vision: str(row.vision),
    mission: str(row.mission),
    galleries: [gallery(0), gallery(1)],
    workshops: arr(row.workshops)
      .map((w) => ({ id: str(w.id), title: str(w.title), date: str(w.date), place: str(w.place), body: str(w.body), link: str(w.link), photo: photoLink(w.photo) }))
      .sort((a, b) => (b.date || "").localeCompare(a.date || "")),
    slides: arr(row.slides)
      .filter((s) => s.photo)
      .map((s) => ({ photo: photoLink(s.photo), heading: str(s.heading), text: str(s.text), button: str(s.button), link: str(s.link) })),
    notices: arr(row.notices).map(str).filter(Boolean),
  };
}

export function toPages(rows: { slug: string; content: unknown; updated_at: string }[]): SitePages {
  const about = (rows.find((r) => r.slug === "about")?.content ?? {}) as AboutRow;
  const aboutStamp = rows.find((r) => r.slug === "about")?.updated_at ?? "";
  const contact = (rows.find((r) => r.slug === "contact")?.content ?? {}) as Partial<ContactPage>;
  return {
    about: {
      heading: str(about.heading) || DEFAULT_PAGES.about.heading,
      body: str(about.body),
      photoVersion: about.photo ? String(Date.parse(aboutStamp) || 1) : "",
    },
    contact: Object.fromEntries(Object.entries(DEFAULT_PAGES.contact).map(([k, fallback]) => [k, str(contact[k as keyof ContactPage]) || (k === "heading" ? fallback : "")])) as ContactPage,
    home: toHome((rows.find((r) => r.slug === "home")?.content ?? {}) as HomeRow),
  };
}

/**
 * The R2 keys of every photo the site shows (About photo, home-page photos), for /api/site-photo.
 * Cached with the catalog, so serving a photo does not query the database each time.
 */
export async function getPhotoKeys(): Promise<{ about: string | null; home: string[] }> {
  "use cache";
  cacheLife("days");
  cacheTag(CATALOG_TAG);

  if (!hasSupabase()) return { about: null, home: [] };
  const db = createClient(env.supabaseUrl, env.supabaseKey, { auth: { persistSession: false } });
  const { data, error } = await db.from("site_pages").select("slug,content").in("slug", ["about", "home"]);
  if (error) throw new Error(`Could not load site photos: ${error.message}`);
  const row = (slug: string) => (data.find((r) => r.slug === slug)?.content ?? {}) as AboutRow & HomeRow;
  return { about: row("about").photo || null, home: homePhotoKeys(row("home")) };
}

export async function getSitePages(): Promise<SitePages> {
  "use cache";
  cacheLife("days");
  cacheTag(CATALOG_TAG);

  if (!hasSupabase()) return DEFAULT_PAGES;
  const db = createClient(env.supabaseUrl, env.supabaseKey, { auth: { persistSession: false } });
  const { data, error } = await db.from("site_pages").select("slug,content,updated_at");
  if (error?.code === "PGRST205") {
    // Table missing until supabase/schema.sql is re-run: show the empty pages rather than break
    console.warn(`[pages] Could not load About/Contact (${error.message}). Run supabase/schema.sql again.`);
    return DEFAULT_PAGES;
  }
  // Any other failure (e.g. a network blip) must not be cached for days as an empty page: throw, like getCatalog
  if (error) throw new Error(`Could not load site pages: ${error.message}`);
  return toPages(data);
}
