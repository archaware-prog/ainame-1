// Server-side settings, read from .env.local (see .env.example and ../docs/SETUP-KEYS.md).

export const env = {
  supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
  supabaseKey: process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? "",
  supabaseSecret: process.env.SUPABASE_SECRET_KEY ?? "",
  r2AccountId: process.env.R2_ACCOUNT_ID ?? "",
  r2KeyId: process.env.R2_ACCESS_KEY_ID ?? "",
  r2Secret: process.env.R2_SECRET_ACCESS_KEY ?? "",
  r2Bucket: process.env.R2_BUCKET ?? "",
  ownerEmail: (process.env.OWNER_EMAIL ?? "").trim().toLowerCase(),
  cronSecret: process.env.CRON_SECRET ?? "",
};

export const hasSupabase = () => !!(env.supabaseUrl && env.supabaseKey && env.supabaseSecret);
export const hasR2 = () => !!(env.r2AccountId && env.r2KeyId && env.r2Secret && env.r2Bucket);

/**
 * Setup problem shown on the owner login screen, or null. A plain server function, not a server
 * action, so the public cannot call it to learn which keys are missing.
 */
export function connectionProblem(): string | null {
  if (!hasSupabase()) return "The database keys are missing. Fill in web/.env.local (see docs/SETUP-KEYS.md).";
  if (!hasR2()) return "The Cloudflare R2 keys are missing, so PDFs cannot be uploaded yet.";
  if (!env.ownerEmail) return "OWNER_EMAIL is not set, so nobody can log in. Add it to the site's settings (Vercel → Environment Variables, or web/.env.local).";
  return null;
}

/** Names of the settings that are still empty, for the owner panel's "not connected" message */
export function missingKeys() {
  const names: [string, string][] = [
    ["NEXT_PUBLIC_SUPABASE_URL", env.supabaseUrl],
    ["NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY", env.supabaseKey],
    ["SUPABASE_SECRET_KEY", env.supabaseSecret],
    ["R2_ACCOUNT_ID", env.r2AccountId],
    ["R2_ACCESS_KEY_ID", env.r2KeyId],
    ["R2_SECRET_ACCESS_KEY", env.r2Secret],
    ["R2_BUCKET", env.r2Bucket],
    ["OWNER_EMAIL", env.ownerEmail],
  ];
  return names.filter(([, v]) => !v).map(([k]) => k);
}
