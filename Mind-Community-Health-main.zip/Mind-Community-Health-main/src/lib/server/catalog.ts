import { cacheLife, cacheTag } from "next/cache";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { env, hasSupabase } from "./env";
import { parseVideoUrl } from "../video";
import { isLinkType, subtopicKey, type Resource, type ResourceType, type Topic } from "../types";

export type Catalog = { topics: Topic[]; resources: Resource[] };

/** Owner changes call updateTag(CATALOG_TAG) so the public site shows them straight away */
export const CATALOG_TAG = "catalog";

export type ResourceRow = {
  id: string;
  title: string;
  type: ResourceType;
  unit: number | null;
  file_id: string | null;
  file_pages: number | null;
  file_bytes: number | null;
  video_url: string | null;
  allow_download: boolean;
  hidden: boolean;
  added_at: string;
  subtopics: string[] | null;
};

// subject_slug, years, branches and exam_tags are still in the table (old data) but no longer used
export const RESOURCE_COLUMNS = "id,title,type,unit,file_id,file_pages,file_bytes,video_url,allow_download,hidden,added_at,subtopics";

type TopicRow = { slug: string; name: string; icon: string; color: string };
/** youtube_url is missing until supabase/schema.sql is re-run, so it is optional */
type SubTopicRow = { topic_slug: string; slug: string; name: string; youtube_url?: string | null };

/** Topics with their sub-topics nested, both in the owner's order */
export function toTopics(topics: TopicRow[], subs: SubTopicRow[]): Topic[] {
  return topics.map((t) => ({
    ...t,
    subtopics: subs
      .filter((s) => s.topic_slug === t.slug)
      .map((s) => ({ slug: s.slug, name: s.name, key: subtopicKey(t.slug, s.slug), ...(s.youtube_url ? { youtube: s.youtube_url } : {}) })),
  }));
}

/** Topics and sub-topics, read with any client (public or owner) */
export async function loadTopics(db: SupabaseClient) {
  const [topics, subs] = await Promise.all([
    db.from("topics").select("slug,name,icon,color").order("position").order("name"),
    // "*" so a database without the newer youtube_url column still loads
    db.from("subtopics").select("*").order("position").order("name"),
  ]);
  const error = topics.error ?? subs.error;
  return { error, topics: error ? [] : toTopics(topics.data as TopicRow[], subs.data as SubTopicRow[]) };
}

function meta(row: ResourceRow) {
  if (row.type === "video") return parseVideoUrl(row.video_url ?? "")?.kind === "instagram" ? "Instagram" : "YouTube";
  if (row.type === "book") return /amazon\.|amzn\./i.test(row.video_url ?? "") ? "Amazon" : "Online store";
  const pages = row.file_pages ?? 1;
  return `PDF · ${pages} ${pages === 1 ? "page" : "pages"}`;
}

/** Database row → the shape pages use. The R2 file id never leaves the server. */
export function toResource(row: ResourceRow): Resource {
  return {
    id: row.id,
    title: row.title,
    subtopics: row.subtopics ?? [],
    type: row.type,
    unit: row.unit ?? undefined,
    pages: row.file_pages ?? undefined,
    videoUrl: row.video_url ?? undefined,
    meta: meta(row),
    allowDownload: isLinkType(row.type) ? false : row.allow_download,
    addedAt: row.added_at,
    hidden: row.hidden || undefined,
  };
}

/** Everything the public site shows. Cached until the owner changes something. */
export async function getCatalog(): Promise<Catalog> {
  "use cache";
  cacheLife("days");
  cacheTag(CATALOG_TAG);

  if (!hasSupabase()) {
    console.warn("[catalog] Supabase keys are missing in .env.local, so the site shows no material. See docs/SETUP-KEYS.md.");
    return { topics: [], resources: [] };
  }
  // Publishable key: Row Level Security only lets it read topics and visible material
  const db = createClient(env.supabaseUrl, env.supabaseKey, { auth: { persistSession: false } });
  const visible = (columns: string) => db.from("resources").select(columns).eq("hidden", false).order("added_at", { ascending: false });
  const [topics, resources] = await Promise.all([loadTopics(db), visible(RESOURCE_COLUMNS)]);

  // A database from before the topics change has no topics yet (missing table PGRST205, missing column 42703).
  // Keep the public site working without them until supabase/schema.sql is re-run.
  if (topics.error?.code === "PGRST205" || resources.error?.code === "42703") {
    console.warn("[catalog] Topics are not in the database yet. Run supabase/schema.sql again in the Supabase SQL Editor.");
    const old = await visible(RESOURCE_COLUMNS.replace(",subtopics", ""));
    if (old.error) throw new Error(`Could not load material: ${old.error.message}`);
    return { topics: [], resources: (old.data as unknown as ResourceRow[]).map(toResource) };
  }
  const error = topics.error ?? resources.error;
  if (error) throw new Error(`Could not load material: ${error.message}`);
  return { topics: topics.topics, resources: (resources.data as unknown as ResourceRow[]).map(toResource) };
}
