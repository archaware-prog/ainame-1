// Name, wording and colour in one place, so the client's real branding is a one-file change.
// The logo picture and every icon size are made from one image by scripts/make-logo.mjs
// (public/logo.png in the header, src/app/icon.png + favicon.ico + apple-icon.png, public/icons/*).

const url =
  process.env.NEXT_PUBLIC_SITE_URL ||
  (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "http://localhost:3000");

export const SITE = {
  name: "Mind and Community Health",
  tagline: "free notes, PPTs & videos",
  /** Line under the name in the header, from the client's reference design */
  motto: "Healthy Minds. Healthy Communities. Better Living.",
  description: "Free, student-friendly study material: notes, slides, question banks and videos in one place. No sign-up needed.",
  themeColor: "#14386a",
  background: "#f6f9fd",
  url: url.replace(/\/$/, ""),
};
