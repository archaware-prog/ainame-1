import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { ImageResponse } from "next/og";
import { SITE } from "./site";

// Share preview card (WhatsApp, Telegram, Instagram DMs). 1200×630 is what they all expect.
// Same look as the site header: logo, navy name, green motto, navy bar.

export const OG_SIZE = { width: 1200, height: 630 };

const NAVY = SITE.themeColor;
const GREEN = "#2e7d32";

export async function ogCard({ kicker, title, footer }: { kicker: string; title: string; footer: string }) {
  const logo = `data:image/png;base64,${(await readFile(join(process.cwd(), "public/logo.png"))).toString("base64")}`;
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", background: SITE.background, color: NAVY }}>
        <div style={{ display: "flex", alignItems: "center", gap: 28, padding: "48px 64px 0" }}>
          {/* eslint-disable-next-line @next/next/no-img-element -- ImageResponse only takes plain <img> */}
          <img src={logo} width={160} height={124} alt="" />
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex", fontSize: 58, fontWeight: 800 }}>{SITE.name.replace(" and ", " & ")}</div>
            <div style={{ display: "flex", fontSize: 30, fontStyle: "italic", color: GREEN, marginTop: 4 }}>{SITE.motto}</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", flex: 1, justifyContent: "center", padding: "0 64px" }}>
          <div style={{ display: "flex", fontSize: 28, fontWeight: 700, color: GREEN, textTransform: "uppercase", letterSpacing: 2 }}>{kicker}</div>
          <div style={{ display: "flex", fontSize: title.length > 50 ? 56 : 70, fontWeight: 800, lineHeight: 1.1, marginTop: 10 }}>{title}</div>
          <div style={{ display: "flex", width: 220, height: 6, borderRadius: 3, marginTop: 24, background: `linear-gradient(90deg, ${GREEN}, #a5d6a7)` }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", padding: "26px 64px", background: NAVY, color: "white", fontSize: 28 }}>
          <div style={{ display: "flex", fontWeight: 700 }}>{footer}</div>
        </div>
      </div>
    ),
    OG_SIZE,
  );
}
