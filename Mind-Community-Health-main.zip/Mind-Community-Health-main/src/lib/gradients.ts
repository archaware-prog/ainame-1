// Colour choices for subject tiles. Kept as full class names so Tailwind generates them.
export const GRADIENTS = [
  "from-orange-400 to-rose-500",
  "from-violet-500 to-fuchsia-500",
  "from-sky-400 to-indigo-500",
  "from-emerald-400 to-teal-600",
  "from-pink-500 to-purple-600",
  "from-amber-400 to-orange-500",
  "from-cyan-400 to-blue-600",
  "from-lime-400 to-emerald-600",
  "from-rose-400 to-red-600",
  "from-slate-500 to-slate-800",
];
