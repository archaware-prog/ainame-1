"use client";

import { createContext, createElement, useContext } from "react";
import { DEFAULT_PAGES, type Resource, type SitePages, type Topic } from "./types";

// Client side of the data layer. The public catalog is loaded on the server
// (src/lib/server/catalog.ts, cached until the owner changes something). The root layout hands
// every page the topics and page texts (StoreProvider); only the pages that list materials get
// the material list too (ResourcesProvider, in src/app/(library)/layout.tsx), to keep the rest light.
// Owner changes go through the server actions in src/lib/actions.ts.

const TopicsCtx = createContext<Topic[]>([]);
const ResourcesCtx = createContext<Resource[]>([]);
const PagesCtx = createContext<SitePages>(DEFAULT_PAGES);

export function StoreProvider({ topics, pages, children }: { topics: Topic[]; pages?: SitePages; children: React.ReactNode }) {
  return createElement(TopicsCtx.Provider, { value: topics }, pages ? createElement(PagesCtx.Provider, { value: pages }, children) : children);
}

export function ResourcesProvider({ resources, children }: { resources: Resource[]; children: React.ReactNode }) {
  return createElement(ResourcesCtx.Provider, { value: resources }, children);
}

/** Owner-written home page parts: header people, gallery, workshops, vision & mission */
export function useHome() {
  return useContext(PagesCtx).home;
}

/** About Us text and photo (shown on the home page too) */
export function useAbout() {
  return useContext(PagesCtx).about;
}

/** Everything the public site may show (hidden items are never sent to the browser).
 *  Empty outside the (library) pages: see ResourcesProvider. */
export function useResources() {
  return useContext(ResourcesCtx);
}

/** Topic cards, each with its sub-topics, in the owner's chosen order */
export function useTopics() {
  return useContext(TopicsCtx);
}

// ---------- usage tracking ----------

function send(body: object) {
  const data = JSON.stringify(body);
  try {
    if (navigator.sendBeacon?.("/api/track", new Blob([data], { type: "application/json" }))) return;
  } catch {
    // fall through to fetch
  }
  void fetch("/api/track", { method: "POST", body: data, keepalive: true }).catch(() => {});
}

/**
 * True the first time `key` is seen in this browser within `ms`; remembers it. Keeps one person
 * reloading or re-opening the same thing from inflating the owner's stats. If the browser blocks
 * storage (private mode), every event is counted, as before.
 */
function firstTime(key: string, ms: number) {
  try {
    const last = Number(localStorage.getItem(key) || 0);
    if (Date.now() - last < ms) return false;
    localStorage.setItem(key, String(Date.now()));
  } catch {
    // storage unavailable: count it
  }
  return true;
}

const HOUR = 60 * 60 * 1000;

/** Counts a file view or video play, at most once an hour per item per browser. Downloads are counted on the server. */
export function track(kind: "view" | "play", id: string) {
  if (firstTime(`sd-${kind}-${id}`, HOUR)) send({ kind, id });
}

/** Counts a visit, at most once a day per browser */
export function trackVisit() {
  if (firstTime("sd-visit", 24 * HOUR)) send({ kind: "visit" });
}
