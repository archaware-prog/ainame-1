export type ResourceType = "notes" | "slides" | "qbank" | "paper" | "video" | "book";

/** A sub-topic inside a topic card, e.g. "1st Year MBBS" under Community Medicine */
export type SubTopic = {
  slug: string;
  name: string;
  /** "topic-slug/subtopic-slug": how items are tagged */
  key: string;
  /** Optional YouTube link (video, playlist or channel) the owner adds for this sub-topic */
  youtube?: string;
};

/** A topic card on the home page (Community Medicine, Mental Health…). The owner edits the list in the panel. */
export type Topic = {
  slug: string;
  name: string;
  /** Key into TOPIC_ICONS (src/lib/topic-style.ts) */
  icon: string;
  /** Card colour, #rrggbb */
  color: string;
  subtopics: SubTopic[];
};

export const subtopicKey = (topic: string, sub: string) => `${topic}/${sub}`;

export type Resource = {
  id: string;
  title: string;
  /** Sub-topic keys ("topic/sub") this item shows under. Empty = only in search and All materials. */
  subtopics: string[];
  type: ResourceType;
  /** Optional: material does not have to follow a syllabus */
  unit?: number;
  /** PDF page count. The file itself is only reachable through /api/files/[id] */
  pages?: number;
  /** YouTube or Instagram link for videos */
  videoUrl?: string;
  meta?: string;
  allowDownload: boolean;
  /** ISO date */
  addedAt: string;
  hidden?: boolean;
};

export type StatRange = 7 | 30 | 90;

export type Stats = {
  days: StatRange;
  totals: { visits: number; views: number; downloads: number; plays: number };
  /** views + plays + downloads per resource id */
  byResource: Record<string, { views: number; downloads: number; plays: number }>;
  devices: { mobile: number; tablet: number; desktop: number };
  /** visits per day, oldest first, YYYY-MM-DD */
  daily: { day: string; n: number }[];
};

/** About Us page as the public sees it. The photo's storage key stays on the server. */
export type AboutPage = {
  heading: string;
  /** Plain text: a blank line starts a new paragraph, lines starting with "- " become bullet points */
  body: string;
  /** Changes whenever the photo changes; empty = no photo */
  photoVersion: string;
};

/** Contact Us page. Every field is optional; empty ones are not shown. */
export type ContactPage = {
  heading: string;
  note: string;
  email: string;
  phone: string;
  whatsapp: string;
  address: string;
  timings: string;
  youtube: string;
  instagram: string;
};

/** A person shown with a passport photo in the header's top-right corner */
export type Person = { name: string; title: string; /** /api/site-photo link, empty = no photo */ photo: string };

/** One picture in the home page's hero slideshow. Empty text fields fall back to the site's own words. */
export type Slide = {
  /** /api/site-photo link */
  photo: string;
  heading: string;
  text: string;
  /** Button label and link (https:// or a path on this site like /topics/...) */
  button: string;
  link: string;
};

export type GalleryPhoto = { photo: string; caption: string };
export type Gallery = { title: string; photos: GalleryPhoto[] };

export type Workshop = {
  id: string;
  title: string;
  /** YYYY-MM-DD, may be empty */
  date: string;
  place: string;
  /** Same plain-text rules as About Us */
  body: string;
  /** Register / YouTube / more-info link, may be empty */
  link: string;
  photo: string;
};

/** Owner-written parts of the home page (and the header photos). Photo storage keys stay on the server. */
export type HomePage = {
  people: Person[];
  vision: string;
  mission: string;
  /** Always two sections */
  galleries: [Gallery, Gallery];
  /** Newest date first */
  workshops: Workshop[];
  /** Hero slideshow, in the owner's order. Empty = the built-in hero photo. */
  slides: Slide[];
  /** Short owner notices for the moving news strip under the hero */
  notices: string[];
};

export type SitePages = { about: AboutPage; contact: ContactPage; home: HomePage };

export const DEFAULT_GALLERY_TITLES = ["Workshops & Events", "Community Outreach"] as const;

export const DEFAULT_PAGES: SitePages = {
  about: { heading: "About Us", body: "", photoVersion: "" },
  contact: { heading: "Contact Us", note: "", email: "", phone: "", whatsapp: "", address: "", timings: "", youtube: "", instagram: "" },
  home: {
    people: [],
    vision: "",
    mission: "",
    galleries: [
      { title: DEFAULT_GALLERY_TITLES[0], photos: [] },
      { title: DEFAULT_GALLERY_TITLES[1], photos: [] },
    ],
    workshops: [],
    slides: [],
    notices: [],
  },
};

/** Is this item tagged with any sub-topic of `topic` (or with that one sub-topic, if given)? */
export function inTopic(r: Resource, topic: string, sub?: string) {
  return sub ? r.subtopics.includes(subtopicKey(topic, sub)) : r.subtopics.some((k) => k.startsWith(`${topic}/`));
}

/** "Community Medicine › 1st Year MBBS" for each sub-topic an item is tagged with */
export function placeNames(r: Resource, topics: Topic[]) {
  return topics.flatMap((t) => t.subtopics.filter((s) => r.subtopics.includes(s.key)).map((s) => ({ topic: t, sub: s })));
}

export const TYPE_LABEL: Record<ResourceType, string> = {
  notes: "Notes",
  slides: "PPT / Slides",
  qbank: "Question Bank",
  paper: "Previous Paper",
  video: "Video",
  book: "Book",
};

/** Items that are a link (stored in `videoUrl`) instead of an uploaded PDF */
export const isLinkType = (t: ResourceType) => t === "video" || t === "book";

/** A book's shop link (Amazon, amzn.in short links…), or null if it is not a web address */
export function bookUrl(link: string) {
  try {
    const u = new URL(link.trim());
    return u.protocol === "https:" || u.protocol === "http:" ? u.href : null;
  } catch {
    return null;
  }
}
