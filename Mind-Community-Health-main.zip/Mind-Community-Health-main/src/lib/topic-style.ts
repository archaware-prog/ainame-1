import { createElement, type CSSProperties } from "react";
import { Apple, BookOpen, Brain, FlaskConical, GraduationCap, Handshake, HeartPulse, Leaf, Lightbulb, Pill, Sprout, Stethoscope, Users, type LucideIcon, type LucideProps } from "lucide-react";

/** Icons the owner can pick for a topic card. The key is what the database stores. */
export const TOPIC_ICONS: Record<string, { icon: LucideIcon; label: string }> = {
  stethoscope: { icon: Stethoscope, label: "Stethoscope" },
  brain: { icon: Brain, label: "Brain" },
  heart: { icon: HeartPulse, label: "Heart" },
  handshake: { icon: Handshake, label: "Handshake" },
  sprout: { icon: Sprout, label: "Plant" },
  leaf: { icon: Leaf, label: "Leaf" },
  book: { icon: BookOpen, label: "Book" },
  graduation: { icon: GraduationCap, label: "Graduation cap" },
  users: { icon: Users, label: "People" },
  apple: { icon: Apple, label: "Apple" },
  pill: { icon: Pill, label: "Medicine" },
  flask: { icon: FlaskConical, label: "Lab" },
  idea: { icon: Lightbulb, label: "Idea" },
};

/** The icon for a topic's stored key (falls back to a book) */
export function TopicIcon({ icon, ...props }: { icon: string } & LucideProps) {
  return createElement((TOPIC_ICONS[icon] ?? TOPIC_ICONS.book).icon, props);
}

/** Card colours the owner can pick. The first five match the client's reference design. */
export const TOPIC_COLORS = ["#1f5fae", "#3b8b3f", "#6a4aa5", "#1b8c78", "#e5772c", "#c0392b", "#c2185b", "#0e7490", "#334155"];

/** CSS variables a topic card uses: --card (strong colour) and --tint (pale background) */
export const topicVars = (color: string) => ({ "--card": color, "--tint": `color-mix(in srgb, ${color} 8%, white)` }) as CSSProperties;
