export type ParsedVideo =
  | { kind: "youtube"; id: string; embedUrl: string; watchUrl: string }
  | { kind: "instagram"; code: string; embedUrl: string; watchUrl: string };

/** Reads a YouTube or Instagram link the owner pasted. Returns null if it is neither. */
export function parseVideoUrl(raw: string): ParsedVideo | null {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  const host = url.hostname.replace(/^www\.|^m\./, "");

  let ytId: string | null = null;
  if (host === "youtu.be") ytId = url.pathname.slice(1).split("/")[0];
  else if (host === "youtube.com" || host === "youtube-nocookie.com") {
    if (url.pathname === "/watch") ytId = url.searchParams.get("v");
    else {
      const m = url.pathname.match(/^\/(shorts|embed|live)\/([\w-]+)/);
      if (m) ytId = m[2];
    }
  }
  if (ytId && /^[\w-]{6,}$/.test(ytId)) {
    return {
      kind: "youtube",
      id: ytId,
      embedUrl: `https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0`,
      watchUrl: `https://www.youtube.com/watch?v=${ytId}`,
    };
  }

  if (host === "instagram.com") {
    const m = url.pathname.match(/^\/(reel|reels|p|tv)\/([\w-]+)/);
    if (m) {
      const path = m[1] === "reels" ? "reel" : m[1];
      return {
        kind: "instagram",
        code: m[2],
        embedUrl: `https://www.instagram.com/${path}/${m[2]}/embed`,
        watchUrl: `https://www.instagram.com/${path}/${m[2]}/`,
      };
    }
  }
  return null;
}

export function youtubeThumb(id: string) {
  return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
}
