import { WorkshopCard } from "@/components/HomeExtras";
import { getSitePages } from "@/lib/server/pages";

export const metadata = { title: "Workshops", description: "Workshops, talks and community programmes.", alternates: { canonical: "/workshops" } };

export default async function WorkshopsPage() {
  const { workshops } = (await getSitePages()).home;
  return (
    <div className="px-4 lg:px-8">
      <h1 className="mt-8 font-display text-3xl font-bold tracking-tight text-navy-900 sm:text-5xl dark:text-white">Workshops</h1>
      <div className="mt-3 h-1 w-40 rounded-full bg-linear-to-r from-leaf-600 to-transparent" />
      {workshops.length ? (
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {workshops.map((w) => (
            <WorkshopCard key={w.id} w={w} full />
          ))}
        </div>
      ) : (
        <p className="card mt-8 p-8 text-center text-sm text-muted">Upcoming workshops will be listed here. Check back soon!</p>
      )}
    </div>
  );
}
