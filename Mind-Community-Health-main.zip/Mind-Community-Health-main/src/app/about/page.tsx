import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { RichText } from "@/components/RichText";
import { getSitePages } from "@/lib/server/pages";
import { SITE } from "@/lib/site";

export async function generateMetadata() {
  const { about } = await getSitePages();
  return { title: about.heading, description: about.body.slice(0, 160) || SITE.description, alternates: { canonical: "/about" } };
}

export default async function AboutPage() {
  const { about } = await getSitePages();
  return (
    <div className="px-4 lg:px-8">
      <h1 className="mt-8 font-display text-3xl font-bold tracking-tight text-navy-900 sm:text-5xl dark:text-white">{about.heading}</h1>
      <div className="mt-3 h-1 w-40 rounded-full bg-linear-to-r from-leaf-600 to-transparent" />

      <div className={`mt-8 grid gap-8 ${about.photoVersion ? "md:grid-cols-[1fr_340px]" : ""}`}>
        <div>
          {about.body ? (
            <RichText text={about.body} />
          ) : (
            <p className="text-base leading-relaxed text-muted">
              {SITE.name} is a free place for students to find notes, PPTs, question banks, previous papers and videos, sorted by year, branch and subject. No sign-up needed.
            </p>
          )}
          <Link href="/explore" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-navy-800 px-5 py-3 text-sm font-semibold text-white transition hover:bg-navy-700">
            Explore Our Resources <ArrowRight size={18} />
          </Link>
        </div>
        {about.photoVersion && (
          // eslint-disable-next-line @next/next/no-img-element -- served through a signed redirect, so next/image cannot optimise it
          <img src={`/api/site-photo?v=${about.photoVersion}`} alt="" className="w-full rounded-2xl object-cover shadow-lg ring-1 ring-black/5 md:sticky md:top-20" />
        )}
      </div>
    </div>
  );
}
