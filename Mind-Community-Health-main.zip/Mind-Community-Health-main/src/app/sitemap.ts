import type { MetadataRoute } from "next";
import { getCatalog } from "@/lib/server/catalog";
import { SITE } from "@/lib/site";
import { inTopic } from "@/lib/types";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const { topics, resources } = await getCatalog();
  const latest = (topic?: string, sub?: string) => resources.find((r) => !topic || inTopic(r, topic, sub))?.addedAt;
  return [
    { url: SITE.url, lastModified: latest(), changeFrequency: "daily", priority: 1 },
    { url: `${SITE.url}/explore`, changeFrequency: "daily", priority: 0.8 },
    { url: `${SITE.url}/about`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${SITE.url}/contact`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${SITE.url}/workshops`, changeFrequency: "weekly", priority: 0.6 },
    ...topics.map((t) => ({ url: `${SITE.url}/topics/${t.slug}`, lastModified: latest(t.slug), changeFrequency: "weekly" as const, priority: 0.8 })),
    ...topics.flatMap((t) =>
      t.subtopics.map((s) => ({ url: `${SITE.url}/topics/${t.slug}/${s.slug}`, lastModified: latest(t.slug, s.slug), changeFrequency: "weekly" as const, priority: 0.7 })),
    ),
    // Item share links (/item/…) are left out: they show the sub-topic pages above
  ];
}
