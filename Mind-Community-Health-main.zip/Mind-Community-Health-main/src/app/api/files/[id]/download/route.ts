import { after, userAgent, type NextRequest } from "next/server";
import { downloadUrl } from "@/lib/server/r2";
import { adminDb } from "@/lib/server/supabase";

// Sends the student to a two-minute download link, but only when the owner allows downloads.

export async function GET(request: NextRequest, ctx: RouteContext<"/api/files/[id]/download">) {
  const { id } = await ctx.params;
  const db = adminDb();
  if (!db) return new Response("Not connected", { status: 503 });

  const { data } = await db.from("resources").select("title,file_id,allow_download,hidden").eq("id", id).maybeSingle();
  if (!data?.file_id || data.hidden) return new Response("Not found", { status: 404 });
  if (!data.allow_download) return new Response("Download is turned off for this file.", { status: 403 });

  const ua = userAgent(request);
  if (!ua.isBot) {
    const device = ua.device.type === "mobile" || ua.device.type === "tablet" ? ua.device.type : "desktop";
    // Counted after the student is already on their way, so a slow stats write never delays the download
    after(async () => {
      await db.from("events").insert({ kind: "download", resource_id: id, device });
    });
  }
  return Response.redirect(await downloadUrl(data.file_id, data.title), 302);
}
