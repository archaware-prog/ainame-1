import { pageUrls } from "@/lib/server/r2";
import { adminDb } from "@/lib/server/supabase";

// Page images for the PDF viewer. The original PDF's address is never sent to the browser.

export async function GET(_req: Request, ctx: RouteContext<"/api/files/[id]">) {
  const { id } = await ctx.params;
  const db = adminDb();
  if (!db) return Response.json({ error: "Not connected" }, { status: 503 });

  const { data } = await db.from("resources").select("file_id,file_pages,allow_download,hidden").eq("id", id).maybeSingle();
  if (!data?.file_id || data.hidden) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json(
    { pages: await pageUrls(data.file_id, data.file_pages ?? 1), allowDownload: data.allow_download },
    { headers: { "Cache-Control": "private, max-age=60" } },
  );
}
