import { hasSupabase } from "@/lib/server/env";
import { getPhotoKeys } from "@/lib/server/pages";
import { isPhotoKey, photoUrl } from "@/lib/server/r2";

// Site photos live in the private R2 bucket, so this sends a short-lived signed link.
// No ?id: the About Us photo (pages add ?v=<version> so a new photo is never served from an old cache entry).
// ?id=<kind-xxxx>: a home-page photo (header people, gallery, workshops). Only photos the home page uses are served.

const redirect = async (key: string) => new Response(null, { status: 302, headers: { Location: await photoUrl(key), "Cache-Control": "public, max-age=3600" } });

export async function GET(req: Request) {
  if (!hasSupabase()) return new Response("Not connected", { status: 503 });
  // Cached list of the photos in use (refreshed whenever the owner saves), not a database query per photo
  const photos = await getPhotoKeys();

  const id = new URL(req.url).searchParams.get("id");
  if (id) {
    const key = `site/${id}.webp`;
    if (!isPhotoKey(key) || !photos.home.includes(key)) return new Response("No photo", { status: 404 });
    return redirect(key);
  }

  const key = photos.about;
  if (!key || !isPhotoKey(key)) return new Response("No photo", { status: 404 });
  return redirect(key);
}
