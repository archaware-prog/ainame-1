import { env } from "@/lib/server/env";
import { adminDb } from "@/lib/server/supabase";

// Called once a day by the Vercel cron in vercel.json. A free Supabase project pauses after a
// week with no database activity; this tiny read keeps it awake.

export async function GET(request: Request) {
  if (env.cronSecret && request.headers.get("authorization") !== `Bearer ${env.cronSecret}`) {
    return new Response("Unauthorized", { status: 401 });
  }
  const db = adminDb();
  if (!db) return Response.json({ ok: false, error: "Not connected" }, { status: 503 });
  const { error } = await db.from("subjects").select("slug").limit(1);
  return Response.json({ ok: !error, at: new Date().toISOString() }, { status: error ? 500 : 200 });
}
