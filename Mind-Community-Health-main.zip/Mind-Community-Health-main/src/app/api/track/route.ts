import { userAgent, type NextRequest } from "next/server";
import { adminDb } from "@/lib/server/supabase";

// Counts visits, file views and video plays for the owner dashboard. Downloads are counted by
// /api/files/[id]/download. No personal data is stored: only the kind, the item and the device type.

const KINDS = new Set(["visit", "view", "play"]);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function POST(request: NextRequest) {
  const db = adminDb();
  const ua = userAgent(request);
  if (!db || ua.isBot) return new Response(null, { status: 204 });

  let body: { kind?: string; id?: string };
  try {
    body = JSON.parse(await request.text());
  } catch {
    return new Response(null, { status: 400 });
  }
  const kind = body.kind ?? "";
  const id = body.id && UUID.test(body.id) ? body.id : null;
  if (!KINDS.has(kind) || (kind !== "visit" && !id)) return new Response(null, { status: 400 });

  const device = ua.device.type === "mobile" || ua.device.type === "tablet" ? ua.device.type : "desktop";
  // An unknown item id fails the foreign key and is simply not counted
  await db.from("events").insert({ kind, resource_id: kind === "visit" ? null : id, device });
  return new Response(null, { status: 204 });
}
