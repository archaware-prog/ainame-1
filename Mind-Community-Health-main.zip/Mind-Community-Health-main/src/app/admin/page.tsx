import { Suspense } from "react";
import { connection } from "next/server";
import { AdminView } from "@/components/admin/AdminView";
import { Login } from "@/components/admin/Login";
import { listAllResources } from "@/lib/actions";
import { connectionProblem } from "@/lib/server/env";
import { getSitePages } from "@/lib/server/pages";
import { currentOwner } from "@/lib/server/supabase";

export const metadata = { title: "Owner panel", robots: { index: false } };

type Search = Promise<Record<string, string | string[] | undefined>>;

export default function AdminPage({ searchParams }: { searchParams: Search }) {
  return (
    <Suspense fallback={<div className="grid min-h-screen place-items-center text-sm text-muted">Loading…</div>}>
      <AdminGate searchParams={searchParams} />
    </Suspense>
  );
}

/** Reads the login cookie, so it runs per request (hence the Suspense above) */
async function AdminGate({ searchParams }: { searchParams: Search }) {
  // Per request from here on: the database client reads the clock, which Next refuses during prerender
  await connection();
  const problem = connectionProblem();
  const owner = await currentOwner();
  if (!owner) return <Login problem={problem} />;
  const [all, pages, sp] = await Promise.all([listAllResources(), getSitePages(), searchParams]);
  // ?tab=…&section=…&view=… : where the owner was before a refresh (see admin/Sections.tsx)
  const one = (v: string | string[] | undefined) => (typeof v === "string" ? v : undefined);
  const at = { tab: one(sp.tab), section: one(sp.section), view: one(sp.view) };
  return <AdminView email={owner} resources={all.ok ? all.data : []} pages={pages} loadError={all.ok ? null : all.error} problem={problem} at={at} />;
}
