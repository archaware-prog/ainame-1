import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans, Source_Serif_4 } from "next/font/google";
import { BottomNav, Footer, Header, VisitTracker, themeScript } from "@/components/Chrome";
import { getCatalog } from "@/lib/server/catalog";
import { getSitePages } from "@/lib/server/pages";
import { SITE } from "@/lib/site";
import { StoreProvider } from "@/lib/store";
import "./globals.css";

const heading = Source_Serif_4({ variable: "--font-heading", subsets: ["latin"], style: ["normal", "italic"] });
const body = Plus_Jakarta_Sans({ variable: "--font-body", subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: `${SITE.name}: ${SITE.tagline}`, template: `%s · ${SITE.name}` },
  description: SITE.description,
  applicationName: SITE.name,
  openGraph: { type: "website", siteName: SITE.name, locale: "en_IN" },
  twitter: { card: "summary_large_image" },
};

export const viewport: Viewport = {
  themeColor: SITE.themeColor,
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const [catalog, pages] = await Promise.all([getCatalog(), getSitePages()]);
  return (
    <html lang="en" className={`${heading.variable} ${body.variable} h-full antialiased`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="flex min-h-full flex-col font-sans">
        {/* Topics and page texts only: the material list is added by src/app/(library)/layout.tsx */}
        <StoreProvider topics={catalog.topics} pages={pages}>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <BottomNav />
        </StoreProvider>
        <VisitTracker />
      </body>
    </html>
  );
}
