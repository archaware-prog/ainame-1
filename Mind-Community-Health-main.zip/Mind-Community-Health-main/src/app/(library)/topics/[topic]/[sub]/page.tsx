import { Suspense } from "react";
import { notFound } from "next/navigation";
import { TopicView } from "@/components/TopicView";
import { getCatalog } from "@/lib/server/catalog";

export async function generateStaticParams() {
  const { topics } = await getCatalog();
  const params = topics.flatMap((t) => t.subtopics.map((s) => ({ topic: t.slug, sub: s.slug })));
  // Cache Components needs at least one entry; "_" renders the not-found page
  return params.length ? params : [{ topic: "_", sub: "_" }];
}

async function lookup(params: PageProps<"/topics/[topic]/[sub]">["params"]) {
  const { topic, sub } = await params;
  const t = (await getCatalog()).topics.find((x) => x.slug === topic);
  const s = t?.subtopics.find((x) => x.slug === sub);
  return t && s ? { topic: t, sub: s } : null;
}

export async function generateMetadata({ params }: PageProps<"/topics/[topic]/[sub]">) {
  const found = await lookup(params);
  if (!found) return { title: "Topic" };
  const title = `${found.sub.name} · ${found.topic.name}`;
  const description = `Free ${found.sub.name} notes, PPTs, question banks, previous papers and videos.`;
  return { title, description, openGraph: { title, description }, alternates: { canonical: `/topics/${found.topic.slug}/${found.sub.slug}` } };
}

// Reading the URL inside <Suspense> keeps navigation instant (a sub-topic the owner adds later is not prerendered)
export default function SubTopicPage({ params }: PageProps<"/topics/[topic]/[sub]">) {
  return (
    <Suspense fallback={<div className="min-h-[60vh]" aria-busy="true" />}>
      <SubTopic params={params} />
    </Suspense>
  );
}

async function SubTopic({ params }: Pick<PageProps<"/topics/[topic]/[sub]">, "params">) {
  const found = await lookup(params);
  if (!found) notFound();
  return <TopicView topicSlug={found.topic.slug} subSlug={found.sub.slug} />;
}
