import { Suspense } from "react";
import { notFound } from "next/navigation";
import { TopicView } from "@/components/TopicView";
import { getCatalog } from "@/lib/server/catalog";

export async function generateStaticParams() {
  const { topics } = await getCatalog();
  // Cache Components needs at least one entry; "_" renders the not-found page
  return topics.length ? topics.map((t) => ({ topic: t.slug })) : [{ topic: "_" }];
}

async function lookup(params: PageProps<"/topics/[topic]">["params"]) {
  const { topic } = await params;
  return (await getCatalog()).topics.find((t) => t.slug === topic);
}

export async function generateMetadata({ params }: PageProps<"/topics/[topic]">) {
  const topic = await lookup(params);
  if (!topic) return { title: "Topic" };
  const description = `Free ${topic.name} notes, PPTs, question banks, previous papers and videos.`;
  return { title: topic.name, description, openGraph: { title: topic.name, description }, alternates: { canonical: `/topics/${topic.slug}` } };
}

// Reading the URL inside <Suspense> keeps navigation instant (a topic the owner adds later is not prerendered)
export default function TopicPage({ params }: PageProps<"/topics/[topic]">) {
  return (
    <Suspense fallback={<div className="min-h-[60vh]" aria-busy="true" />}>
      <TopicBody params={params} />
    </Suspense>
  );
}

async function TopicBody({ params }: Pick<PageProps<"/topics/[topic]">, "params">) {
  const topic = await lookup(params);
  if (!topic) notFound();
  return <TopicView topicSlug={topic.slug} />;
}
