import { Suspense } from "react";
import { notFound } from "next/navigation";
import { HomeView } from "@/components/HomeView";
import { TopicView } from "@/components/TopicView";
import { getCatalog } from "@/lib/server/catalog";
import { TYPE_LABEL, placeNames } from "@/lib/types";

// The link the Share button sends. It shows the item's sub-topic page with this item already open, and
// gives WhatsApp and other apps the item's own title and preview image.

export async function generateStaticParams() {
  const { resources } = await getCatalog();
  // Cache Components needs at least one entry; "_" renders the not-found page
  return resources.length ? resources.map((r) => ({ id: r.id })) : [{ id: "_" }];
}

async function lookup(params: PageProps<"/item/[id]">["params"]) {
  const { id } = await params;
  const { topics, resources } = await getCatalog();
  const r = resources.find((x) => x.id === id);
  return r ? { r, place: placeNames(r, topics)[0] } : null;
}

export async function generateMetadata({ params }: PageProps<"/item/[id]">) {
  const found = await lookup(params);
  if (!found) return { title: "Not found" };
  const { r, place } = found;
  const description = `Free ${TYPE_LABEL[r.type].toLowerCase()}${place ? ` for ${place.sub.name}` : ""}. Open it in one tap, no sign-up needed.`;
  // The share link shows the sub-topic page, so Google is pointed at that page as the real one
  // (no duplicate copies in search). WhatsApp and other apps still get this item's own title and image.
  const canonical = place ? `/topics/${place.topic.slug}/${place.sub.slug}` : "/";
  return { title: r.title, description, openGraph: { title: r.title, description }, alternates: { canonical } };
}

// Reading the URL inside <Suspense> keeps navigation instant (new uploads are not prerendered)
export default function ItemPage({ params }: PageProps<"/item/[id]">) {
  return (
    <Suspense fallback={<div className="min-h-[60vh]" aria-busy="true" />}>
      <Item params={params} />
    </Suspense>
  );
}

async function Item({ params }: Pick<PageProps<"/item/[id]">, "params">) {
  const found = await lookup(params);
  if (!found) notFound();
  // An item under no sub-topic opens over the home page
  return found.place ? <TopicView topicSlug={found.place.topic.slug} subSlug={found.place.sub.slug} /> : <HomeView />;
}
