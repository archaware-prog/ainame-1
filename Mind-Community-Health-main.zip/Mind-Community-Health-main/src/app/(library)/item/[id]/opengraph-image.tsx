import { OG_SIZE, ogCard } from "@/lib/og";
import { getCatalog } from "@/lib/server/catalog";
import { TYPE_LABEL, placeNames } from "@/lib/types";

export const alt = "Free study material";
export const size = OG_SIZE;
export const contentType = "image/png";

export default async function Image({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { topics, resources } = await getCatalog();
  const r = resources.find((x) => x.id === id);
  const place = r && placeNames(r, topics)[0];
  return ogCard({
    kicker: r ? (r.type === "book" ? "Book · on Amazon" : `Free ${TYPE_LABEL[r.type]}`) : "Free study material",
    title: r?.title ?? "Notes, PPTs & videos",
    footer: place ? `${place.topic.name} · ${place.sub.name}` : "Open it in one tap",
  });
}
