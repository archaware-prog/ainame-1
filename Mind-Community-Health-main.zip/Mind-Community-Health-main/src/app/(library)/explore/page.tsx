import { Suspense } from "react";
import { ExploreView } from "@/components/ExploreView";

export const metadata = { title: "Explore" };

export default function ExplorePage() {
  return (
    <Suspense fallback={<div className="px-4 lg:px-8 py-10 text-sm text-muted">Loading…</div>}>
      <ExploreView />
    </Suspense>
  );
}
