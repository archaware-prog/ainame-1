import { ViewerProvider } from "@/components/Viewer";
import { getCatalog } from "@/lib/server/catalog";
import { ResourcesProvider } from "@/lib/store";

// Only the pages that list materials (home, search, topics, shared item links) send the
// material list to the browser. About, Contact, Workshops and the owner panel stay light.
// The "(library)" folder name is not part of any web address.
export default async function LibraryLayout({ children }: LayoutProps<"/">) {
  const { resources } = await getCatalog();
  return (
    <ResourcesProvider resources={resources}>
      <ViewerProvider>{children}</ViewerProvider>
    </ResourcesProvider>
  );
}
