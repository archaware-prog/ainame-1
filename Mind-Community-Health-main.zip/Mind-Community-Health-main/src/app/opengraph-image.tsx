import { OG_SIZE, ogCard } from "@/lib/og";
import { SITE } from "@/lib/site";

export const alt = `${SITE.name}: ${SITE.tagline}`;
export const size = OG_SIZE;
export const contentType = "image/png";

export default function Image() {
  return ogCard({ kicker: "Learn · Understand · Apply", title: "For a Healthier Individual and a Healthier Society", footer: "Free notes, PPTs & videos · No sign-up" });
}
