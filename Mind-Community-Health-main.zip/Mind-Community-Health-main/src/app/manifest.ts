import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";

// Lets students add the site to their phone's home screen like an app
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: `${SITE.name}: free study material`,
    short_name: SITE.name,
    description: "Free notes, PPTs, question banks and videos. No sign-up needed.",
    start_url: "/",
    display: "standalone",
    background_color: SITE.background,
    theme_color: SITE.themeColor,
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
