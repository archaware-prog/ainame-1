import type { ComponentType } from "react";
import { Clock, Mail, MapPin, MessageCircle, Phone, Play } from "lucide-react";
import { RichText } from "@/components/RichText";
import { getSitePages } from "@/lib/server/pages";

export async function generateMetadata() {
  const { contact } = await getSitePages();
  return { title: contact.heading, description: contact.note.slice(0, 160) || "How to reach us.", alternates: { canonical: "/contact" } };
}

/** wa.me needs the country code; a 10-digit Indian number gets 91 in front */
const whatsappLink = (n: string) => {
  const digits = n.replace(/\D/g, "");
  return `https://wa.me/${digits.length === 10 ? `91${digits}` : digits}`;
};

type Item = { icon: ComponentType<{ size?: number | string }>; label: string; value: string; href?: string; color: string };

export default async function ContactPage() {
  const { contact: c } = await getSitePages();
  const items: Item[] = [
    { icon: Mail, label: "Email", value: c.email, href: `mailto:${c.email}`, color: "#1f5fae" },
    { icon: Phone, label: "Phone", value: c.phone, href: `tel:${c.phone.replace(/[^\d+]/g, "")}`, color: "#1b8c78" },
    { icon: MessageCircle, label: "WhatsApp", value: c.whatsapp, href: whatsappLink(c.whatsapp), color: "#25a244" },
    { icon: MapPin, label: "Address", value: c.address, href: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.address)}`, color: "#e5772c" },
    { icon: Clock, label: "Timings", value: c.timings, color: "#6a4aa5" },
    { icon: Play, label: "YouTube", value: c.youtube, href: c.youtube, color: "#ff0033" },
    { icon: InstagramIcon, label: "Instagram", value: c.instagram, href: c.instagram, color: "#dd2a7b" },
  ].filter((i) => i.value);

  return (
    <div className="px-4 lg:px-8">
      <h1 className="mt-8 font-display text-3xl font-bold tracking-tight text-navy-900 sm:text-5xl dark:text-white">{c.heading}</h1>
      <div className="mt-3 h-1 w-40 rounded-full bg-linear-to-r from-leaf-600 to-transparent" />
      {c.note && (
        <div className="mt-6 max-w-3xl">
          <RichText text={c.note} />
        </div>
      )}

      {items.length === 0 ? (
        <p className="card mt-8 p-8 text-center text-sm text-muted">Contact details are coming soon.</p>
      ) : (
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {items.map((i) => {
            const body = (
              <>
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-white" style={{ background: i.color }}>
                  <i.icon size={20} />
                </span>
                <span className="min-w-0">
                  <span className="block text-xs font-semibold uppercase tracking-wider text-muted">{i.label}</span>
                  <span className="block whitespace-pre-line break-words text-sm font-medium">{i.label === "YouTube" || i.label === "Instagram" ? i.value.replace(/^https:\/\/(www\.)?/, "") : i.value}</span>
                </span>
              </>
            );
            const cls = "card flex items-center gap-3 p-4";
            return i.href ? (
              <a key={i.label} href={i.href} target={i.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className={`${cls} transition hover:-translate-y-0.5 hover:border-brand-500/40`}>
                {body}
              </a>
            ) : (
              <div key={i.label} className={cls}>
                {body}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** lucide-react no longer ships brand logos, so a simple camera outline stands in */
function InstagramIcon({ size = 20 }: { size?: number | string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
    </svg>
  );
}
