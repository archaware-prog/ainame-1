# StudyDrop (placeholder name)

Free e-content website: notes, PPTs (as PDF), question banks, papers and the client's own videos.
Students never log in; one owner manages everything at `/admin`.

## First-time setup

1. Create the Supabase and Cloudflare R2 accounts and fill in `.env.local` — see `../docs/SETUP-KEYS.md`.
2. Supabase → SQL Editor → run `supabase/schema.sql`.
3. `node --env-file=.env.local scripts/check-setup.mjs` tests every key and says what to fix.
   Running it again is safe: it only adds what is missing, and the one-time topic seed/move is
   recorded in the `migrations` table so it never repeats.
4. Optional, for testing only: `node --env-file=.env.local scripts/seed.mjs` loads the old demo's
   sample PDFs. It predates topics, so its items show under no topic until you tick one in /admin.
   Delete those items before launch (the videos are not the client's).

## How material is organised

Topic cards on the home page (e.g. Community Medicine) → sub-topics inside each (e.g. 1st Year MBBS).
The owner edits both in `/admin` → **Topics** (name, icon, colour, order) and ticks one or more
sub-topics on every upload. Tables `topics`, `subtopics`; an item stores its places in
`resources.subtopics` as `"topic-slug/sub-slug"` keys. Pages: `/topics/[topic]`, `/topics/[topic]/[sub]`.
The old `subject_slug`, `years`, `branches`, `exam_tags` columns and the `subjects`/`branches` tables
are no longer used by the code.

## Run it

```bash
npm install
npm run dev                                          # http://localhost:3000
npm run build
node node_modules/next/dist/bin/next start -p 3100   # not "npx next start" (the zap proxy breaks it)
```

## How it works

| Piece | Where |
| --- | --- |
| Public data (topics, sub-topics + visible items) | `src/lib/server/catalog.ts`, cached with `use cache` + tag `catalog`; loaded once in `app/layout.tsx` and read through the hooks in `src/lib/store.ts` |
| Owner actions (login, add/edit/delete, topics, stats) | `src/lib/actions.ts`. Each checks the login, writes with the secret key, then calls `updateTag("catalog")` |
| PDF storage | Private Cloudflare R2 bucket (`src/lib/server/r2.ts`). The owner's browser uploads the PDF **and a WebP image of every page** (made with pdf.js in `components/admin/upload.ts`) through presigned links. Layout: `files/<name>-<time>/original.pdf`, `…/p1`, `…/p2` |
| PDF viewer | `/api/files/[id]` returns signed page-image links (stable for an hour so browsers cache them). View-only files never send the PDF. Works on Android, where PDFs in iframes do not |
| pdf.js files | `npm install` copies the worker, fonts and decoders to `public/pdfjs/` (`scripts/copy-pdfjs.mjs`, git-ignored) |
| Downloads | `/api/files/[id]/download` checks the switch, counts it, then redirects to a two-minute signed link |
| Usage stats | `/api/track` (visits, views, plays) → `events` table; dashboard reads the `stats_*` SQL functions |
| Keep-alive | `vercel.json` cron → `/api/keep-alive` once a day, so the free database never pauses |
| Branding | `src/lib/site.ts` (name, wording, colours). Logo: `public/logo.png` in the header; all icons (`app/icon.png`, `favicon.ico`, `apple-icon.png`, `public/icons/*`) are made from one image with `node scripts/make-logo.mjs "<logo on black>.jpeg"` |
| Share previews / SEO | `app/item/[id]` (share link target), `opengraph-image.tsx`, `sitemap.ts`, `robots.ts` |

Security: Row Level Security is on. The public key can only read topics, sub-topics, site pages and visible items; all
writes and all usage data go through the server. `OWNER_EMAIL` must match the logged-in user.

## Limits to know

- R2 free plan: 10 GB storage, free downloads. Site limits: 50 MB and 500 pages per PDF (`MAX_MB` in `upload.ts`, `MAX_PAGES` in `r2.ts`).
- The R2 bucket's CORS policy must list every address the owner uploads from (see SETUP-KEYS.md, Part 2 step 4).
- If an upload is abandoned half-way, its files stay in R2 (no item points at them). Harmless; delete the folder in the R2 dashboard if it matters.
- PowerPoints are uploaded as PDF.
- `/api/track` is open (it has to be, for anonymous students), so someone could inflate the counts.
