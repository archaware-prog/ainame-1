-- StudyDrop database. Paste the whole file into Supabase → SQL Editor → Run.
-- Safe to run again: it only creates what is missing.
--
-- Security model: Row Level Security is on for every table. The public (publishable key) may only
-- READ subjects and visible resources. All writes go through the website's server, which checks
-- the owner's login and then uses the secret key.

create table if not exists public.subjects (
  slug        text primary key check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text not null,
  emoji       text not null default '📘',
  gradient    text not null default 'from-brand-500 to-pop-500',
  description text not null default '',
  position    int  not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.resources (
  id             uuid primary key default gen_random_uuid(),
  title          text not null,
  subject_slug   text references public.subjects(slug) on update cascade on delete restrict,
  type           text not null check (type in ('notes', 'slides', 'qbank', 'paper', 'video', 'book')),
  unit           int check (unit between 1 and 20),
  -- R2 folder (private bucket) holding original.pdf and one image per page (p1, p2, …)
  file_id        text,
  file_pages     int,
  file_bytes     bigint,
  video_url      text,
  allow_download boolean not null default true,
  exam_tags      text[] not null default '{}',
  hidden         boolean not null default false,
  added_at       timestamptz not null default now(),
  constraint resources_file_or_video check (
    (type = 'video' and video_url is not null) or (type <> 'video' and file_id is not null)
  )
);
create index if not exists resources_subject_idx on public.resources (subject_slug);
create index if not exists resources_added_idx on public.resources (added_at desc);

-- Branches (CS, IT, Civil…) the owner can add, rename and reorder in the owner panel
create table if not exists public.branches (
  slug        text primary key check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text not null,
  position    int  not null default 0,
  created_at  timestamptz not null default now()
);
insert into public.branches (slug, name, position) values
  ('cs', 'Computer Science (CS)', 1),
  ('it', 'Information Technology (IT)', 2),
  ('civil', 'Civil', 3),
  ('other', 'Other', 4)
on conflict (slug) do nothing;

-- About Us and Contact Us text, edited by the owner in the panel (added 2026-11-18).
-- The About photo's R2 key sits inside `content`; the website serves it through /api/site-photo.
create table if not exists public.site_pages (
  slug        text primary key check (slug in ('about', 'contact', 'home')),
  content     jsonb not null default '{}',
  updated_at  timestamptz not null default now()
);
-- 'home' (header photos, gallery, workshops, vision & mission) added 2026-11-19; widen the check on existing databases
alter table public.site_pages drop constraint if exists site_pages_slug_check;
alter table public.site_pages add constraint site_pages_slug_check check (slug in ('about', 'contact', 'home'));

-- Which years (1–4) and branches an item shows under. Empty branches = every branch of those years.
-- Added 2026-11-18; safe to re-run this whole file on a live database.
alter table public.resources add column if not exists years    int[]  not null default '{}';
alter table public.resources add column if not exists branches text[] not null default '{}';
alter table public.resources drop constraint if exists resources_years_valid;
alter table public.resources add constraint resources_years_valid check (years <@ array[1, 2, 3, 4]);

-- ---------- topics (added 2026-11-18, replaces years, branches, subjects and exam prep) ----------
-- Topic cards on the home page (Community Medicine, Mental Health…) and the sub-topics inside each.
-- The owner adds, renames, reorders and deletes both in the owner panel. Slugs never change after creation.
create table if not exists public.topics (
  slug        text primary key check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text not null,
  icon        text not null default 'book',
  color       text not null default '#1f5fae' check (color ~ '^#[0-9a-f]{6}$'),
  position    int  not null default 0,
  created_at  timestamptz not null default now()
);
create table if not exists public.subtopics (
  topic_slug  text not null references public.topics(slug) on delete restrict,
  slug        text not null check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name        text not null,
  position    int  not null default 0,
  created_at  timestamptz not null default now(),
  primary key (topic_slug, slug)
);
-- Optional YouTube link per sub-topic (added 2026-11-19)
alter table public.subtopics add column if not exists youtube_url text;

-- Client asked on 2026-11-19 to rename this card; the web address stays /topics/research-publications
update public.topics set name = 'Books, Research & Publications' where slug = 'research-publications' and name = 'Research & Publications';

-- Sub-topics an item shows under, each written as 'topic-slug/subtopic-slug'
alter table public.resources add column if not exists subtopics text[] not null default '{}';

-- 2026-11-21: "book" items are a link to the client's book on Amazon (kept in video_url, no PDF)
alter table public.resources drop constraint if exists resources_type_check;
alter table public.resources add constraint resources_type_check check (type in ('notes', 'slides', 'qbank', 'paper', 'video', 'book'));
alter table public.resources drop constraint if exists resources_file_or_video;
alter table public.resources add constraint resources_file_or_video check (
  (type in ('video', 'book') and video_url is not null) or (type not in ('video', 'book') and file_id is not null)
);

-- One-time jobs that must never run twice (re-running this file is safe)
create table if not exists public.migrations (
  name    text primary key,
  ran_at  timestamptz not null default now()
);

do $$
begin
  if exists (select 1 from public.migrations where name = 'topics-v1') then return; end if;

  -- Starter list, from the client's reference design
  insert into public.topics (slug, name, icon, color, position) values
    ('community-medicine',    'Community Medicine',            'stethoscope', '#1f5fae', 1),
    ('mental-health',         'Mental Health & Well-being',    'brain',       '#3b8b3f', 2),
    ('human-values',          'Human Values & Relationships',  'handshake',   '#6a4aa5', 3),
    ('health-awareness',      'Health Awareness',              'sprout',      '#1b8c78', 4),
    ('research-publications', 'Books, Research & Publications', 'book',      '#e5772c', 5)
  on conflict (slug) do nothing;
  insert into public.subtopics (topic_slug, slug, name, position) values
    ('community-medicine',    '1st-year-mbbs',               '1st Year MBBS',               1),
    ('community-medicine',    '2nd-year-mbbs',               '2nd Year MBBS',               2),
    ('community-medicine',    '3rd-year-mbbs',               '3rd Year MBBS',               3),
    ('mental-health',         'stress-management',           'Stress Management',           1),
    ('mental-health',         'emotional-well-being',        'Emotional Well-being',        2),
    ('mental-health',         'mental-health-resources',     'Mental Health Resources',     3),
    ('mental-health',         'neuro-linguistic-programming','Neuro-Linguistic Programming',4),
    ('human-values',          'ethics-and-values',           'Ethics & Values',             1),
    ('human-values',          'communication',               'Communication',               2),
    ('human-values',          'social-harmony',              'Social Harmony',              3),
    ('health-awareness',      'healthy-lifestyle',           'Healthy Lifestyle',           1),
    ('health-awareness',      'nutrition-and-wellness',      'Nutrition & Wellness',        2),
    ('health-awareness',      'disease-prevention',          'Disease Prevention',          3),
    ('research-publications', 'articles-and-papers',         'Articles & Papers',           1),
    ('research-publications', 'educational-material',        'Educational Material',        2),
    ('research-publications', 'useful-links',                'Useful Links',                3)
  on conflict do nothing;

  -- Move existing material across. Anything tagged NLP (branch or subject) goes to
  -- Mental Health › Neuro-Linguistic Programming; everything else by year to Community Medicine › Nth Year MBBS.
  update public.resources r set subtopics = array['mental-health/neuro-linguistic-programming']
  where exists (select 1 from public.branches b where b.slug = any(r.branches) and (b.name ilike '%neuro%' or b.name ilike '%nlp%'))
     or exists (select 1 from public.subjects s where s.slug = r.subject_slug and (s.name ilike '%neuro%' or s.name ilike '%nlp%'));

  if exists (select 1 from public.resources where 4 = any(years) and subtopics = '{}') then
    insert into public.subtopics (topic_slug, slug, name, position) values ('community-medicine', '4th-year-mbbs', '4th Year MBBS', 4)
    on conflict do nothing;
  end if;

  update public.resources r set subtopics = (
    select array_agg('community-medicine/' || (array['1st','2nd','3rd','4th'])[y] || '-year-mbbs' order by y) from unnest(r.years) y
  )
  where r.subtopics = '{}' and r.years <> '{}';

  insert into public.migrations (name) values ('topics-v1');
end $$;

-- One row per visit, file view, download or video play. No personal data is stored.
create table if not exists public.events (
  id          bigint generated always as identity primary key,
  kind        text not null check (kind in ('visit', 'view', 'download', 'play')),
  resource_id uuid references public.resources(id) on delete set null,
  device      text not null default 'desktop' check (device in ('mobile', 'tablet', 'desktop')),
  created_at  timestamptz not null default now()
);
create index if not exists events_created_idx on public.events (created_at);
create index if not exists events_resource_idx on public.events (resource_id);

-- Wrong owner-login tries, one row each, used to block password guessing (added 2026-11-19).
-- Only the website's server reads or writes it; rows older than a day are deleted automatically.
create table if not exists public.login_attempts (
  id  bigint generated always as identity primary key,
  ip  text not null,
  at  timestamptz not null default now()
);
create index if not exists login_attempts_ip_at_idx on public.login_attempts (ip, at);

-- ---------- security ----------

alter table public.subjects  enable row level security;
alter table public.resources enable row level security;
alter table public.events    enable row level security;
alter table public.branches  enable row level security;
alter table public.site_pages enable row level security;
alter table public.topics     enable row level security;
alter table public.subtopics  enable row level security;
alter table public.migrations enable row level security;
alter table public.login_attempts enable row level security;  -- no policies: the public can neither read nor write it

drop policy if exists "public can read topics" on public.topics;
create policy "public can read topics" on public.topics for select using (true);

drop policy if exists "public can read subtopics" on public.subtopics;
create policy "public can read subtopics" on public.subtopics for select using (true);

drop policy if exists "public can read site pages" on public.site_pages;
create policy "public can read site pages" on public.site_pages for select using (true);

drop policy if exists "public can read subjects" on public.subjects;
create policy "public can read subjects" on public.subjects for select using (true);

drop policy if exists "public can read branches" on public.branches;
create policy "public can read branches" on public.branches for select using (true);

drop policy if exists "public can read visible resources" on public.resources;
create policy "public can read visible resources" on public.resources for select using (not hidden);

-- events: no policies, so only the server (secret key) can read or write them

-- ---------- dashboard numbers ----------

create or replace function public.stats_totals(since timestamptz)
returns table (kind text, n bigint)
language sql stable set search_path = '' as $$
  select e.kind, count(*) from public.events e where e.created_at >= since group by e.kind;
$$;

create or replace function public.stats_by_resource(since timestamptz)
returns table (resource_id uuid, kind text, n bigint)
language sql stable set search_path = '' as $$
  select e.resource_id, e.kind, count(*) from public.events e
  where e.created_at >= since and e.resource_id is not null
  group by e.resource_id, e.kind;
$$;

create or replace function public.stats_by_device(since timestamptz)
returns table (device text, n bigint)
language sql stable set search_path = '' as $$
  select e.device, count(*) from public.events e
  where e.created_at >= since and e.kind = 'visit'
  group by e.device;
$$;

create or replace function public.stats_daily(since timestamptz)
returns table (day date, n bigint)
language sql stable set search_path = '' as $$
  select (e.created_at at time zone 'Asia/Kolkata')::date, count(*) from public.events e
  where e.created_at >= since and e.kind = 'visit'
  group by 1 order by 1;
$$;

revoke execute on function public.stats_totals(timestamptz)      from public, anon, authenticated;
revoke execute on function public.stats_by_resource(timestamptz) from public, anon, authenticated;
revoke execute on function public.stats_by_device(timestamptz)   from public, anon, authenticated;
revoke execute on function public.stats_daily(timestamptz)       from public, anon, authenticated;
grant execute on function public.stats_totals(timestamptz)      to service_role;
grant execute on function public.stats_by_resource(timestamptz) to service_role;
grant execute on function public.stats_by_device(timestamptz)   to service_role;
grant execute on function public.stats_daily(timestamptz)       to service_role;
