# Finishing the site without Claude

Everything in Phase 1 is written. What is left is **connecting the real accounts, testing, branding
and going live**. Do the steps in order; each one says how you know it worked.

All commands run in a terminal inside `web/`. If something fails, look at the **Troubleshooting**
table at the end first.

---

## Step 1 — Keys (T-14)

1. Follow `docs/SETUP-KEYS.md` with the client's email. It ends with a filled-in `web/.env.local`.
2. Run the checker:

   ```bash
   node --env-file=.env.local scripts/check-setup.mjs
   ```

   It tests every key against the real Supabase and R2 accounts (it uploads and deletes one tiny
   test file). Fix every `FIX` line and run it again until the last line says **Everything is connected.**

## Step 2 — Run it on your computer with test data (T-16, T-18)

```bash
npm install
node --env-file=.env.local scripts/seed.mjs     # optional: 17 sample items (they show under no topic until ticked in /admin)
npm run build
node node_modules/next/dist/bin/next start -p 3100
```

Open <http://localhost:3100>. Use `next start` this way, not `npx next start` (the zap proxy breaks that).
`npm run dev` (port 3000) also works for quick looks.

## Step 3 — Test checklist (T-16 to T-23)

Tick each one in a normal browser. Open DevTools (F12) → **Network** tab for the two marked 🔍.

**Public site**
- [ ] Home shows the topic cards, newest items and videos. Search finds an item by a word in its title.
- [ ] Clicking a topic card opens its sub-topics; a sub-topic page lists its items with the type tabs
      (Notes / Slides / …) and, when there is more than one unit, a unit picker.
- [ ] Open a PDF that allows download: pages appear as images; **Download** saves a `.pdf` with the item's name.
- [ ] 🔍 Open a **view-only** PDF (e.g. "Stacks & Queues"): pages appear, there is no Download button, and the
      Network tab shows **no request ending in `.pdf`** (only `p1`, `p2`… images). This is the main promise.
- [ ] Visiting `/api/files/<id>/download` for a view-only item says "Download is turned off".
- [ ] A YouTube video opens in the pop-up and plays.
- [ ] **Share** on an item copies an `/item/…` link; opening it shows that item.
- [ ] On a phone (or DevTools phone mode, 390 px wide): no sideways scrolling, bottom menu works, dark mode looks right.

**Owner panel** (`/admin`)
- [ ] Wrong password → "That email or password is not right." Right password → panel opens.
- [ ] **Add material** → PDF: pick a real PDF of 10–30 pages. The bar fills, then it appears on the public
      site within a few seconds. Open it: every page is there and readable.
- [ ] 🔍 During that upload the Network tab shows `PUT` requests to `…r2.cloudflarestorage.com` that succeed.
- [ ] **Add material** → video: paste a YouTube link; it appears and plays.
- [ ] **Edit** an item: change the title. Then edit again and choose a new PDF (replace file). The new pages show.
- [ ] Switch **download** off for an item → on the public site it becomes view-only.
- [ ] **Hide** an item → it disappears from the public site. Un-hide → it comes back.
- [ ] **Delete** an item → gone. In Cloudflare → R2 → bucket, its `files/…` folder is gone too.
- [ ] **Topics**: add a topic (pick icon and colour), rename it, move it up/down. Add a sub-topic, rename
      it, move it, delete an empty one. Deleting a sub-topic that still has items, or a topic that still
      has sub-topics, is refused with a message.
- [ ] **Dashboard**: after clicking around the public site, visits / views / downloads / plays go up.
      7 / 30 / 90-day buttons work. Devices shows mobile/desktop.
- [ ] Log out → `/admin` asks for the password again.

When all are ticked, move T-16 to T-23 to **Done** in `progress.md` (see "Updating progress.md" below).

## Step 4 — The client's name, logo and colours (T-24)

| What | Where |
| --- | --- |
| Name, tagline, description, theme colour | `web/src/lib/site.ts` (one file) |
| Logo text in the header | `Logo()` in `web/src/components/Chrome.tsx` |
| Brand colours (purple / pink) | `web/src/app/globals.css`, the `--color-brand-*` and `--color-pop-*` lines |
| Logo, browser tab icon, phone app icons | Run `node scripts/make-logo.mjs "<new logo>.jpeg"` in `web/` (logo drawn on a black background). It writes `public/logo.png`, `src/app/icon.png`, `favicon.ico`, `apple-icon.png` and `public/icons/*` |

Search the code for `StudyDrop` to catch any leftover mentions. Then `npm run lint` and `npm run build`.

## Step 5 — Instagram reels (T-15)

Add one of the client's public reels as a video item. It should play in the pop-up. Some reels
(private, collab, remix) cannot play inside other sites; those show an **Open on Instagram** button, which is expected.

## Step 6 — Remove the test data

Before launch, delete every sample item in `/admin` (the sample videos are not the client's). Then add
the client's real topics, sub-topics and material.

## Step 7 — Go live on Vercel (T-27)

1. Commit and push `web/` to GitHub (`git push`). The repo is `github.com/chinmayDipke/StudyDrop`; move it to
   the client's GitHub later if they want to own it.
2. <https://vercel.com> → sign up with the client's email → **Add New → Project** → import the repo.
   Framework: Next.js (auto). Root directory: the repo root.
3. **Environment Variables**: add all 8 values from `.env.local`, plus:
   - `NEXT_PUBLIC_SITE_URL` = the real address, e.g. `https://studydrop.in` (no `/` at the end)
   - `CRON_SECRET` = any long random text (e.g. from a password generator)
4. **Deploy**. Open the `…vercel.app` address it gives you.
5. **Domain**: Vercel → Project → **Settings → Domains** → add the client's domain. Vercel shows the DNS
   records to add at the domain seller (GoDaddy, Hostinger…). Add exactly those. HTTPS turns on by itself.
6. **R2 CORS**: add the live addresses (`https://domain`, `https://www.domain`, the `…vercel.app` one) to the
   bucket's CORS policy (SETUP-KEYS.md, Part 2 step 4). **Without this, uploads work on your computer but fail on the live site.**
7. After changing any environment variable in Vercel, **redeploy** (Deployments → ⋯ → Redeploy).
8. Run the checker once more with the live address in `.env.local`'s `NEXT_PUBLIC_SITE_URL`; it then also tests CORS for it.

Note: Vercel's free (Hobby) plan is for non-commercial sites. A free study site fits. If the client later
sells anything on it, move to Vercel Pro.

## Step 8 — Launch check (T-26, T-28)

- [ ] Repeat the Step 3 checklist on the live address, on a real Android phone and an iPhone.
- [ ] Upload one PDF from the live site (proves CORS is right).
- [ ] Next day: Vercel → Project → **Settings → Cron Jobs** shows `/api/keep-alive` ran (T-26).
- [ ] Chrome DevTools → **Lighthouse** → Mobile → Analyze. Aim for 90+ on Performance and Accessibility.
- [ ] Share an item link on WhatsApp: the preview shows the title and image (T-25).
- [ ] Google Search Console: add the domain and submit `https://domain/sitemap.xml`.

## Updating progress.md

Move a finished task line to **Done** in this form, then recount the bar:

```
- [x] T-19 PDF uploads to R2 — proof: web/src/components/admin/upload.ts · verified: uploaded a 24-page PDF on localhost (2026-11-05)
```

```bash
node .claude/kit/progress.js        # run from the project root, not web/
```

---

## Troubleshooting

| What you see | Why | Fix |
| --- | --- | --- |
| Site shows no material, terminal says "Supabase keys are missing" | `.env.local` empty or not in `web/` | Fill it, restart the server |
| `/admin` says "keys are missing" | Same | Same, then run the checker |
| Upload: "Upload failed. Check your internet…" but internet works | Bucket CORS does not list this address | SETUP-KEYS.md Part 2 step 4. Address must match exactly: `http` vs `https`, port, no `/` at the end |
| Upload: "The upload did not finish" | A page image did not arrive (connection dropped) | Try again |
| Upload: "This PDF has a password" | Locked PDF | Remove the password (print to PDF again) |
| Upload: "larger than 50 MB" | Site limit | Compress it (ilovepdf.com → Compress PDF), or raise `MAX_MB` in `web/src/components/admin/upload.ts` |
| Upload: "File storage (Cloudflare R2) is not connected yet" | R2 values missing | Fill the four `R2_*` values |
| PDF viewer: "This file could not be opened" | R2 keys wrong, or files deleted in R2 | Run the checker |
| Pages show as broken images after the viewer was open for over an hour | Page links expire after 1–2 hours | Close and reopen the file |
| Login: "This account is not the site owner" | `OWNER_EMAIL` does not match the Supabase user | Fix `OWNER_EMAIL`, restart / redeploy |
| Owner changes do not show on the public site | Would be a caching bug | Reload; if it persists, check the action calls `changed()` in `web/src/lib/actions.ts` |
| Supabase project "paused" | A week with no activity (before the cron was live) | Supabase dashboard → Restore. The daily cron prevents it after launch |
| `npm run build` fails after editing | Read the first error line; it names the file and line | Undo the last edit if unsure (`git diff`, `git checkout -- <file>`) |
| `npm install` then pdf.js errors in the owner panel | `public/pdfjs/` missing | `node scripts/copy-pdfjs.mjs` |

## Not built (Phase 2, only if the client asks)

T-29 to T-34 in `progress.md`: MCQ quizzes, bookmarks, recently viewed, mark as done, new-upload alerts,
"Helpful" button and topic requests. Their scope is in the proposal, §7.
