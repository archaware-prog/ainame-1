# Getting the keys for the live site

Two free accounts are needed: **Supabase** (database + owner login) and **Cloudflare R2** (PDF
storage). Create both with the **client's** email so the client owns them. Takes about 20 minutes.

At the end you will have 8 values. Put them in `web/.env.local` (copy `web/.env.example`, fill it in).
That file is never committed to git. Do not paste the two **secret** values into chat, email or WhatsApp.

| # | Name in `.env.local` | Where it comes from | Secret? |
| - | --- | --- | --- |
| 1 | `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project URL | no |
| 2 | `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Supabase → publishable key (`sb_publishable_…`) | no |
| 3 | `SUPABASE_SECRET_KEY` | Supabase → secret key (`sb_secret_…`) | **yes** |
| 4 | `R2_ACCOUNT_ID` | Cloudflare → R2 → Account ID | no |
| 5 | `R2_ACCESS_KEY_ID` | Cloudflare → R2 API token → Access Key ID | no |
| 6 | `R2_SECRET_ACCESS_KEY` | Cloudflare → R2 API token → Secret Access Key | **yes** |
| 7 | `R2_BUCKET` | The bucket name you chose (Part 2, step 2) | no |
| 8 | `OWNER_EMAIL` | The owner's login email (Part 1, step 4) | no |

---

## Part 1 — Supabase

### 1. Create the project
1. Go to <https://supabase.com/dashboard> and sign up / sign in with the client's email.
2. **New project**.
   - **Name:** the site name (e.g. `studydrop`).
   - **Database password:** click *Generate*, then save it in a password manager. We do not need it
     for the site, but you cannot see it again.
   - **Region:** **Mumbai (ap-south-1)** — closest to Indian students.
   - **Plan:** Free.
3. Wait 1–2 minutes until the project shows as ready.

### 2. Copy the URL and the two keys
1. Left menu → **Project Settings** (gear icon) → **Data API**. Copy **Project URL**
   (looks like `https://abcdxyz.supabase.co`) → value **1**.
2. Left menu → **Project Settings** → **API Keys**.
   - **Publishable key** (`sb_publishable_…`) → value **2**.
   - **Secret keys** → click the eye / *Reveal* on the default secret key (`sb_secret_…`) → value **3**.
     If there is no secret key yet, click **Create new secret key**.

> **Older projects** only show a *Legacy API Keys* tab. Then use **anon public** for value 2 and
> **service_role** for value 3. Both work the same.

### 3. Turn off public sign-ups (important)
Only the owner should ever be able to log in.

**Authentication** → **Sign In / Providers** (on some dashboards: *Settings*) →
turn **off** "Allow new users to sign up" → **Save**.

### 4. Create the owner's login
**Authentication** → **Users** → **Add user** → **Create new user**.
- Email: the client's email.
- Password: a strong password the client will use at `/admin`.
- Tick **Auto Confirm User**.

Give that email and password to the client, not to us. The **email** is value **8**.

### 5. Create the tables
Open `web/supabase/schema.sql` in the project and copy all of it.
**SQL Editor** → **New query** → paste → **Run**. It should say *Success. No rows returned*.
Then **Table Editor** should show (among others) `topics`, `subtopics`, `resources`, `events` and
`site_pages`. The five starting topic cards are already filled in.

---

## Part 2 — Cloudflare R2 (PDF storage)

R2 keeps the PDFs in a **private** store. Students never get a direct address to a file: the site
hands out links that stop working after a short time. Free up to **10 GB** (about 1,500 typical PDFs
with their page images), with free downloads.

### 1. Create the account and turn on R2
1. Go to <https://dash.cloudflare.com/sign-up> and sign up with the client's email.
2. Left menu → **Storage & databases** → **R2 Object Storage** (on some dashboards just **R2**).
3. Click **Purchase R2 Plan** / **Add R2 subscription** and choose the free plan.
   **Cloudflare asks for a card (or PayPal) even for the free plan.** Nothing is charged while the
   site stays under 10 GB. Use the client's card.

### 2. Create the bucket
**R2** → **Create bucket**.
- **Name:** `studydrop-files` (lowercase, no spaces) → value **7**.
- **Location:** Automatic. **Storage class:** Standard.
- Click **Create bucket**.

Do **not** turn on "Public access", "r2.dev subdomain" or a custom domain for this bucket. It must stay private.

### 3. Create the key (API token)
1. Go back to the **R2** overview page. On the right, under **Account details**, copy the
   **Account ID** (32 letters and numbers) → value **4**.
2. Same page → **Manage API tokens** (or **API** → **Manage API tokens**) → **Create Account API token**
   (if only *User API token* is offered, that works too).
   - **Token name:** `studydrop-site`.
   - **Permissions:** **Object Read & Write**.
   - **Specify bucket(s):** *Apply to specific buckets only* → `studydrop-files`.
   - **TTL:** Forever.
   - **Create API Token**.
3. The next page shows the keys **only once**. Copy:
   - **Access Key ID** → value **5**.
   - **Secret Access Key** → value **6**.

   Ignore the "Token value" and the endpoint URLs on that page; the site does not need them.

### 4. Allow uploads from the website (CORS)
The owner panel sends PDFs from the owner's browser straight to R2. R2 blocks that unless the
website's address is on this list.

**R2** → `studydrop-files` → **Settings** → **CORS Policy** → **Add CORS policy** (or **Edit**) →
replace everything with:

```json
[
  {
    "AllowedOrigins": ["http://localhost:3000", "http://localhost:3100"],
    "AllowedMethods": ["PUT"],
    "AllowedHeaders": ["content-type"],
    "MaxAgeSeconds": 3600
  }
]
```

→ **Save**. When the site goes live, add its real address to `AllowedOrigins` (for example
`"https://studydrop.in"` and `"https://www.studydrop.in"`, and the `…vercel.app` address).
No trailing `/`. If uploads fail with "Upload failed. Check your internet…" while the internet works,
this list is the reason.

### Free plan limits to tell the client
- 10 GB of storage free. After that about $0.015 per GB a month (₹1–2 per GB).
- 1 million uploads and 10 million page/file reads a month free. A site this size uses a tiny part.
- PDFs up to 50 MB each (a site limit, to keep uploads quick; R2 itself allows far bigger). Up to 500 pages.
- Uploading takes longer than the file size suggests, because the owner's browser also makes an
  image of every page. Roughly 1 minute extra per 100 pages on a laptop.

---

## Part 3 — Put the values in the project

1. In `web/`, copy `.env.example` to a new file named `.env.local`.
2. Paste the 8 values after the `=` signs. No quotes, no spaces. Leave the last two
   (`NEXT_PUBLIC_SITE_URL`, `CRON_SECRET`) empty for now; they are only for Vercel.
3. In a terminal inside `web/`, run `node --env-file=.env.local scripts/check-setup.mjs`. It tests
   every value against the real accounts and says exactly what to fix. Run it until everything says OK.
   We never need the database password or the owner's password.

Later, when the site goes on Vercel, the same 8 values are added in **Vercel → Project → Settings →
Environment Variables**, plus:
- `NEXT_PUBLIC_SITE_URL`: the real address, e.g. `https://studydrop.in` (used in share previews and the sitemap).
- `CRON_SECRET`: any long random text. Vercel sends it with the daily keep-alive call so nobody else can trigger it.
