import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  cacheComponents: true,
  partialPrefetching: true,
  // Years, subjects and Exam Prep were replaced by topics (2026-11-18). Old shared links land on the home page.
  async redirects() {
    return ["/years/:path*", "/subjects/:path*", "/exam-prep"].map((source) => ({ source, destination: "/", permanent: false }));
  },
  // Basic protection on every page. A full Content-Security-Policy is left out on purpose: it would
  // need testing against YouTube/Instagram embeds, R2 images and the pdf.js worker first.
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          // No other website may show this site inside a frame (stops click-jacking tricks)
          { key: "Content-Security-Policy", value: "frame-ancestors 'self'" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
