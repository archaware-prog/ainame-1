// Builds every logo and icon file from one logo drawn on a black background.
// Usage (from web/): node scripts/make-logo.mjs "../new logo.jpeg"
//
// The black around the drawing is removed by a flood fill from the image edges, so the black
// outlines inside the drawing (brain lines, leaf edges) stay. Edge pixels blended with the black are
// un-blended, so the cut-out has no dark fringe on a light page.
import { writeFileSync } from "node:fs";
import sharp from "sharp";

const src = process.argv[2];
if (!src) throw new Error('Usage: node scripts/make-logo.mjs "<logo on black>.jpeg"');

const BG = 40; // a pixel whose brightest channel is below this, and touches the outside, is background
const FRINGE = 3; // how many pixels into the drawing to un-blend from black

const { data, info } = await sharp(src).removeAlpha().raw().toBuffer({ resolveWithObject: true });
const { width: w, height: h } = info;
const rgba = Buffer.alloc(w * h * 4);
const max = (i) => Math.max(data[i * 3], data[i * 3 + 1], data[i * 3 + 2]);

// 1. Flood fill the outside black (distance 0 = background)
const dist = new Int32Array(w * h).fill(-1);
let queue = [];
for (let x = 0; x < w; x++) queue.push(x, (h - 1) * w + x);
for (let y = 0; y < h; y++) queue.push(y * w, y * w + w - 1);
queue = queue.filter((i) => max(i) < BG);
for (const i of queue) dist[i] = 0;
for (let q = 0; q < queue.length; q++) {
  const i = queue[q], x = i % w, y = (i / w) | 0;
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const nx = x + dx, ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
    const n = ny * w + nx;
    if (dist[n] === -1 && max(n) < BG) { dist[n] = 0; queue.push(n); }
  }
}

// 2. Distance (in pixels) of drawing pixels from the background, up to FRINGE
let ring = queue;
for (let d = 1; d <= FRINGE; d++) {
  const next = [];
  for (const i of ring) {
    const x = i % w, y = (i / w) | 0;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
      const n = ny * w + nx;
      if (dist[n] === -1) { dist[n] = d; next.push(n); }
    }
  }
  ring = next;
}

// 3. Background → transparent; fringe → colour-to-alpha against black; the rest unchanged
for (let i = 0; i < w * h; i++) {
  const [r, g, b] = [data[i * 3], data[i * 3 + 1], data[i * 3 + 2]];
  let a = 255, k = 1;
  if (dist[i] === 0) a = 0;
  else if (dist[i] > 0) {
    const m = max(i);
    a = Math.min(255, Math.round(m * (255 / 200))); // fully opaque once bright enough
    k = a ? Math.min(255 / m, 255 / a) : 1;
  }
  rgba[i * 4] = Math.min(255, r * k);
  rgba[i * 4 + 1] = Math.min(255, g * k);
  rgba[i * 4 + 2] = Math.min(255, b * k);
  rgba[i * 4 + 3] = a;
}

const cut = await sharp(rgba, { raw: { width: w, height: h, channels: 4 } }).trim({ threshold: 0 }).png().toBuffer();
const meta = await sharp(cut).metadata();
console.log(`cut-out: ${meta.width}×${meta.height}`);

// Logo shown in the header (transparent)
await sharp(cut).resize({ height: 256 }).png({ compressionLevel: 9 }).toFile("public/logo.png");

/** The logo centred on a square: `fill` is how much of the side it may take */
const square = (size, fill, background) =>
  sharp(cut)
    .resize(Math.round(size * fill), Math.round(size * fill), { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .toBuffer()
    .then((logo) =>
      sharp({ create: { width: size, height: size, channels: 4, background } })
        .composite([{ input: logo, gravity: "center" }])
        .png({ compressionLevel: 9 })
        .toBuffer(),
    );

const black = { r: 0, g: 0, b: 0, alpha: 1 };
const clear = { r: 0, g: 0, b: 0, alpha: 0 };

// Phone home-screen icons: the logo on black, as the client drew it
writeFileSync("public/icons/icon-192.png", await square(192, 0.9, black));
writeFileSync("public/icons/icon-512.png", await square(512, 0.9, black));
writeFileSync("public/icons/maskable-512.png", await square(512, 0.7, black)); // Android crops to a circle
writeFileSync("src/app/apple-icon.png", await square(180, 0.86, black));
// Browser tab
writeFileSync("src/app/icon.png", await square(96, 1, clear));

// favicon.ico for old browsers: 16, 32 and 48 px PNGs inside one .ico
const sizes = [16, 32, 48];
const pngs = await Promise.all(sizes.map((s) => square(s, 1, clear)));
const head = Buffer.alloc(6 + 16 * sizes.length);
head.writeUInt16LE(0, 0);
head.writeUInt16LE(1, 2);
head.writeUInt16LE(sizes.length, 4);
let offset = head.length;
sizes.forEach((s, n) => {
  const e = 6 + 16 * n;
  head.writeUInt8(s, e);
  head.writeUInt8(s, e + 1);
  head.writeUInt16LE(1, e + 4); // colour planes
  head.writeUInt16LE(32, e + 6); // bits per pixel
  head.writeUInt32LE(pngs[n].length, e + 8);
  head.writeUInt32LE(offset, e + 12);
  offset += pngs[n].length;
});
writeFileSync("src/app/favicon.ico", Buffer.concat([head, ...pngs]));

console.log("wrote public/logo.png, public/icons/*.png, src/app/apple-icon.png, src/app/icon.png, src/app/favicon.ico");
