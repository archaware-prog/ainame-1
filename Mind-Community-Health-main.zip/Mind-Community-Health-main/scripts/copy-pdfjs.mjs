// Copies the PDF renderer's worker, fonts and decoders into public/pdfjs, where the owner panel loads
// them from when it turns uploaded PDFs into page images. Runs after every `npm install`, so the
// copy always matches the installed pdfjs-dist version. public/pdfjs is not committed.

import { cpSync, mkdirSync } from "node:fs";

const from = "node_modules/pdfjs-dist";
const to = "public/pdfjs";
mkdirSync(to, { recursive: true });
cpSync(`${from}/build/pdf.worker.min.mjs`, `${to}/pdf.worker.min.mjs`);
for (const dir of ["standard_fonts", "cmaps", "wasm", "iccs"]) cpSync(`${from}/${dir}`, `${to}/${dir}`, { recursive: true });
