// Checks every key in .env.local against the real Supabase and R2 accounts, without changing
// anything that matters (it writes, reads and deletes one tiny test file in R2).
//
//   node --env-file=.env.local scripts/check-setup.mjs
//
// Each line prints OK or FIX with what to do. Run it again until everything says OK.

import { createClient } from "@supabase/supabase-js";
import { AwsClient } from "aws4fetch";

const env = process.env;
let problems = 0;
const ok = (msg) => console.log(`  OK   ${msg}`);
const fix = (msg) => {
  problems++;
  console.log(`  FIX  ${msg}`);
};

const REQUIRED = [
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY",
  "SUPABASE_SECRET_KEY",
  "R2_ACCOUNT_ID",
  "R2_ACCESS_KEY_ID",
  "R2_SECRET_ACCESS_KEY",
  "R2_BUCKET",
  "OWNER_EMAIL",
];

console.log("\n.env.local");
const missing = REQUIRED.filter((k) => !env[k]?.trim());
if (missing.length) {
  for (const k of missing) fix(`${k} is empty. See docs/SETUP-KEYS.md.`);
  console.log("\nFill these in first, then run this again.\n");
  process.exit(1);
}
ok("all 8 values are filled in");

// ---------- Supabase ----------
console.log("\nSupabase");
const url = env.NEXT_PUBLIC_SUPABASE_URL.replace(/\/$/, "");
const admin = createClient(url, env.SUPABASE_SECRET_KEY, { auth: { persistSession: false } });
const pub = createClient(url, env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY, { auth: { persistSession: false } });

async function checkSupabase() {
  // One plain request first, so a wrong address gives one clear message instead of many
  let settings;
  try {
    const res = await fetch(`${url}/auth/v1/settings`, { headers: { apikey: env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY } });
    if (res.status === 401) return fix("Supabase refused the publishable key. Check NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY.");
    settings = await res.json();
  } catch (e) {
    return fix(`could not reach Supabase at ${url} (${e.cause?.code ?? e.message}). Check NEXT_PUBLIC_SUPABASE_URL.`);
  }
  ok("Supabase project found");

  const tables = await Promise.all(["resources", "events"].map((t) => admin.from(t).select("*", { count: "exact", head: true })));
  const bad = tables.find((r) => r.error);
  if (bad) fix(`tables not found (${bad.error.message}). Run supabase/schema.sql in the Supabase SQL Editor.`);
  else ok(`tables exist: ${tables[0].count} items, ${tables[1].count} usage events`);

  // Added 2026-11-18: topic cards, sub-topics and About/Contact. An older database needs schema.sql re-run.
  const tp = await pub.from("topics").select("slug", { count: "exact", head: true });
  const st = await pub.from("subtopics").select("slug", { count: "exact", head: true });
  const tcol = await admin.from("resources").select("subtopics").limit(1);
  const sp = await pub.from("site_pages").select("slug").limit(1);
  const newErr = tp.error ?? st.error ?? tcol.error ?? sp.error;
  if (newErr) fix(`topics or About/Contact table missing (${newErr.message}). Run supabase/schema.sql again.`);
  else ok(`topics and About/Contact pages ready: ${tp.count} topics, ${st.count} sub-topics`);

  const stats = await admin.rpc("stats_totals", { since: new Date(Date.now() - 86_400_000).toISOString() });
  if (stats.error) fix(`dashboard functions missing (${stats.error.message}). Run supabase/schema.sql again.`);
  else ok("dashboard functions exist");

  // The public key must be able to read topics but never write or read usage data
  const read = await pub.from("topics").select("slug").limit(1);
  if (read.error) fix(`the publishable key cannot read topics (${read.error.message}). Check NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY.`);
  else ok("publishable key can read the public catalog");
  const write = await pub.from("events").insert({ kind: "visit", device: "desktop" });
  if (!write.error) fix("the publishable key could WRITE usage data. Row Level Security is off: run supabase/schema.sql again.");
  else ok("publishable key cannot write (Row Level Security is on)");

  const users = await admin.auth.admin.listUsers({ perPage: 200 });
  if (users.error) fix(`could not list users (${users.error.message}). Check SUPABASE_SECRET_KEY.`);
  else {
    const owner = users.data.users.find((u) => u.email?.toLowerCase() === env.OWNER_EMAIL.trim().toLowerCase());
    if (!owner) fix(`no login exists for OWNER_EMAIL (${env.OWNER_EMAIL}). Supabase → Authentication → Users → Add user.`);
    else if (!owner.email_confirmed_at) fix(`the owner login exists but is not confirmed. Delete it and add it again with "Auto Confirm User" ticked.`);
    else ok(`owner login exists for ${owner.email}`);
  }

  if (settings.disable_signup) ok("public sign-ups are turned off");
  else fix('public sign-ups are ON. Supabase → Authentication → Sign In / Providers → turn off "Allow new users to sign up".');
}
await checkSupabase();

// ---------- Cloudflare R2 ----------
console.log("\nCloudflare R2");
const r2 = new AwsClient({ accessKeyId: env.R2_ACCESS_KEY_ID, secretAccessKey: env.R2_SECRET_ACCESS_KEY, service: "s3", region: "auto" });
const objectUrl = (key) => `https://${env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${env.R2_BUCKET}/${key}`;
const testKey = `setup-check/${Date.now()}.txt`;
let r2Reachable = true;

try {
  const put = await r2.fetch(objectUrl(testKey), { method: "PUT", body: "setup check", headers: { "Content-Type": "text/plain" } });
  if (!put.ok) {
    const body = await put.text();
    if (/NoSuchBucket/.test(body)) fix(`bucket "${env.R2_BUCKET}" not found. Check R2_BUCKET (and R2_ACCOUNT_ID).`);
    else if (/InvalidAccessKeyId|SignatureDoesNotMatch|Unauthorized/i.test(body) || put.status === 401 || put.status === 403)
      fix(`R2 refused the keys (${put.status}). Check R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY and that the token has "Object Read & Write" on this bucket.`);
    else fix(`R2 upload failed (${put.status}): ${body.slice(0, 200)}`);
  } else {
    ok("can upload a file");
    const get = await r2.fetch(objectUrl(testKey));
    if (get.ok && (await get.text()) === "setup check") ok("can read it back");
    else fix(`could not read the test file back (${get.status}).`);

    // A browser must NOT be able to open files without a signed link (the bucket must stay private)
    const open = await fetch(objectUrl(testKey));
    if (open.ok) fix("the bucket can be read without a key. Make sure no public access is turned on.");
    else ok("files are private without a signed link");

    const del = await r2.fetch(objectUrl(testKey), { method: "DELETE" });
    if (del.ok) ok("can delete files");
    else fix(`could not delete the test file (${del.status}). The token needs "Object Read & Write".`);
  }
} catch (e) {
  r2Reachable = false;
  fix(`could not reach R2 (${e.cause?.code ?? e.message}). Check R2_ACCOUNT_ID.`);
}

// The owner's browser uploads straight to R2, which only works if the bucket's CORS policy allows
// the site's address. Ask R2 the same question a browser would.
const origins = r2Reachable ? ["http://localhost:3000", env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "")].filter(Boolean) : [];
for (const origin of origins) {
  try {
    const signed = await r2.sign(`${objectUrl("setup-check/cors.txt")}?X-Amz-Expires=60`, { method: "PUT", aws: { signQuery: true } });
    const pre = await fetch(signed.url, {
      method: "OPTIONS",
      headers: { Origin: origin, "Access-Control-Request-Method": "PUT", "Access-Control-Request-Headers": "content-type" },
    });
    const allowed = pre.headers.get("access-control-allow-origin");
    if (pre.ok && (allowed === origin || allowed === "*")) ok(`browser uploads allowed from ${origin}`);
    else fix(`browser uploads from ${origin} are blocked. Add it to the bucket's CORS policy (docs/SETUP-KEYS.md, Part 2, step 4).`);
  } catch (e) {
    fix(`could not check CORS for ${origin} (${e.message}).`);
  }
}

console.log(problems ? `\n${problems} thing(s) to fix. Fix them, then run this again.\n` : "\nEverything is connected.\n");
process.exit(problems ? 1 : 0);
