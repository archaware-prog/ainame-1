// Loads the demo's sample subjects and material into a fresh database, for testing.
// Delete the sample items in the owner panel before launch (the videos are not the client's).
//
//   node --env-file=.env.local scripts/seed.mjs
//
// Does nothing if the database already has subjects.

import { readFileSync } from "node:fs";
import { createClient } from "@supabase/supabase-js";
import { AwsClient } from "aws4fetch";
import { createCanvas } from "@napi-rs/canvas";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

const env = process.env;
for (const k of ["NEXT_PUBLIC_SUPABASE_URL", "SUPABASE_SECRET_KEY", "R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET"]) {
  if (!env[k]) throw new Error(`${k} is missing from .env.local`);
}
const db = createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SECRET_KEY, { auth: { persistSession: false } });
const r2 = new AwsClient({ accessKeyId: env.R2_ACCESS_KEY_ID, secretAccessKey: env.R2_SECRET_ACCESS_KEY, service: "s3", region: "auto" });

async function put(key, body, type) {
  const res = await r2.fetch(`https://${env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${env.R2_BUCKET}/${key}`, { method: "PUT", body, headers: { "Content-Type": type } });
  if (!res.ok) throw new Error(`R2 upload failed (${res.status}): ${await res.text()}`);
}

/** Same layout the owner panel makes: original.pdf plus one WebP image per page, 1400 px wide */
async function uploadPdf(path, fileId) {
  const bytes = readFileSync(path);
  await put(`${fileId}/original.pdf`, bytes, "application/pdf");
  const lib = "node_modules/pdfjs-dist";
  const doc = await getDocument({ data: new Uint8Array(bytes), standardFontDataUrl: `${lib}/standard_fonts/`, cMapUrl: `${lib}/cmaps/`, wasmUrl: `${lib}/wasm/`, iccUrl: `${lib}/iccs/` }).promise;
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    const viewport = page.getViewport({ scale: 1400 / page.getViewport({ scale: 1 }).width });
    const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
    await page.render({ canvas, viewport, background: "#ffffff" }).promise;
    await put(`${fileId}/p${n}`, await canvas.encode("webp", 80), "image/webp");
  }
  const pages = doc.numPages;
  await doc.loadingTask.destroy();
  return { file_id: fileId, file_pages: pages, file_bytes: bytes.length };
}

const SUBJECTS = [
  {
    slug: "engineering-maths",
    name: "Engineering Maths",
    emoji: "📐",
    gradient: "from-orange-400 to-rose-500",
    description: "Laplace, Fourier, matrices and calculus, explained simply.",
  },
  {
    slug: "data-structures",
    name: "Data Structures",
    emoji: "🧩",
    gradient: "from-violet-500 to-fuchsia-500",
    description: "Arrays to graphs, with notes, slides and exam questions.",
  },
  {
    slug: "engineering-physics",
    name: "Engineering Physics",
    emoji: "⚛️",
    gradient: "from-sky-400 to-indigo-500",
    description: "Quantum basics, optics and more.",
  },
  {
    slug: "operating-systems",
    name: "Operating Systems",
    emoji: "💻",
    gradient: "from-emerald-400 to-teal-600",
    description: "Processes, scheduling and memory management.",
  },
  {
    slug: "machine-learning",
    name: "Machine Learning",
    emoji: "🤖",
    gradient: "from-pink-500 to-purple-600",
    description: "Neural networks and the maths behind them.",
  },
];

const SAMPLES = [
  // Data Structures
  { id: "ds-1", title: "Unit 1: Arrays & Linked Lists", subjectSlug: "data-structures", type: "notes", unit: 1, fileUrl: "/samples/ds-unit1-arrays-linked-lists.pdf", allowDownload: true, examTags: ["class-test", "university"], addedAt: "2026-10-27" },
  { id: "ds-2", title: "Stacks & Queues", subjectSlug: "data-structures", type: "slides", unit: 2, fileUrl: "/samples/ds-stacks-queues-slides.pdf", allowDownload: false, addedAt: "2026-10-26" },
  { id: "ds-3", title: "Important Questions (Units 1 to 5)", subjectSlug: "data-structures", type: "qbank", fileUrl: "/samples/ds-important-questions.pdf", allowDownload: true, examTags: ["university"], addedAt: "2026-10-22" },
  { id: "ds-4", title: "Data Structures: Full Course", subjectSlug: "data-structures", type: "video", videoUrl: "https://www.youtube.com/watch?v=RBSGKlAvoiM", allowDownload: false, addedAt: "2026-10-20" },
  { id: "ds-5", title: "University Exam Paper: Winter 2025", subjectSlug: "data-structures", type: "paper", fileUrl: "/samples/university-exam-paper-2025.pdf", allowDownload: true, examTags: ["university"], addedAt: "2026-10-12" },
  { id: "ds-6", title: "Introduction to Algorithms", subjectSlug: "data-structures", type: "video", unit: 1, videoUrl: "https://www.youtube.com/watch?v=0IAPZzGSbME", allowDownload: false, addedAt: "2026-10-08" },

  // Engineering Maths
  { id: "m-1", title: "Laplace Transform: Short Notes", subjectSlug: "engineering-maths", type: "notes", unit: 3, fileUrl: "/samples/maths-laplace-notes.pdf", allowDownload: true, examTags: ["class-test"], addedAt: "2026-10-28" },
  { id: "m-2", title: "What is a Laplace Transform?", subjectSlug: "engineering-maths", type: "video", unit: 3, videoUrl: "https://www.youtube.com/watch?v=j0wJBEZdwLs", allowDownload: false, addedAt: "2026-10-25" },
  { id: "m-3", title: "Fourier Transform: Visual Intro", subjectSlug: "engineering-maths", type: "video", unit: 4, videoUrl: "https://www.youtube.com/watch?v=spUNpyF58BY", allowDownload: false, addedAt: "2026-10-18" },
  { id: "m-4", title: "Maths Question Bank", subjectSlug: "engineering-maths", type: "qbank", fileUrl: "/samples/maths-question-bank.pdf", allowDownload: true, examTags: ["university", "class-test"], addedAt: "2026-10-15" },
  { id: "m-5", title: "Vectors: Linear Algebra Ch. 1", subjectSlug: "engineering-maths", type: "video", unit: 1, videoUrl: "https://www.youtube.com/watch?v=fNk_zzaMoSs", allowDownload: false, addedAt: "2026-10-05" },
  { id: "m-6", title: "The Essence of Calculus", subjectSlug: "engineering-maths", type: "video", unit: 2, videoUrl: "https://www.youtube.com/watch?v=WUvTyaaNkzM", allowDownload: false, addedAt: "2026-10-02" },

  // Physics
  { id: "p-1", title: "Quantum Mechanics: Basics", subjectSlug: "engineering-physics", type: "notes", unit: 2, fileUrl: "/samples/physics-quantum-notes.pdf", allowDownload: true, addedAt: "2026-10-24" },

  // Operating Systems
  { id: "os-1", title: "CPU Scheduling", subjectSlug: "operating-systems", type: "slides", unit: 2, fileUrl: "/samples/os-cpu-scheduling-slides.pdf", allowDownload: true, addedAt: "2026-10-27" },
  { id: "os-2", title: "Algorithms and Computation (MIT)", subjectSlug: "operating-systems", type: "video", videoUrl: "https://www.youtube.com/watch?v=ZA-tUyM_y7s", allowDownload: false, addedAt: "2026-10-10" },

  // Machine Learning
  { id: "ml-1", title: "What is a Neural Network?", subjectSlug: "machine-learning", type: "video", unit: 1, videoUrl: "https://www.youtube.com/watch?v=aircAruvnKk", allowDownload: false, addedAt: "2026-10-23" },

  // Competitive exam material (linked to a subject so it also shows there)
  { id: "gate-1", title: "GATE Practice Set 1", subjectSlug: "data-structures", type: "qbank", fileUrl: "/samples/gate-practice-set-1.pdf", allowDownload: true, examTags: ["competitive"], addedAt: "2026-10-21" },
];

const { count, error: countError } = await db.from("subjects").select("slug", { count: "exact", head: true });
if (countError) throw new Error(`Database not ready (did you run supabase/schema.sql?): ${countError.message}`);
if (count) {
  console.log(`Database already has ${count} subjects. Nothing to do.`);
  process.exit(0);
}

const { error: subjectError } = await db.from("subjects").insert(SUBJECTS.map((s, i) => ({ ...s, position: i + 1 })));
if (subjectError) throw subjectError;
console.log(`Added ${SUBJECTS.length} subjects`);

for (const r of SAMPLES) {
  let file = {};
  if (r.fileUrl) {
    const name = r.fileUrl.split("/").pop().replace(/.pdf$/, "");
    file = await uploadPdf(`public${r.fileUrl}`, `files/sample-${name}`);
  }
  const { error } = await db.from("resources").insert({
    title: r.title,
    subject_slug: r.subjectSlug,
    type: r.type,
    unit: r.unit ?? null,
    video_url: r.videoUrl ?? null,
    allow_download: r.allowDownload,
    exam_tags: r.examTags ?? [],
    added_at: new Date(r.addedAt).toISOString(),
    ...file,
  });
  if (error) throw error;
  console.log(`  + ${r.title}`);
}
console.log("Done.");
